# Studio Moser Inspiration Board

**Created for:** Tim Moser
**Date:** February 11, 2026
**Purpose:** Visual direction guide for Studio Moser website

---

## Top 10 Must-See Sites

### 1. **Paul Stamatiou** - paulstamatiou.com + photos.paulstamatiou.com
**Why this works for Studio Moser:**
- Corporate design leader (Twitter, Sesame) + extensive photography + personal writing
- Two-site approach: main for design/writing, subdomain for elaborate photo essays
- 20+ years of consistent content builds massive authority
- Perfect model for Tim's dual design + photography identity

**What to steal:**
- Separate domain strategy for photography (photos.studiomoser.com)
- Photo essay format (travel series, elaborate photosets)
- Balance of professional credibility + personal projects

**URL:** https://paulstamatiou.com/

---

### 2. **Tobias van Schneider** - vanschneider.com
**Why this works for Studio Moser:**
- Multiple disciplines (design, photography, products, sneakers) under one unified brand
- "House of van Schneider" approach - personal brand encompasses everything
- Doesn't apologize for breadth, presents it as strength
- Co-founder of Semplice (product maker + designer like Tim)

**What to steal:**
- Unified brand approach ("Studio Moser" as umbrella for everything)
- Confidence in multi-disciplinary positioning
- Visual consistency across all work types
- Portfolio + products + photography all equal prominence

**URL:** https://vanschneider.com/

---

### 3. **Frank Chimero** - frankchimero.com
**Why this works for Studio Moser:**
- Creative Director at Modern Treasury with deeply personal site
- Elegant simplicity - white space, thoughtful typography
- Writing + portfolio + explorations blend seamlessly
- Philosophy-driven, doesn't separate "professional" from "personal"

**What to steal:**
- Story-driven approach (personality comes through)
- Minimalist design that feels warm, not cold
- Writing as thought leadership platform
- "This is me, completely" positioning

**URL:** https://frankchimero.com/

---

### 4. **Jack McDade** - jackmcdade.com
**Why this works for Studio Moser:**
- Creator of Statamic (product) + designer + educator (Radical Design course)
- "Wacky" personal site - not afraid to be unconventional
- Personal brand supports product brands
- Portfolio + products + teaching integrated

**What to steal:**
- Permission to be personality-driven
- Product work gets equal billing with client work
- Playful touches without sacrificing professionalism
- Shows full human behind the work

**URL:** https://jackmcdade.com/

---

### 5. **Andy Matuschak** - andymatuschak.org + notes.andymatuschak.org
**Why this works for Studio Moser:**
- Applied researcher + tool builder (previously Khan Academy, Apple)
- "Building in public" with public notes site + Patreon
- Multiple sites for different purposes but unified brand
- Research + products + writing all interconnected

**What to steal:**
- Building in public approach (perfect for Ausra Photos)
- Separate spaces for different purposes (main site vs. updates)
- Patreon/supporter funding model for ongoing work
- Transparency about process and progress

**URL:** https://andymatuschak.org/

---

### 6. **Daniel Eden** - daneden.me
**Why this works for Studio Moser:**
- Product Designer at Meta Reality Labs
- Personal site + blog + portfolio + apps (side projects)
- Professional work + side projects presented equally
- Apps get same prominence as corporate portfolio

**What to steal:**
- Equal treatment of day job and side projects
- Simple navigation: Work | Writing | Apps | About
- Corporate credibility + indie spirit balance
- Clean, minimal design lets work speak

**URL:** https://daneden.me/

---

### 7. **James Victore** - jamesvictore.com + yourworkisagift.com + courses
**Why this works for Studio Moser:**
- Designer, artist, educator, business coach - all under one brand
- Multiple sites for different offerings (portfolio + education + store)
- Each site serves specific audience while maintaining unified brand
- Major clients (Adobe, MailChimp, Starbucks) + personal projects

**What to steal:**
- Multi-site strategy when appropriate (future consideration)
- Each offering gets proper space and focus
- Strong personal brand ties everything together
- Big client names establish instant credibility

**URL:** https://jamesvictore.com/

---

### 8. **Jessica Hische** - jessicahische.is
**Why this works for Studio Moser:**
- Lettering artist, illustrator, author with multiple revenue streams
- Clean portfolio with bold typography showcasing diverse work
- Unified visual identity across different project types
- Portfolio + FAQ + personal sharing integrated naturally

**What to steal:**
- Strong visual identity across all sections
- FAQ approach (answers common questions upfront)
- Diverse work presented cohesively
- Typography-first design (relevant for Tim's design background)

**URL:** https://www.jessicahische.is/working

---

### 9. **Meiwen** - (Multiple platforms)
**Why this works for Studio Moser:**
- Professional designer AND photographer (travel, editorial, interior)
- Minimalist homepage with short bio and featured items from both disciplines
- Simple toggle between disciplines, unified aesthetic
- Design sensibility enhances photography presentation

**What to steal:**
- Clean separation between design and photography
- Minimal design philosophy
- Let the work be the hero
- Designer eye visible in photography portfolio presentation

**Referenced in:** [Framer Photography Portfolios](https://www.framer.com/blog/photography-portfolio-websites/)

---

### 10. **Jason Kottke** - kottke.org + kottke.org/portfolio
**Why this works for Studio Moser:**
- Blogger since 1998, also graphic designer and web designer
- Created Silkscreen typeface (used by Adobe, MTV, Volvo) and Gawker logo
- Blog is primary, but portfolio demonstrates serious design chops
- Writing builds audience, portfolio converts clients

**What to steal:**
- Blog as primary audience builder
- Long-term content strategy (25+ years!)
- Portfolio section separate but accessible
- Writing demonstrates thinking, portfolio demonstrates execution

**URL:** https://kottke.org/ + https://kottke.org/portfolio/portfolio.html

---

## Design Pattern Gallery

### Navigation Patterns

#### Pattern A: Split Entry Points (Design vs. Photography)
**Example:** Samuel Angibaud
- Split-screen homepage: Design on left, Photography on right
- Immediate choice between disciplines
- No confusion about what visitor wants

**When to use:** When disciplines serve different audiences completely

---

#### Pattern B: Unified Brand with Sections
**Examples:** Tobias van Schneider, Frank Chimero
- One site, clear sections in navigation
- Work | Photography | Products | About | Contact
- Personal brand is unifying element

**When to use:** When you want ONE cohesive identity (RECOMMENDED FOR TIM)

---

#### Pattern C: Three-Column Entry (Clear Pillars)
**Example:** Anwita+Arun (quadrant homepage)
- Homepage divided into clear zones
- Each zone is entry point to different discipline
- Visual grid, minimal text

**When to use:** When you have 3-4 distinct offerings

---

#### Pattern D: Story-First, Then Navigate
**Examples:** Frank Chimero, narrative-driven sites
- Homepage tells your story
- Then offers clear navigation to specific sections
- Personal connection before work showcase

**When to use:** When personal brand/philosophy is key selling point

**RECOMMENDATION FOR TIM:** Hybrid of B + D
- Story-driven homepage ("I'm Tim, I make things")
- Clear navigation to specialized sections
- One unified brand (Studio Moser) with distinct areas

---

### Layout Approaches

#### Minimalist with Bold Typography
**Examples:** Frank Chimero, Khoi Vinh, Ethan Marcotte
- Generous white space
- Large, readable type
- One accent color or monochrome
- Focus on content, not decoration

**Tone:** Professional, thoughtful, modern
**Best for:** Design + writing focus
**Color:** Black + white + one accent

---

#### Image-First Grid
**Examples:** Most photography portfolios, Anwita+Arun
- Large images dominate
- Minimal text
- Grid or masonry layouts
- Images do the talking

**Tone:** Visual storytelling, immersive
**Best for:** Photography-forward presentation
**Color:** Neutral frames to let photos shine

---

#### Editorial/Magazine Style
**Examples:** Paul Stamatiou photo essays, Jason Kottke
- Longer-form content
- Article-style layouts
- Mix of images + text
- Sophisticated typography

**Tone:** Thoughtful, narrative, content-rich
**Best for:** Writing + photography + storytelling
**Color:** Editorial neutrals with considered accents

---

#### Playful/Interactive
**Examples:** Bruno Simon, Jack McDade
- Custom interactions
- Personality-driven design
- Unconventional approaches
- Memorable experiences

**Tone:** Creative, unique, tech-forward
**Best for:** Standing out, showing technical skills
**Color:** Expressive, varied

**RECOMMENDATION FOR TIM:** Foundation of Minimalist + Image Strength in photo sections + slight playfulness in product pages

---

### Photography Integration Strategies

#### Strategy 1: Separate Photography Portfolio
**Example:** Paul Stamatiou (photos.paulstamatiou.com)
- Dedicated subdomain or section
- Client galleries, services, booking flow isolated
- Photography treated as equal business

**When to use:** Professional photography services are significant revenue

---

#### Strategy 2: Photography as Equal Discipline
**Examples:** Meiwen, Anwita+Arun, designer-photographers
- Photography portfolio same prominence as design
- Clear service offerings for photo clients
- Toggle or separate navigation section

**When to use:** Photography is equal revenue stream to design (POTENTIALLY TIM)

---

#### Strategy 3: Photography as Documentation
**Approach:** Use photography to document design/product process
- Behind-scenes photos become content
- Process documentation with photography
- Shows intersection of disciplines

**When to use:** Photography enhances primary work, not separate service

**RECOMMENDATION FOR TIM:** Strategy 2 (Equal Discipline) with elements of Strategy 3 (documentation)

---

### Product Showcase Patterns

#### Building in Public (In-Progress Transparency)
**Examples:** Andy Matuschak, Dean Tate (game dev), indie makers
- Show works-in-progress prominently
- Status updates: "In Development," "Beta," "Shipped"
- Devlogs, updates, beta signups
- Community building, early adopters

**Best for:** Ausra Photos, game development, ongoing projects

---

#### Shipped Products Grid
**Examples:** Indie Hacker portfolios ($22k/mo, $185k/mo success stories)
- Homepage shows available products
- Each product is a card with stats/links
- Revenue-focused presentation

**Best for:** Multiple shipped products generating income

---

#### Products as Case Studies
**Examples:** Designer portfolios that include side projects
- Products treated like client work
- Challenge → Solution → Outcome format
- Shows process thinking

**Best for:** Demonstrating product thinking to potential clients

**RECOMMENDATION FOR TIM:** Mix of "Building in Public" (Ausra, active projects) + "Shipped Products" (games, completed apps)

---

## What to Steal - Specific Elements

### Homepage Heroes

**Paul Stamatiou approach:**
```
Large hero image or photo
Brief introduction (1-2 sentences)
Clear CTAs to main sections
Recent work or writing below
```

**Frank Chimero approach:**
```
Simple text introduction
"I'm [name]. I [do this]."
Generous white space
Elegant typography
Clear navigation
```

**Tobias van Schneider approach:**
```
Visual showcase of range
"House of [Name]" branding
All work types visible immediately
Confident multi-disciplinary positioning
```

**STEAL THIS FOR TIM:**
```
TIM MOSER
Creative Director · Photographer · Maker

14 years directing creative for Microsoft, Disney, and NPR.
Also building apps, making indie games, and photographing stories.

Seattle-based. Always making something.

[Three visual cards: DESIGN → | PHOTOGRAPHY → | PRODUCTS →]
```

---

### About Pages That Work

**Pattern: Lead with Credentials, Then Explain Breadth**

From research examples:
1. **Start with authority** - "14 years at [Big Company]"
2. **Explain side projects** as natural extension of creative practice
3. **Frame umbrella brand** - "Studio Moser is where it all comes together"
4. **Show it's connected** - Design thinking across all mediums
5. **Clear CTAs** - What you're looking for, how to work together

**STEAL THIS STRUCTURE:**
```markdown
# About Tim Moser

## I make things.
[Brief, confident introduction]

## By Day / By Night / Always
[Structure showing different facets]

## Why "Studio Moser"?
[Explains umbrella brand concept]

## Currently
[What's happening now]

## Let's Work Together
[Clear CTA + what you're looking for]
```

---

### Navigation Labels That Work

**Simple & Clear (Recommended):**
- Work
- Photography
- Products
- About
- Contact

**Alternative (More Specific):**
- Design
- Photography
- Projects
- Studio
- Contact

**Alternative (Personality-Driven):**
- What I Make
- How I See
- What I'm Building
- Who I Am
- Let's Talk

**RECOMMENDATION:** Simple & Clear (first option)

---

### Photography Service Pages

**Best Practices from Research:**

1. **Show the work first** (15-20 best images)
2. **Services section** separate from gallery
3. **Simple pricing structure:**
   - "Starting at $X" or
   - "Half-day session: $X, Full-day: $Y" or
   - "Get in touch for custom quote"
4. **What's included** (deliverables, timeline, editing)
5. **Easy booking:** Contact form or email
6. **Client testimonials** (if available)

**STEAL THIS STRUCTURE:**
```
/photography
  - Portfolio galleries (commercial, personal, process)
  - Services page
    - What I Offer
    - Example Projects
    - Investment (pricing)
    - How to Book
```

---

### Product Pages That Convert

**From Indie Maker Research:**

1. **Status indicator** - "In Development," "Beta," "Launched"
2. **Clear value prop** - "What it is" in one sentence
3. **Personal motivation** - "Why I'm building it"
4. **Current progress** - Where it's at now
5. **Next milestone** - What's coming
6. **CTA** - Waitlist, beta signup, or download

**STEAL THIS TEMPLATE:**
```markdown
### Ausra Photos
[Screenshot/Hero Image]

**Status:** Active Development (Beta Q2 2026)
**What it is:** Photo organization tool that respects your workflow
**Why I'm building it:** Frustrated with existing solutions that force you into their system
**Progress:** Private alpha with 50 users, rebuilding core features based on feedback
**Next:** Public beta launch with collaborative features

[Join Waitlist] [Follow Updates]
```

---

### Footer Patterns

**Minimalist Approach:**
```
© 2026 Studio Moser
Email | Instagram | LinkedIn
```

**Extended Approach:**
```
STUDIO MOSER

Work | Photography | Products | About | Contact

© 2026 Studio Moser · Seattle, WA
tim@studiomoser.com | @studiomoser
```

**RECOMMENDATION:** Extended (provides easy navigation, social proof)

---

## What to Avoid - Common Mistakes

### ❌ Don't: Apologize for Breadth
**Bad:** "I wear many hats and do a little bit of everything"
**Good:** "I'm a multi-disciplinary creative working across design, photography, and product development"

**Why:** Confidence is key. Your breadth is a strength, not a weakness.

---

### ❌ Don't: Scatter Your Identity
**Bad:** Separate disconnected sites with no clear connection
**Good:** One umbrella brand (Studio Moser) with clear sections

**Why:** Unified brand builds recognition and authority

---

### ❌ Don't: Hide Your Credentials
**Bad:** Lead with indie projects, mention Moby in passing
**Good:** Lead with "14 years at Moby, clients like Microsoft, Disney, NPR"

**Why:** Enterprise credentials establish instant authority

---

### ❌ Don't: Use Generic Portfolio Templates
**Bad:** Standard Squarespace photography template everyone uses
**Good:** Custom design (or heavily customized template) that reflects your aesthetic

**Why:** You're a designer - your site should demonstrate your skills

---

### ❌ Don't: Overwhelm with Too Much Content at Launch
**Bad:** Try to launch with 50 projects, full blog, complete product pages
**Good:** Launch with 5-7 best projects, basic product info, room to grow

**Why:** Better to launch simple and expand than delay indefinitely

---

### ❌ Don't: Mix Photography Styles Without Organization
**Bad:** Commercial product shots + travel photos + portraits all mixed together
**Good:** Clear galleries: Commercial | Personal | Process

**Why:** Different audiences looking for different things

---

### ❌ Don't: Treat Products Like Side Projects
**Bad:** "Here are some things I made on the side"
**Good:** "Products & Projects" section with proper case study treatment

**Why:** Products demonstrate entrepreneurial thinking and follow-through

---

### ❌ Don't: Use Vague Service Descriptions
**Bad:** "Available for creative projects"
**Good:** "Available for 2-3 select projects per quarter. Interested in: [specific types]"

**Why:** Specificity attracts the right clients, vagueness attracts confusion

---

### ❌ Don't: Forget Mobile Experience
**Bad:** Design for desktop only, assume mobile will work
**Good:** Test on mobile from day one, optimize for touch

**Why:** Many visitors will discover you via mobile/social

---

### ❌ Don't: Launch Without Clear CTAs
**Bad:** Beautiful portfolio with no way to contact you
**Good:** Clear contact options on every major page

**Why:** Don't make people hunt to hire you

---

## Organized by Visual Vibe

### Clean & Minimal
**Examples:** Frank Chimero, Khoi Vinh, Ethan Marcotte
**Characteristics:**
- Generous white space
- Limited color palette (black + white + one accent)
- Typography-focused
- Let work breathe

**Good for:** Professional credibility, design-forward positioning
**Studio Moser fit:** 8/10 - Works well for main site foundation

---

### Image-Heavy & Visual
**Examples:** Paul Stamatiou photos, photography portfolios
**Characteristics:**
- Large hero images
- Full-bleed photography
- Minimal text
- Visual storytelling

**Good for:** Photography showcase, visual impact
**Studio Moser fit:** 9/10 - Perfect for photography section

---

### Editorial & Content-Rich
**Examples:** Jason Kottke, Khoi Vinh, Paul Stamatiou writing
**Characteristics:**
- Article-style layouts
- Readable typography (serif body text)
- Mix of images and text
- Long-form content

**Good for:** Thought leadership, writing platform
**Studio Moser fit:** 7/10 - Good if Tim wants to blog regularly

---

### Playful & Interactive
**Examples:** Bruno Simon, Jack McDade, Patrick Heng
**Characteristics:**
- Custom interactions
- Unexpected elements
- Personality-forward
- Technical showcase

**Good for:** Standing out, showing technical chops
**Studio Moser fit:** 5/10 - Use sparingly in product sections

---

### Bold & Confident
**Examples:** Tobias van Schneider, Jessica Hische
**Characteristics:**
- Strong typography
- Confident positioning
- Unapologetic about breadth
- Personal brand front and center

**Good for:** Multi-disciplinary positioning, personal brand strength
**Studio Moser fit:** 10/10 - Perfect tone for Tim's positioning

---

## Quick Reference: Best Site for Each Need

**Best multi-disciplinary positioning:** Tobias van Schneider
**Best design + photography balance:** Paul Stamatiou
**Best minimalist aesthetic:** Frank Chimero
**Best personality-driven:** Jack McDade
**Best building-in-public:** Andy Matuschak
**Best photography showcase:** Paul Stamatiou (photos subdomain)
**Best product showcase:** Indie Hacker portfolios + Andy Matuschak
**Best about page structure:** Frank Chimero, James Victore
**Best writing integration:** Jason Kottke, Khoi Vinh
**Best corporate + indie balance:** Daniel Eden

---

## Recommended Direction for Studio Moser

### Overall Vibe: "Confident Multi-Disciplinary Creative"

**Primary Inspiration:** Tobias van Schneider (unified brand approach)
**Secondary Inspiration:** Paul Stamatiou (design + photography balance)
**Design Foundation:** Frank Chimero (minimalist elegance)
**Product Approach:** Andy Matuschak (building in public)
**About/Story:** James Victore (tying it all together)

---

### Visual Direction

**Foundation:**
- Clean, minimal design with generous white space
- Bold typography (headings), readable serif or clean sans (body)
- Warm neutral palette (cream, warm gray) + deep blue or forest green accent
- Pacific Northwest influence (natural, grounded, not flashy)

**Homepage:**
- Story-driven hero (brief intro, confident positioning)
- Three visual cards for main sections (Design, Photography, Products)
- Featured work below (mix from all three areas)
- Simple footer with navigation and contact

**Work Section:**
- Large project images
- Brief case studies (challenge, role, outcome)
- Lead with Moby credentials (Microsoft, Disney, NPR)
- Mix of corporate and independent work

**Photography Section:**
- Full-bleed images
- Organized galleries (Commercial, Personal, Process)
- Separate services page with clear offerings
- Contact/booking CTA prominent

**Products Section:**
- Project cards with status indicators
- "Building in public" transparency
- Active projects (Ausra) + Shipped (games)
- Updates/devlog optional but recommended

**About Page:**
- Lead with credentials (14 years Moby)
- Explain breadth as unified creative practice
- "Why Studio Moser?" section
- Currently working on (shows you're active)
- Clear CTA (what you're looking for)

---

## Next Steps for Tim

1. **Review this board** - Mark favorites, note what resonates
2. **Visit top 5 sites** - Spend time with Paul Stamatiou, Tobias van Schneider, Frank Chimero, Jack McDade, Andy Matuschak
3. **Identify direction** - Which vibe feels right? Minimalist, bold, playful, editorial?
4. **Gather content:**
   - 5-7 best Moby projects (images, descriptions)
   - 15-20 best photos (organized: commercial, personal, process)
   - Product screenshots/info (Ausra, games)
   - Write about page (use template from strategy doc)
5. **Choose platform** - Framer recommended (fast, designer-friendly)
6. **Build structure** - Homepage + 5 core pages
7. **Launch in 2 weeks** - Start simple, expand based on feedback

---

## Your Decision Points

**Tim, decide on these:**

1. **Navigation approach:**
   - [ ] Option A: Work | Photography | Products | About | Contact
   - [ ] Option B: Design | Photography | Projects | Studio | Contact
   - [ ] Option C: Something else? _____________

2. **Photography strategy:**
   - [ ] Equal discipline (separate major section)
   - [ ] Subdomain approach (photos.studiomoser.com)
   - [ ] Integrated (part of overall portfolio)

3. **Product transparency:**
   - [ ] Full "building in public" (show everything)
   - [ ] Moderate (show progress, but curated)
   - [ ] Minimal (only announce when shipped)

4. **Visual direction:**
   - [ ] Minimalist & clean (Frank Chimero vibe)
   - [ ] Bold & confident (Tobias van Schneider vibe)
   - [ ] Image-first (Paul Stamatiou photos vibe)
   - [ ] Mix: Minimal foundation + image strength + slight playfulness

5. **Launch approach:**
   - [ ] Simple launch (homepage + basic pages, expand later)
   - [ ] Full launch (complete case studies, galleries, blog)
   - [ ] Phased (launch core, add sections monthly)

**Recommended answers:** 1A, 2A, 3B, 4D, 5A

---

*This inspiration board is your visual strategy guide. The research is done, the patterns are identified, and the direction is clear. Now it's about choosing what resonates with you and building it.*

*The market doesn't need another single-focus portfolio. It needs Studio Moser - authentic, multi-disciplinary, confident.*
