# Tim Moser: Professional Profile & Strategic Insights

**Research Completed:** February 11, 2026
**Purpose:** Enhance all 5 project strategies with Tim-specific insights

---

## Who Tim Moser Is

### Professional Background

**Moby, Inc (2011-Present)**
- Co-founder and Creative Director
- Partners with James Jacoby
- 14+ years building digital products for major clients
- Manages overall aesthetic and visual direction

**Key Accomplishments:**
- 20+ years in human-centered design & collaborative innovation
- 10 startups co-founded
- 25+ brands created and launched
- Built agency from freelance roots to established Seattle firm

**Education:**
- Northwest College of Art (2000-2003)

### Moby, Inc Portfolio

**Major Clients:**
- Microsoft
- Disney
- T-Mobile
- Philips
- Fisher-Price
- Fox (21st Century Fox)
- Fred Hutch (Cancer Research)
- Fluke
- NPR
- Deloitte Digital
- Delta Dental
- AON
- Xbox / Office 365

**Expertise Areas:**
- iOS and Android mobile app development
- Website design and development
- Progressive web apps
- Voice interfaces
- Games
- AR and VR experiences
- eCommerce ecosystems
- Content management systems
- Digital product strategy

**Company Philosophy:**
- User-centered design (understand end-users before development)
- Collaborative process (clients as true team partners, not outsiders)
- Strategic storytelling (clear brand narratives)
- Technical excellence (advisors on technology decisions)

### Side Projects

**Supernormal Games** (Indie Game Studio)
- Formerly "Makeshift Games"
- Created "Depict" - drawing and guessing game (very popular)
- Created "Chuck the Ball" - fast-paced puzzle game
- Demonstrates: Entrepreneurship, consumer product experience, indie game development

**Personal Sites:**
- timontheinterweb.com (currently inactive)
- builtbymoby.com (company site)
- makeshiftgames.com (game studio)

### Professional Identity

**Self-Description:**
- "Charismatic Creative Director"
- "20+ Years Creating Magic Through Human-Centered Design & Collaborative Innovation"
- "Creator of things visual and musical"

**LinkedIn Profile:** linkedin.com/in/timmoser/

---

## Key Strengths & Capabilities

### Design & Creative Direction
- Enterprise-level creative direction for Fortune 500 companies
- 25+ brands created from scratch
- Visual identity and brand systems expert
- Photography skills (visual and production)
- Musical creativity (multi-disciplinary creative)

### Technical Skills
- iOS/Android mobile app development
- Web development (full-stack understanding)
- SwiftUI, React Native, modern frameworks
- Product prototyping and user testing
- AR/VR/game development experience

### Business & Strategy
- 10 startups co-founded (entrepreneurial DNA)
- 14 years running successful agency
- Client relationship management (Fortune 500 level)
- Pricing and positioning expertise
- Go-to-market strategy from multiple launches

### Network & Community
- 14 years of Seattle creative community connections
- Moby client network (Microsoft, Disney, NPR, etc.)
- Indie game development community
- Photography community ties
- Pacific Northwest creative scene established presence

---

## Comparable Professionals

### Agency Founders Turned Independent
- **Frank Chimero** - Designer, writer, teacher (similar commercial + personal blend)
- **Tobias van Schneider** - Former Spotify, now runs Semplice (indie game interest too)
- **Jessica Hische** - Letterer/illustrator with agency work + personal projects

### Creative Directors with Indie Projects
- **Rami Ismail** - Game developer + consultant for major studios
- **Jonathan Harris** - Artist/designer with commercial clients + personal explorations

### Pacific Northwest Multi-Disciplinary Creatives
- **Michael Lanning** - Designer/developer/photographer at Instrument Portland
- **Aaron Draplin** - Portland-based designer with strong PNW influence

---

## How Tim's Profile Impacts Each Project Strategy

### 1. Studio Moser (Personal Portfolio/Agency)

**Key Insight:** Tim shouldn't position as "new designer seeking work"

**Enhanced Positioning:**
- "Where Moby co-founder Tim Moser takes on select projects"
- "Enterprise-level creative direction without committee overhead"
- "14 years directing work for Microsoft, Disney, NPR - now available for independent projects"

**Advantages:**
- Instant credibility from Moby portfolio
- Can charge premium rates ($1,500-2,500/day) justified by Fortune 500 experience
- Built-in Seattle network from 14 years
- Portfolio already exists (select Moby projects + indie games)

**Target Clients:**
- Venture-backed startups (Series A-C) needing enterprise-level creative direction
- Agencies needing fractional senior creative director
- Mid-market companies ($5M-50M) needing rebrand without full agency cost

**Realistic Scope:** 10-15 hours/week max = 2-3 projects per quarter

---

### 2. Ausra Photos (Privacy-First Photo Management App)

**Key Insight:** Tim has shipped mobile apps before - can actually build this

**Advantages:**
- iOS/Android expertise from Moby transfers directly
- User-centered design philosophy perfect for photo UX
- Can create Apple-quality interface from day one
- Seattle photography community as early adopters

**Realistic Scope:** 10-15 hours/week = 6-month MVP (Mac-only initially)

**MVP Features (Achievable):**
- Mac app only (not iOS/iPad initially)
- Import, organize, search photos
- Basic editing tools
- Local-first storage (skip cloud sync until post-launch)
- Focus on organization over AI wizardry

**Go-to-Market:**
- Seattle photographers as beta users
- Moby network for soft launch
- Product Hunt + Indie Hackers communities
- r/photography, r/apple, r/privacy

**Decision Point:** Large opportunity but extremely competitive. Should Tim partner with developer rather than solo build?

---

### 3. Ebook Reader App

**Key Insight:** Reading apps need excellent UX - Tim's specialty

**Advantages:**
- Mobile app development experience directly applicable
- Cross-platform technical complexity is something Tim has solved
- Design quality as differentiator in crowded market
- Privacy positioning aligns with user-centered values

**Realistic Scope:** 10-15 hours/week = 6-month MVP (iOS-only initially)

**Comparable Solo Developers:**
- David Smith (Widgetsmith) - Apple designer turned indie dev
- Matthew Palmer (Vanilla, Rocket) - Designer/developer hybrid
- Christian Selig (Apollo) - Solo designer/developer

**Alternative Approach:** Rather than build from scratch, offer design consulting to existing reader app (Readwise, Koodo) for upfront payment + equity stake. Leverages Tim's actual strength: premium design direction.

**Decision Point:** Great market but solo build while running Moby is extremely challenging.

---

### 4. Shopify Physical Product Store (Apparel)

**Key Insight:** 25+ brands created means Tim knows the formula

**Advantages:**
- Design quality will be superior to typical POD stores
- Photography skills = professional product shots (save money)
- Can create cohesive brand ecosystem
- Seattle creative community as built-in audience

**Recommended Niche:**
- Option A: Seattle creative community apparel
- Option B: Indie game developer apparel
- Option C: Photography community gear

**Realistic Scope:** 5-10 hours/week for ongoing operations

**Pricing Strategy:**
- Premium positioning ($38-44 tees, $58-68 hoodies)
- Justified by "Designed by Creative Director at Moby, Inc"
- Target 40-45% margins
- Goal: $2K-5K/month by Month 6

**Alternative Approach:** Design capsule collection for existing brand ($5K-15K upfront + 5-10% royalties) - less operational burden.

**Decision Point:** Leverages design/photo skills but requires ongoing time commitment. Is retail operations what Tim wants?

---

### 5. Dawn's Projects (Website + Job Hunt)

**Key Insight:** Tim's portfolio case study expertise directly helps Dawn

**Tim's Value-Add:**
- Template selection and Squarespace setup
- Case study positioning advice (knows how to frame Avalara/Fred Hutch/F5 work)
- Technical build and customization
- Mobile optimization and UX review
- Photography direction for professional assets

**Realistic Time Commitment:**
- Minimum: 13 hours (critical path only)
- Ideal: 23-25 hours over 8 weeks (3 hrs/week average, peak 6 hrs in Week 4)

**Critical Path for Tim:**
- Week 1: Template selection (4 hrs)
- Week 4: Technical build (6 hrs)
- Week 6: Mobile optimization and QA (2 hrs)

**Additional Support:**
- Intro Dawn to 2-3 Seattle content leads
- Share Dawn's site on LinkedIn when launched
- Provide context if Dawn interviews at Moby clients/partners

**ROI for Tim:**
- Portfolio piece for Studio Moser
- Skill practice (Squarespace for future clients)
- Network expansion (Dawn's contacts)
- Potential referrals back

---

## Strategic Recommendations for Tim

### Time Reality Check

**Current Commitments:**
- Moby, Inc (full-time as co-founder)
- Supernormal Games (indie game studio)
- Potentially Studio Moser launching
- Potentially helping Dawn
- Potentially building Ausra Photos or ebook reader or Shopify store

**Total Available Time for Side Projects:** Realistically 10-15 hours/week max

### Priority Matrix

**HIGHEST ROI (Revenue per Hour):**
1. **Studio Moser** - Fastest path to revenue ($50K-150K/year potential)
   - Uses existing skills and network
   - No product development risk
   - Can start generating income in 1-2 months
   - 2-3 select projects per quarter = manageable

**MODERATE ROI (Long-term Potential):**
2. **Supernormal Games** - Already committed, passion project
   - Keep as passion project, not income focus
   - 5-10 hours/week max
   - Long-term potential uncertain but personally fulfilling

3. **Dawn's Projects** - Relationship investment
   - 23-25 hours one-time over 8 weeks
   - Portfolio piece + network expansion
   - Worth doing if bandwidth available

**LOWEST ROI (High Risk/Time):**
4. **Ausra Photos** - Large market but extremely competitive
   - Would require 6-12 months part-time to MVP
   - Technical complexity high
   - Consider partnering vs. solo build

5. **Ebook Reader** - Similar challenges to Ausra Photos
   - Consider consulting vs. building

6. **Shopify Store** - Ongoing operations burden
   - Consider designing for existing brand vs. running store

### Recommended Focus

**Immediate (Next 3 Months):**
1. **Launch Studio Moser** - Simple portfolio site, tap Moby network, book 2-3 projects
2. **Help Dawn** - 3-4 hours/week for 8 weeks, website + job hunt support
3. **Continue Supernormal Games** - Maintain momentum, 5-10 hours/week

**Don't Start Yet:**
- Ausra Photos (unless finding technical partner)
- Ebook reader (unless consulting opportunity, not solo build)
- Shopify store (unless willing to commit to retail operations)

### The One-Project Rule

**Most successful entrepreneurs focus on ONE primary side project at a time.**

Tim should pick:
- **Studio Moser** (highest ROI, uses existing skills, fastest revenue)
- OR one of the product ideas (if truly passionate)
- NOT multiple product builds simultaneously while running Moby

---

## Pricing Power & Market Positioning

### What Tim Can Charge (Based on Experience)

**Studio Moser Day Rates:**
- Creative Direction: $1,500-2,500/day
- Brand Identity: $15,000-40,000 per project
- Product Design Direction: $20,000-50,000 per project
- Photography Direction: $5,000-15,000 per project

**Why These Rates:**
- 20+ years experience
- Fortune 500 portfolio
- 10 startups co-founded
- 25+ brands launched
- Enterprise-level expertise

**Don't Undercharge:**
- Tim isn't "freelancer seeking any work"
- Tim is "senior creative director available for select projects"
- Position accordingly, charge accordingly

---

## Competitive Advantages Summary

### What Makes Tim Unique

1. **Enterprise + Indie:** Both Fortune 500 experience AND indie game building
2. **Full-Stack Creative:** Design, development, photography, strategy
3. **Proven Builder:** 10 startups, 25+ brands - not theoretical
4. **Seattle Credibility:** 14 years building local reputation
5. **Technical Depth:** Can bridge design and development conversations
6. **User-Centered DNA:** Not just aesthetic - thoughtful product thinking

### Market Positioning

**Tim is not:**
- Generic freelance designer
- Junior developer learning on the job
- Typical agency creative without shipping experience

**Tim is:**
- Seasoned creative director with F500 portfolio
- Technical enough to ship products independently
- Entrepreneurial (10 startups prove it)
- Connected to Seattle creative ecosystem
- Multi-disciplinary (design, dev, photo, games, music)

---

## Key Contacts & Network

### Moby, Inc Network
- James Jacoby (co-founder/partner)
- 14 years of Moby employees and alumni
- Major clients: Microsoft, Disney, NPR, Fred Hutch, T-Mobile, Fisher-Price, Fox
- Seattle agency ecosystem

### Seattle Creative Community
- 14 years of conference attendance, meetups, events
- Seattle Interactive Conference connections
- Northwest College of Art alumni network
- Local design/dev community established presence

### Indie Game Community
- Supernormal Games audience
- Seattle Indies members
- PAX and game dev conference connections
- Indie game developer peers

### Photography Community
- Seattle photographers (through personal work)
- Can leverage for Studio Moser or Ausra Photos
- Visual creative community crossover

---

## Final Recommendations

### For Studio Moser
**Launch immediately** - You already have the portfolio and network. Just need to package it.

### For Product Ideas (Ausra, Ebook Reader, Shopify)
**Partner or consult, don't solo build** - Your strength is creative direction, not solo product development while running an agency.

### For Dawn's Projects
**Help if you have bandwidth** - 23 hours over 8 weeks is manageable and relationship-building.

### For Time Management
**Focus on ONE primary side project** - Studio Moser has highest ROI and plays to strengths.

---

## Sources & Research

- [Tim Moser LinkedIn Profile](https://www.linkedin.com/in/timmoser/)
- [Moby, Inc Website](https://mobyinc.com/)
- [Moby About Page](https://mobyinc.com/about)
- [Supernormal Games](https://supernormalgames.itch.io/)
- [Seattle Creative Community Research](https://www.seattlecreative.directory/)
- [Multi-Disciplinary Portfolio Examples](https://muz.li/blog/top-100-most-creative-and-unique-portfolio-websites-of-2025/)
- [Creative Director Portfolios 2026](https://www.sitebuilderreport.com/inspiration/creative-director-portfolios)

---

**Research completed by Shelby**
**February 11, 2026**

All 5 project strategies have been enhanced with Tim-specific insights, realistic scope, and comparable professionals analysis.
