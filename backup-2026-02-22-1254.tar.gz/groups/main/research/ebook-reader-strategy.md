# Ebook Reader App - Product Strategy & Market Research

**Prepared for:** Tim
**Date:** February 11, 2026
**Status:** Strategic Planning & Market Entry Analysis

---

## Executive Summary

The ebook reader market in 2026 is dominated by Amazon Kindle (79% US market share) but shows clear signs of diversification. Users are frustrated with closed ecosystems, poor library organization, slow software, and lack of AI-powered features. There's a significant opportunity for a modern, privacy-focused, cross-platform reader that combines the best of open-source flexibility with premium user experience and AI-powered reading enhancement.

**Key Opportunity:** Build a reader app that respects user autonomy, offers seamless cross-platform sync, provides AI-powered reading assistance without being intrusive, and prioritizes library management flexibility.

---

## 1. Market Analysis

### Current Market Landscape

**Market Size & Growth:**
- Global ebook market valued at $18.85 billion in 2026, projected to reach $23.6 billion by 2031 (4.6% CAGR)
- Subscription services hold 55.72% market share with reliable recurring revenue
- Mobile-first reading continues to dominate over dedicated e-readers
- Asia Pacific leads growth at 4.72% CAGR as smartphone penetration increases

**Major Players & Market Share:**

1. **Amazon Kindle** - 79% US market share
   - Dominant platform with extensive ecosystem
   - Recently launched AI "Recaps" feature (April 2025) for series summaries
   - Strong vendor lock-in through proprietary formats
   - Subscription: Kindle Unlimited

2. **Apple Books** - ~5% US market share
   - iOS/macOS integration advantage
   - Limited customization but seamless ecosystem
   - Premium positioning

3. **Kobo** - 10% e-reader device market, <3% US ebook market
   - Leading in Canada, France, Japan, and Australia
   - Open to EPUB format and library integrations
   - Subscription: Kobo Plus
   - Features "Reading Life" social reading experience

4. **Open-Source/Independent:**
   - **Calibre** - Most feature-rich library management but dated UI
   - **BookFusion** - Modern cross-platform with Calibre sync
   - **Readest** - Modern UI, AI summaries, cross-platform including web
   - **Libby** - Library-focused with excellent series organization
   - **Koodo Reader** - Open-source, cloud sync via Dropbox/WebDAV

**Key Market Trends:**
- Subscription models increasingly dominant (Kindle Unlimited, Scribd, Kobo Plus)
- AI integration for personalization, summaries, and reading assistance
- Mobile-first reading shifting away from dedicated e-readers
- Regional players eroding Amazon's monopoly
- Growing demand for cross-platform synchronization
- Privacy concerns around tracking and DRM

### What's Missing in the Market

Based on extensive research, current solutions fail to address:

1. **Flexible Library Organization** - Kindle's lack of user customization is the #1 complaint
2. **Modern Performance** - Most readers are "slow by today's standards"
3. **Seamless Import/Export** - File management remains painful across platforms
4. **AI That's Additive, Not Intrusive** - Users want AI features but without feeling manipulated
5. **Privacy-First Approach** - Growing concern over tracking and data collection
6. **Format Freedom** - DRM and proprietary formats create vendor lock-in
7. **Social Reading Done Right** - Readers want community without being forced into walled gardens
8. **Mood-Based Discovery** - Better personalization beyond simple algorithms

---

## 2. User Pain Points & Opportunities

### Critical Pain Points (Validated by User Research)

**Library Management Issues:**
- Inability to organize library in customized ways
- No flexibility in sorting, tagging, or creating custom collections
- Poor series organization (Libby does this better than Kindle)
- Difficult to find books in large libraries

**Performance & Technical Problems:**
- Slow software performance on modern devices
- PDF files crash or load forever in reading apps
- Apps can't handle large ebooks properly
- Import/export functionality is frustratingly slow

**Content & Format Limitations:**
- Apps can't differentiate article text from ads
- Limited format support creates friction
- No seamless switching between ebook and audiobook formats
- Export features often fail or crash apps

**Monetization Frustrations:**
- Previously free features moved behind paywalls
- Users feel "squeezed" by predatory subscription tactics
- Lack of transparency in pricing changes

**Discovery & Personalization:**
- Algorithm recommendations feel generic
- No mood-based recommendations
- Human recommendations still preferred over AI (2026 State of Reading Report)
- Limited discovery beyond mainstream titles

### Untapped Opportunities

1. **AI-Powered Reading Enhancement:**
   - Personalized difficulty adaptation
   - Multimodal learning (text + audio + visual)
   - Real-time comprehension assistance
   - Smart summaries without spoiling
   - Vocabulary building based on reading level

2. **Cross-Platform Excellence:**
   - True seamless sync across ALL devices (iOS, Android, web, desktop)
   - Reading position, highlights, notes, bookmarks all in sync
   - Integration with note-taking apps (Obsidian, Notion, Roam)
   - Unified library regardless of device

3. **Privacy-First Architecture:**
   - No tracking or surveillance
   - Local-first with optional cloud sync
   - DRM-free focus
   - User owns their data and annotations
   - Transparent about what data is collected

4. **Community & Social Reading:**
   - Book clubs and reading circles
   - Share highlights and annotations with friends
   - Discussion threads on specific passages
   - Reader reviews that feel authentic, not manipulated

5. **Advanced Library Management:**
   - Unlimited custom collections and tags
   - Smart collections based on rules
   - Series tracking with auto-organization
   - Reading statistics and insights
   - Calibre integration for power users

---

## 3. Competitive Differentiation Strategy

### Core Value Proposition

**"Your library, your way. Reading reimagined with AI that enhances, not interrupts."**

### Key Differentiators

**1. Library-First Philosophy**
- Most flexible organization system on the market
- Smart collections that auto-update based on reading patterns
- Visual library views (grid, list, shelf, timeline)
- Tag taxonomy that makes sense to readers
- Perfect series management with reading order

**2. AI Reading Companion (Not Overlord)**
- Optional, contextual AI features
- Reading comprehension assistance on demand
- Smart chapter summaries without spoilers
- Vocabulary enhancement based on your level
- Mood-based recommendations using emotional intelligence
- "Show your work" - AI explains why it recommends things

**3. True Cross-Platform Freedom**
- Web, iOS, Android, macOS, Windows, Linux
- Progressive Web App (PWA) for universal access
- Offline-first architecture
- Real-time sync across all devices
- Export everything anytime (no lock-in)

**4. Privacy as Default**
- Local-first storage with optional cloud sync
- End-to-end encryption for cloud storage
- Zero tracking or surveillance
- Open about data practices
- GDPR compliant by design
- Option to self-host sync server

**5. Format Agnostic**
- EPUB, MOBI, AZW3, PDF, TXT, MD, HTML, FB2
- DRM-free focus (with clear explanation why)
- Import from Kindle, Apple Books, Kobo
- Export highlights to Markdown, CSV, PDF
- Convert between formats seamlessly

**6. Community Without Walls**
- Share reading lists without platform lock-in
- Book clubs with discussion threads
- Highlight sharing with attribution
- Public and private libraries
- Integration with Goodreads, LibraryThing, etc.

---

## 4. Naming Strategy

### Naming Criteria
- Short (under 12 characters)
- Memorable and brandable
- .com or .io domain available
- Not generic "eBook reader"
- Evokes reading, knowledge, or discovery
- Easy to pronounce globally
- Trademark-friendly

### Recommended Name Options

**1. READEST** ⭐ (Top Choice)
- **Rationale:** Modern, clean, suggests "read" + "best." Already used by an open-source project but could acquire or negotiate
- **Domain:** readest.com (may be available or acquirable)
- **Tagline:** "Read at your best"
- **Pros:** Short, memorable, suggests quality and reading
- **Cons:** May need to acquire from existing project

**2. INKWELL**
- **Rationale:** Classic literary reference, suggests depth and timelessness
- **Domain:** inkwell.io or getinkwell.com
- **Tagline:** "Where readers gather"
- **Pros:** Warm, literary, distinctive
- **Cons:** .com likely taken, may feel old-fashioned to some

**3. PAGEMARK**
- **Rationale:** Combines "page" + "bookmark," suggests organization and progress
- **Domain:** pagemark.io
- **Tagline:** "Mark your reading journey"
- **Pros:** Clear purpose, memorable, available domains
- **Cons:** Slightly longer, less emotional connection

**4. SHELF**
- **Rationale:** Simple, evokes personal library, one syllable
- **Domain:** shelf.io or getshelf.com
- **Tagline:** "Your personal library"
- **Pros:** Ultra-short, immediately understood, modern
- **Cons:** .com definitely taken, may be too generic

**5. LUMINA**
- **Rationale:** Suggests light, knowledge, illumination
- **Domain:** lumina.io or readlumina.com
- **Tagline:** "Illuminate your reading"
- **Pros:** Beautiful, sophisticated, globally pronounceable
- **Cons:** Used by many other products, may have trademark issues

**6. VERSO**
- **Rationale:** Publishing term for left-hand page, literary reference
- **Domain:** verso.io or getverso.com
- **Tagline:** "Every page, every device"
- **Pros:** Short, literary, elegant
- **Cons:** May not be immediately understood by general audience

**7. REED**
- **Rationale:** Short for "read," also a nature reference (calming)
- **Domain:** reed.io or reedr.com
- **Tagline:** "Simple, powerful reading"
- **Pros:** Ultra-short, memorable, multiple meanings
- **Cons:** .com taken, possible confusion with musical instrument/plant

### Recommended Approach
1. Check domain availability for top 3 choices
2. Run trademark searches
3. Test with 10-15 potential users for resonance
4. Secure .com if available, .io as alternative
5. Register social media handles immediately

---

## 5. Feature Recommendations

### MVP (Minimum Viable Product) - Phase 1

**Core Reading:**
- EPUB, MOBI, PDF support
- Beautiful, customizable reading interface
- Night mode, adjustable fonts, spacing, margins
- Highlights and notes (3 colors minimum)
- Bookmarks and reading progress

**Library Management:**
- Import books from files
- Basic collections (minimum 3 custom collections)
- Search by title, author, tags
- Grid and list views
- Reading status (want to read, reading, finished)

**Cross-Platform:**
- iOS app (priority #1 based on market)
- Web app (PWA)
- iCloud or user-owned cloud sync
- Export library to JSON/CSV

**AI Features (Light Touch):**
- Basic book recommendations based on reading history
- Reading statistics (pages per day, time spent)
- Chapter summaries on demand

### Phase 2 - Differentiation Features

**Advanced Library:**
- Unlimited custom collections
- Smart collections with rules
- Series tracking and organization
- Visual "shelf" view
- Tags with taxonomy
- Calibre import/sync

**Enhanced AI:**
- Mood-based recommendations
- Reading comprehension assistance
- Vocabulary builder
- Multi-book series summaries
- Reading insights and patterns

**Social Features:**
- Share highlights (public or private)
- Book clubs with discussion threads
- Friend recommendations
- Reading challenges

**Advanced Sync:**
- Android app
- Desktop apps (macOS, Windows, Linux)
- Self-hosted sync option
- Export to note apps (Obsidian, Notion)

### Phase 3 - Platform Maturity

**Advanced AI:**
- Adaptive reading difficulty
- Multimodal learning features
- Cross-book knowledge graph
- Audiobook integration with seamless switching
- AI reading companion (ask questions about the book)

**Community Platform:**
- Public libraries and lists
- Author connections
- Reading events and challenges
- Integration with Goodreads, LibraryThing

**Advanced Features:**
- Format conversion tools
- Annotation export in multiple formats
- Advanced statistics and analytics
- Reading goals with gamification
- Speed reading tools

**Enterprise/Education:**
- Classroom management features
- Group licenses
- Administrative controls
- Learning analytics

---

## 6. Positioning Strategy

### Target Audiences (Priority Order)

**1. Power Readers (Primary)**
- Read 20+ books per year
- Own 100+ ebooks across multiple platforms
- Frustrated with current organization tools
- Value flexibility and customization
- Willing to pay for quality tools
- Age: 25-55, skews slightly female
- Income: $60k+

**2. Privacy-Conscious Users (Secondary)**
- Concerned about data tracking
- Prefer open-source or transparent alternatives
- Value DRM-free content
- Want to own their digital library
- Often tech-savvy
- Age: 30-50, skews male

**3. Cross-Platform Users (Secondary)**
- Use multiple devices daily
- Frustrated with platform lock-in
- Need seamless sync
- Read on phone, tablet, laptop, e-reader
- Professional knowledge workers
- Age: 25-45, balanced gender

**4. Students & Lifelong Learners (Tertiary)**
- Read for learning, not just entertainment
- Take extensive notes
- Need to reference and organize research
- Want integration with note-taking tools
- Age: 18-40, balanced gender

### Positioning Statement

**For power readers who are frustrated with inflexible library management and platform lock-in, [Product Name] is a modern ebook reader that gives you complete control over your digital library with AI-powered enhancements that feel helpful, not intrusive. Unlike Kindle which traps you in a walled garden, or Calibre which feels outdated, [Product Name] combines beautiful design, flexible organization, and true cross-platform freedom.**

### Brand Voice & Personality

- **Respectful:** We treat readers as intelligent adults, not data points
- **Empowering:** Your library, your rules, your data
- **Modern:** Contemporary design without sacrificing function
- **Transparent:** Honest about what we do and why
- **Literary:** We love books and reading culture
- **Innovative:** Embracing new technology thoughtfully

### Key Messaging Pillars

1. **"Your Library, Your Way"** - Emphasize flexibility and customization
2. **"Reading Without Walls"** - Cross-platform freedom and no lock-in
3. **"AI That Enhances, Not Interrupts"** - Thoughtful AI integration
4. **"Privacy by Design"** - User data respect and transparency
5. **"Made for Readers, By Readers"** - Community-driven development

---

## 7. Monetization Strategy

### Recommended Model: Freemium with Premium Subscription

**Why This Model:**
- Aligns with 2026 market expectations (subscription services hold 55.72% market share)
- Allows users to try before committing
- Provides recurring revenue for sustainable development
- Offers flexibility for different user needs
- Balances accessibility with premium features

### Pricing Tiers

**FREE TIER - "Reader"**
- Core reading experience (EPUB, MOBI, PDF)
- Basic highlights and notes (1 color)
- Up to 3 custom collections
- Cloud sync for up to 100 books
- iOS and web access
- Basic statistics

**Value:** Provides genuine utility, not crippled experience. Converts users who discover they need more organization.

**PREMIUM TIER - "Bibliophile"**
- **Monthly: $6.99**
- **Annual: $59.99** (Save 29% - $5/month)
- Unlimited books and collections
- Unlimited highlights and notes (all colors + tags)
- Advanced library organization (smart collections, series tracking)
- All platforms (iOS, Android, web, desktop)
- Priority cloud sync
- Export to all formats (Markdown, CSV, PDF)
- AI reading features (summaries, recommendations, vocabulary)
- Reading insights and analytics
- Integration with note-taking apps (Obsidian, Notion)

**LIFETIME PLAN - "Collector"**
- **One-time: $249**
- All Premium features forever
- Early access to new features
- Support indie development
- No recurring fees ever
- Priority support

**Value:** Targets power readers who will save money long-term and provides significant upfront capital for development.

### Additional Revenue Streams

**1. Enterprise/Education License**
- **$299/year** for up to 50 users
- Classroom management features
- Group licensing and administration
- Learning analytics
- Priority support and training

**2. Self-Hosted Sync Server**
- **$99 one-time** license for self-hosted sync
- Docker container for easy deployment
- Full privacy control
- For technical users and institutions

**3. Professional Services**
- Library migration service ($49-$99 one-time)
- Custom import/export development
- Calibre integration consulting

**4. Partner Integrations (Future)**
- Affiliate partnerships with DRM-free bookstores
- Referral fees (ethical, transparent)
- Integration partnerships with Obsidian, Notion, etc.

### Pricing Strategy Details

**Free Trial Approach:**
- 14-day free trial of Premium (no credit card required)
- After trial, graceful degradation to Free tier
- Clear communication of what changes
- One-click upgrade anytime

**Annual Discount Rationale:**
- 29% discount encourages annual commitment
- Reduces churn significantly (60-75% retention at year one)
- Provides working capital for development
- Industry standard discount rate

**Student Discount:**
- 50% off Premium ($29.99/year)
- Verification via student email or third-party service
- Builds long-term user base

**Transparency Commitment:**
- Never remove features from free tier
- Never surprise price increases
- Always offer legacy pricing to existing subscribers
- Clear communication about what premium features enable

### Revenue Projections (Conservative)

**Year 1 Goals:**
- 10,000 registered users
- 5% conversion to Premium = 500 paid users
- Average revenue per paid user: $60 (mix of monthly, annual, lifetime)
- MRR: $2,500 (500 × $5 average monthly equivalent)
- ARR: $30,000
- 25 Lifetime purchases: $6,225
- **Total Year 1 Revenue: ~$36,000**

**Year 2 Goals:**
- 50,000 registered users
- 8% conversion to Premium = 4,000 paid users
- MRR: $20,000
- ARR: $240,000
- 100 Lifetime purchases: $24,900
- **Total Year 2 Revenue: ~$265,000**

**Year 3 Goals:**
- 150,000 registered users
- 10% conversion to Premium = 15,000 paid users
- MRR: $75,000
- ARR: $900,000
- **Total Year 3 Revenue: ~$900,000+**

*Note: These are conservative estimates. Successful execution could yield 2-3x these numbers.*

---

## 8. Go-to-Market Strategy

### Phase 1: Soft Launch (Months 1-3)

**Objective:** Validate product-market fit with early adopters

**Tactics:**
1. **Private Beta** (Month 1)
   - Invite 100 power readers (friends, network, indie hackers)
   - Collect detailed feedback
   - Iterate rapidly on core experience

2. **Public Beta** (Month 2-3)
   - Launch on Product Hunt
   - Post in r/ebooks, r/kindle, r/ereaders
   - Indie Hackers showcase
   - HackerNews Show HN
   - Focus on iOS + Web only

3. **Early Adopter Pricing**
   - Lifetime plan at $149 (limited to first 500)
   - Annual at $49 (first year, then $59.99)
   - Build passionate core community

**Success Metrics:**
- 1,000 registered users
- 100 paid users
- 4+ star average rating
- 50+ detailed feedback submissions
- Net Promoter Score (NPS) > 40

### Phase 2: Product Launch (Months 4-6)

**Objective:** Reach power reader community and achieve product-market fit

**Tactics:**
1. **Content Marketing**
   - Launch blog with ebook organization tips
   - "How to leave Kindle" migration guides
   - Reading productivity content
   - SEO optimization for "best ebook reader" searches

2. **Community Building**
   - Create Discord or Slack community
   - Weekly AMAs with founder
   - User showcase spotlights
   - Reading challenges

3. **Platform Expansion**
   - Launch Android app
   - Desktop apps (macOS, Windows)
   - Calibre integration

4. **PR & Outreach**
   - Pitch to The Verge, TechCrunch, 9to5Mac
   - Book YouTubers and podcasts
   - Literary bloggers and BookTube
   - Reach out to Cortex podcast (productivity focused)

**Success Metrics:**
- 10,000 registered users
- 500 paid users
- Featured in 3+ tech publications
- 1,000+ App Store downloads
- NPS > 50

### Phase 3: Growth (Months 7-12)

**Objective:** Scale to 50,000 users and establish sustainable growth

**Tactics:**
1. **Paid Acquisition** (if metrics support)
   - Reddit ads in r/books, r/ebooks
   - Google Search ads for "ebook reader" queries
   - Facebook/Instagram ads targeting book lovers
   - Podcast sponsorships (literary podcasts)

2. **Partnership Development**
   - Integrate with DRM-free bookstores
   - Partner with indie publishers
   - Library partnerships (public libraries)
   - Note-taking app partnerships (Obsidian, Roam)

3. **Viral Loops**
   - "Import your Kindle library" social sharing
   - Referral program (give 1 month free, get 1 month free)
   - Book club invitations
   - Shared reading lists

4. **Feature Expansion**
   - Launch Phase 2 features (AI enhancements, social)
   - Regular updates and improvements
   - User-requested features

**Success Metrics:**
- 50,000 registered users
- 4,000 paid users ($20k MRR)
- 30% month-over-month user growth
- <5% monthly churn
- 4.5+ star average rating

### Distribution Channels (Priority Order)

1. **Product Hunt** - Tech early adopters, high visibility
2. **App Store & Google Play** - Primary discovery
3. **Reddit Communities** - r/ebooks, r/kindle, r/ereaders, r/books
4. **HackerNews** - Technical audience, privacy-conscious users
5. **Indie Hackers** - Maker community, early adopters
6. **Tech Blogs** - The Verge, TechCrunch, 9to5Mac, AppleInsider
7. **Book YouTube & Podcasts** - BookTube, literary podcasts
8. **SEO/Content Marketing** - Long-term organic traffic
9. **Social Media** - Twitter/X (book community), Instagram (bookstagram)
10. **Word of Mouth** - Most sustainable long-term channel

---

## 9. Technical Considerations

### Recommended Tech Stack

**Frontend:**
- React Native or Flutter for iOS/Android (single codebase)
- React/Next.js for web app (PWA capable)
- Electron for desktop apps (reuse web code)

**Backend:**
- Node.js/Express or Go for API
- PostgreSQL for structured data (user accounts, metadata)
- S3-compatible storage for ebook files
- Redis for caching and sync coordination

**Sync Architecture:**
- Conflict-free Replicated Data Types (CRDTs) for annotations
- Delta sync to minimize bandwidth
- End-to-end encryption option
- Local-first with eventual consistency

**AI/ML:**
- OpenAI API for summaries and recommendations (initially)
- Fine-tuned models for book-specific tasks (later)
- On-device ML for privacy-sensitive features (Apple CoreML)

**Infrastructure:**
- AWS or DigitalOcean for hosting
- CloudFlare for CDN and DDoS protection
- Docker for containerization
- Terraform for infrastructure as code

### Development Roadmap

**MVP (3-4 months):**
- iOS app with core reading features
- Web app (PWA) with basic library management
- Cloud sync (basic)
- User authentication
- EPUB and PDF support

**Phase 2 (2-3 months):**
- Android app
- Enhanced library features (smart collections)
- AI features (summaries, recommendations)
- Export features
- Calibre sync

**Phase 3 (3-4 months):**
- Desktop apps
- Social features
- Advanced AI features
- Self-hosted sync option
- Note-taking app integrations

### Privacy & Security Priorities

- GDPR compliant by design
- End-to-end encryption for sensitive data
- Local-first architecture (works offline)
- Transparent data practices (published privacy policy)
- No tracking or analytics without consent
- Option to self-host for full control
- Regular security audits
- Bug bounty program (when ready)

---

## 10. Competitive Analysis Summary

### Direct Competitors

| Competitor | Strengths | Weaknesses | Opportunity Gap |
|-----------|-----------|-----------|----------------|
| **Amazon Kindle** | Huge library, ecosystem, Kindle Unlimited | Walled garden, poor organization, slow software, tracking | Privacy, flexibility, cross-platform |
| **Apple Books** | iOS integration, beautiful design | Limited to Apple ecosystem, poor customization | Cross-platform, organization |
| **Kobo** | Open formats, library integration | Smaller ecosystem, less polished app | Modern UI, AI features |
| **Calibre** | Most powerful features, open source | Dated UI, desktop-only, steep learning curve | Modern mobile experience |
| **BookFusion** | Cross-platform, Calibre sync | Limited AI features, less known | Marketing, AI features |
| **Readest** | Modern UI, AI features, open source | New, limited adoption, lacks polish | Go-to-market, community |

### Competitive Advantages

**What We Do Better:**
1. **Library flexibility** - More than Kindle, simpler than Calibre
2. **Privacy-first** - Unlike Kindle/Apple tracking
3. **Cross-platform** - True seamless experience (not just "available" on multiple platforms)
4. **AI integration** - More thoughtful than Amazon's Recaps, less intrusive
5. **User ownership** - Export everything, no lock-in
6. **Modern design** - Better than Calibre, more flexible than Apple

**What We Can't Compete On (Yet):**
- Integrated bookstore (Kindle, Apple, Kobo have this)
- Subscription book access (Kindle Unlimited, Kobo Plus)
- Hardware devices (Kindle, Kobo make e-readers)
- Brand recognition (all established players)

**Strategic Response:**
- Focus on library management and reading experience, not selling books
- Partner with DRM-free stores rather than build our own
- Support all formats so users can get books anywhere
- Build passionate community of power readers

---

## 11. Risk Analysis & Mitigation

### Key Risks

**1. Amazon Competition**
- **Risk:** Kindle could copy features or improve organization
- **Likelihood:** Medium
- **Impact:** High
- **Mitigation:** Move fast, build loyal community, focus on privacy differentiation (Amazon won't do this), emphasize cross-platform and user ownership

**2. Low Conversion Rates**
- **Risk:** Users love free tier but don't upgrade
- **Likelihood:** Medium-High
- **Impact:** High
- **Mitigation:** Ensure free tier has clear limitations but isn't crippled; make premium features genuinely valuable; focus on power readers who need organization

**3. Technical Complexity**
- **Risk:** Cross-platform sync is hard, ebook parsing is complex
- **Likelihood:** High
- **Impact:** Medium
- **Mitigation:** Start with iOS + Web only, use proven libraries (epub.js), hire experienced mobile developers, iterate based on feedback

**4. Privacy Regulation Changes**
- **Risk:** GDPR/privacy laws become more strict
- **Likelihood:** Medium
- **Impact:** Low (positive for us)
- **Mitigation:** We're privacy-first by design, this actually helps differentiation

**5. Market Saturation**
- **Risk:** Users are content with current solutions
- **Likelihood:** Low
- **Impact:** High
- **Mitigation:** User research shows clear frustration with current tools; focus on power readers who feel pain most acutely

**6. Funding/Runway**
- **Risk:** Takes longer to achieve product-market fit than expected
- **Likelihood:** Medium
- **Impact:** High
- **Mitigation:** Bootstrap initially, focus on early revenue through lifetime deals, keep team small, consider grants/accelerators if needed

### Success Factors

**Must Have:**
1. Beautiful, fast reading experience
2. Reliable cross-platform sync
3. Flexible library organization
4. Strong privacy guarantees
5. Easy import from Kindle/Apple/Kobo

**Nice to Have:**
1. AI features (can add later)
2. Social features (can add later)
3. Desktop apps (can add later)
4. Calibre integration (can add later)

---

## 12. Immediate Next Steps

### Week 1-2: Validation & Planning
- [ ] Survey 20-30 power readers about pain points (Reddit, personal network)
- [ ] Create detailed user personas with real quotes
- [ ] Validate pricing with potential users (what would you pay?)
- [ ] Check domain availability for top 3 name choices
- [ ] Conduct trademark search for chosen name
- [ ] Sketch core UI/UX flows (reading, library, sync)

### Week 3-4: Brand & Design Foundation
- [ ] Finalize name and register domains
- [ ] Create brand identity (logo, colors, typography)
- [ ] Design high-fidelity mockups for MVP
- [ ] Write detailed technical specification
- [ ] Set up development environment
- [ ] Create project roadmap with milestones

### Month 2-3: MVP Development
- [ ] Build iOS app with basic reading features
- [ ] Build web app with library management
- [ ] Implement basic cloud sync
- [ ] Add EPUB and PDF support
- [ ] Create user authentication
- [ ] Set up analytics (privacy-respecting)

### Month 4: Private Beta
- [ ] Invite 100 beta users
- [ ] Collect detailed feedback through interviews
- [ ] Iterate on core experience
- [ ] Fix critical bugs
- [ ] Improve onboarding flow
- [ ] Test import from Kindle/Apple

### Month 5-6: Public Launch Prep
- [ ] Polish UI/UX based on beta feedback
- [ ] Create landing page and marketing site
- [ ] Write App Store listing and screenshots
- [ ] Prepare Product Hunt launch
- [ ] Create initial content (blog posts, guides)
- [ ] Set up customer support system

### Month 6: Launch
- [ ] Submit to App Store
- [ ] Launch on Product Hunt
- [ ] Post on Reddit, HackerNews, Indie Hackers
- [ ] Reach out to tech press
- [ ] Monitor feedback and respond quickly
- [ ] Begin iterating based on user input

---

## 13. Success Metrics & KPIs

### North Star Metric
**Weekly Active Readers** - Users who open the app and read for 10+ minutes per week

### Key Performance Indicators

**Acquisition:**
- New user registrations per week
- App Store downloads
- Website visitors and conversion rate
- Viral coefficient (referrals per user)

**Activation:**
- % of users who import their first book
- % of users who read for 10+ minutes in first session
- Time to first highlight/note

**Engagement:**
- Daily/Weekly/Monthly active users
- Average session length
- Books read per user per month
- Highlights and notes created

**Retention:**
- Day 1, Day 7, Day 30 retention rates
- Monthly churn rate
- Cohort retention analysis

**Revenue:**
- Free to paid conversion rate
- Monthly Recurring Revenue (MRR)
- Average Revenue Per User (ARPU)
- Customer Lifetime Value (LTV)
- LTV:CAC ratio

**Satisfaction:**
- Net Promoter Score (NPS)
- App Store rating
- Customer support ticket volume
- Feature request frequency

### Target Metrics (End of Year 1)
- 10,000 registered users
- 500 paid users (5% conversion)
- $30,000 ARR
- 4.5+ App Store rating
- NPS > 50
- 40% Day 30 retention
- <5% monthly churn

---

## 14. Why This Will Win

### The Opportunity Is Real

User research consistently shows frustration with:
- Kindle's inflexibility and walled garden
- Apple's ecosystem lock-in
- Calibre's dated interface
- Lack of privacy in mainstream apps
- Poor cross-platform experiences

**Power readers are actively looking for alternatives but keep coming back to imperfect solutions because nothing better exists.**

### We Have Clear Differentiation

Unlike competitors, we offer:
1. **Best-in-class library management** (better than Kindle, easier than Calibre)
2. **True privacy respect** (unlike Amazon/Apple)
3. **Cross-platform excellence** (not just "available" but actually seamless)
4. **Modern, fast, beautiful** (not legacy software)
5. **User ownership** (export everything, no lock-in)

### The Market Is Growing

- $18.85B market in 2026, growing to $23.6B by 2031
- Subscription services showing strong growth (55.72% market share)
- Mobile-first reading increasing
- Asia Pacific growth at 4.72% CAGR
- Diversification away from Amazon's monopoly

### The Timing Is Right

- Amazon's 2026 DRM-free changes show market pressure for openness
- AI reading features are becoming expected (Amazon launched Recaps in 2025)
- Privacy concerns are mainstream (GDPR, user awareness)
- Cross-platform expectations are higher than ever
- Open-source alternatives prove there's hunger for freedom

### Sustainable Business Model

- Freemium aligns with user expectations
- Premium tier targets power readers who will pay
- Lifetime plan provides upfront capital
- Path to profitability clear with conservative metrics
- Multiple revenue streams possible long-term

### Founder-Market Fit

Tim (presumably) is building this because he's frustrated with current solutions - classic founder-market fit. The best products come from scratching your own itch.

---

## 15. Final Recommendations

### Top 3 Priorities for Success

**1. Nail the Core Reading Experience**
- Everything else is secondary to beautiful, fast, reliable reading
- Import must be painless (users won't switch if migration is hard)
- Library organization must be dramatically better than Kindle
- Sync must work flawlessly (users will churn if they lose annotations)

**2. Build for Power Readers First**
- Don't try to compete with Kindle for casual readers
- Focus on people who read 20+ books/year and feel real pain
- These users will pay for quality tools
- They're your evangelists to reach others

**3. Privacy as Genuine Differentiator**
- Don't just say you respect privacy - prove it
- Open source parts of the code
- Publish transparent data practices
- Offer self-hosting option
- Make this a core part of brand identity

### Recommended Next Action

**Decision Point: Choose Your Name This Week**

Run a quick survey with 10-15 potential users:
- Show them 3-5 name options
- Ask which they'd be most likely to recommend
- Check if they understand what the product does
- Validate pricing expectations

Then:
1. Register domains and social media handles
2. Create basic landing page with email signup
3. Start collecting interested users before you build
4. Target: 100 email signups before writing code

### The Path Forward

This market has room for a thoughtful, well-executed reader app that respects users and delivers a premium experience. Success requires:

- **Focus:** Do a few things exceptionally well rather than many things poorly
- **Speed:** Ship MVP in 3-4 months, iterate based on feedback
- **Community:** Build with power readers, not in isolation
- **Sustainability:** Focus on revenue from day one, not just growth
- **Values:** Let privacy and user ownership guide every decision

The opportunity is real. The market is ready. The technology exists. Now it's about execution.

---

## Research Sources

### Market Analysis
- [Ebook Market Share, Size, Trends & Industry Analysis](https://www.mordorintelligence.com/industry-reports/e-book-market)
- [Ebook Market Size, Share, Trends & Forecast 2032](https://www.skyquestt.com/report/ebook-market)
- [E Book Market Size Forecast |Growth at 6.1% CAGR](https://www.businessresearchinsights.com/market-reports/e-book-market-117774)
- [E-Reader Market Share, Size & Growth Outlook to 2030](https://www.mordorintelligence.com/industry-reports/e-reader-market)
- [Ebook Market Share, Size, Growth & Trend, 2034](https://www.fortunebusinessinsights.com/ebook-market-111315)
- [Kobo vs. Kindle vs. Apple Books vs. Libby: Which Book App Is Best for You?](https://twit.tv/posts/tech/kobo-vs-kindle-vs-apple-books-vs-libby-which-book-app-best-you)
- [Best ereaders in 2026: 9 top ebook readers from Kindle, Kobo and more](https://www.techradar.com/best/best-ereader)
- [100+ Ebook statistics for 2026](https://whop.com/blog/ebook-statistics/)
- [eBook Market Share: Amazon, Apple and Kobo](https://booksliced.com/books/the-exact-ebook-market-shares-of-the-major-players-in-the-industry-are-rather-difficult-to-come-by-but-here-are-some-esitmates/)
- [E-Readers Statistics By Geography, Demographics, Genres and Users](https://coolest-gadgets.com/e-readers-statistics/)

### User Pain Points
- [eBook readers: user satisfaction and usability issues](https://pages.gseis.ucla.edu/faculty/richardson/ebook.pdf)
- [2025 Has Been a Down Year for New eReaders](https://blog.the-ebook-reader.com/2025/09/11/2025-has-been-a-down-year-for-new-ereaders/)
- [(PDF) "eBook Readers: User Satisfaction and Usability Issues"](https://www.researchgate.net/publication/220364253_eBook_Readers_User_Satisfaction_and_Usability_Issues)

### AI & Innovation Trends
- [The Future of Reading How AI is Changing the Way We Consume Books](https://blog.bookautoai.com/future-of-reading-ai/)
- [Learn Your Way: Reimagining textbooks with generative AI](https://research.google/blog/learn-your-way-reimagining-textbooks-with-generative-ai/)
- [Building Adaptive E-Books with AI](https://hyperspace.mv/adaptive-e-books/)
- [Top 10 Publishing Trends 2026](https://www.luminadatamatics.com/resources/blog/top-10-publishing-trends-to-watch-out-for-in-2026/)
- [How AI is Crafting Personalized Books Tailored to Your Reading Habits](https://festivaltopia.com/how-ai-is-crafting-personalized-books-tailored-to-your-reading-habits/)
- [The Future of Reading: How AI is Changing Ebooks](https://goodereader.com/blog/e-book-news/the-future-of-reading-how-ai-is-changing-ebooks)
- [AI Innovations in E-Readers: 2025 Trends and Predictions](https://goodereader.com/blog/electronic-readers/ai-innovations-in-e-readers-2025-trends-and-predictions)
- [The 2026 State of Reading Report](https://www.kitv.com/online_features/press_releases/the-2026-state-of-reading-report-human-recommendations-surpass-algorithms-in-the-ai-era/article_1613d344-25d4-5d74-aaa8-97dea8627bd6.html)

### Open Source Alternatives
- [Best Calibre Alternatives of 2026](https://technicalwall.com/alternatives/best-calibre-alternatives/)
- [Best Open Source Windows eBook Readers 2026](https://sourceforge.net/directory/ebook-readers/)
- [Top 5 Calibre Alternatives](https://bookrunch.com/news/top_5_calibre_alternatives/)
- [Slant - 20 best alternatives to Calibre as of 2026](https://www.slant.co/options/8505/alternatives/~calibre-alternatives)
- [Show HN: Citadel – a Calibre-compatible eBook management app](https://news.ycombinator.com/item?id=38988019)

### Monetization Strategies
- [12 Best Mobile App Monetization Strategies for 2026](https://adapty.io/blog/mobile-app-monetization-strategies/)
- [10 Mobile App Monetization Strategies That Actually Work in 2026](https://videoflicks.com/technology/mobile-app-monetization-strategies-2026/)
- [10 Proven Mobile App Monetization Strategies for 2026](https://www.adworkly.co/blog/mobile-app-monetization-strategies)
- [How to Monetize Ebooks and Audiobooks in Your App](https://www.audiorista.com/blog/how-to-monetize-ebooks-and-audiobooks-in-your-app)
- [Software Monetization Models and Strategies for 2026](https://www.getmonetizely.com/articles/software-monetization-models-and-strategies-for-2026-the-complete-guide)

### Naming & Branding
- [2026 domain name trends to power your brand online](https://get.it.com/blog/2026-domain-name-trends/)
- [Brandable Domain Names | BrandBucket](https://www.brandbucket.com/brandable-domain-names)
- [Best App Name Generator That Uses AI in 2026](https://namify.tech/app-name-generator)
- [Business Name Generator - Namelix](https://namelix.com/)
- [One Word Domains - Database of available one-word domains](https://oneword.domains/)
- [12 Types of Cool Domain Names That Actually Work in 2025](https://namesnag.com/blog/cool-domain-names)

### Cross-Platform Features
- [Top 9 Cross-Platform eBook Readers for 2025](https://kitaboo.com/9-best-cross-platform-ebook-readers/)
- [BookFusion - Read, share, organize, bookmark and sync](https://www.bookfusion.com/)
- [GitHub - readest/readest](https://github.com/readest/readest)
- [5+ best cross-platform eBook readers](https://windowsreport.com/cross-platform-ebook-readers/)
- [Readwise Reader | The first read-it-later app built for power readers](https://readwise.io/read)

### Privacy & DRM
- [Digital Rights Management - Amazon KDP](https://kdp.amazon.com/en_US/help/topic/GDDXGH9VR22ACM8U)
- [Amazon changes how copyright protection is applied to Kindle Direct's ebooks](https://techcrunch.com/2025/12/10/amazon-changes-how-copyright-protection-is-applied-to-kindle-directs-self-published-ebooks/)
- [Amazon's 2026 DRM Update for Authors](https://pandapublishing.agency/blog/amazon-2026-drm-update-guide-authors/)
- [Amazon is Allowing EPUB & PDF Downloads for DRM-Free Kindle Books](https://kindlepreneur.com/amazon-drm-epub-downloads/)
- [Guide to DRM-Free Living: Literature](https://www.defectivebydesign.org/guide/ebooks)
- [Amazon Has Started Selling (Some) DRM-Free Kindle E-Books](https://www.popularmechanics.com/technology/gear/a70188796/kindle-books-drm-free-option-2026/)

---

*Report prepared February 11, 2026*
*For questions or follow-up analysis, contact Shelby*

---

## ENHANCED STRATEGY BASED ON TIM'S PROFILE

### How Tim's Moby Experience Applies to Ebook Reader

**Directly Relevant Skills:**
- **Mobile app development** (iOS/Android) from Moby's 14 years
- **User-centered design** philosophy perfect for reading UX
- **Cross-platform experience** (Moby built for all platforms)
- **Enterprise product thinking** (Microsoft, NPR) brings rigor
- **Indie game background** (Supernormal Games) = consumer app experience

**Why This Project Fits Tim:**
1. Reading apps need excellent UX (Tim's specialty)
2. Cross-platform is technically complex (Tim has done it)
3. Privacy positioning aligns with user-centered values
4. Large market + clear differentiation opportunity
5. Can leverage both enterprise thinking + indie execution

### Comparable Professionals Who've Built Similar Products

**Designers Who Became App Founders:**
- **David Smith** (Widgetsmith) - Apple designer turned indie developer
- **Matthew Palmer** (Vanilla, Rocket) - Designer/developer hybrid
- **Christian Selig** (Apollo for Reddit) - Solo designer/developer

**What They Did Right:**
1. **Focus on Apple ecosystem** (where they had expertise)
2. **Launch minimal, iterate fast** (shipped imperfect MVPs)
3. **Build in public** (Twitter, blogs showing progress)
4. **Leverage design as differentiator** (beautiful apps stand out)
5. **Freemium model** (free tier drove downloads, premium converted)

### Realistic Scope for Tim (10-15 hrs/week)

**6-Month MVP Plan:**

**Months 1-2: iOS Reading Core**
- EPUB reader only (skip MOBI, PDF initially)
- Basic reading interface (font, size, colors)
- Simple library (import from Files app)
- Local storage only (no sync)

**Months 3-4: Organization Features**
- Collections (3 max in free, unlimited in paid)
- Search (basic text search)
- Highlights (1 color free, all colors paid)
- Reading stats (pages/day, time spent)

**Months 5-6: Launch Prep**
- Polish UX (Tim's strength)
- App Store assets (screenshots, description)
- Beta testing with Seattle network
- Soft launch to Moby contacts

**What to Skip Initially:**
- Android app (add later if iOS succeeds)
- Desktop apps (not critical for MVP)
- AI features (expensive, complex)
- Social features (not differentiator)
- Cloud sync (too complex for MVP)

### Go-to-Market Using Tim's Assets

**Phase 1: Seattle Network (Month 5)**
- Moby employees and clients as beta users
- Seattle tech community (Product Hunt Seattle)
- Former colleagues from 14 years of work
- Photography friends (cross-promote with Studio Moser)

**Phase 2: Design Community (Month 6-7)**
- Dribbble, Behance portfolio showcasing design
- "From Creative Director at Moby" credibility
- Designer-focused launch angle
- Beautiful UI as differentiator in marketing

**Phase 3: Indie Community (Month 7-8)**
- Product Hunt (leverage Supernormal Games network)
- Indie Hackers showcase
- Hacker News Show HN
- r/ebooks, r/apple, r/privacy

**Pricing for Tim's Launch:**
- Free: 100 books, basic features
- Premium: $4.99/month or $49/year
- Lifetime: $149 (early adopters)
- Goal: 500 paid users in 6 months = $2K-4K MRR to validate

### Key Advantages Tim Brings

1. **Design Excellence:** Premium feel from day one
2. **UX Expertise:** Reading experience will be delightful
3. **Technical Chops:** Can actually build cross-platform
4. **Network:** 14 years of contacts for beta testing
5. **Portfolio:** Moby work as credibility signal

### Should Tim Build This vs. Other Projects?

**Ebook Reader Project:**
- **Time to First Revenue:** 6-9 months
- **Competitive Intensity:** High (Kindle dominates)
- **Technical Complexity:** Medium-High
- **Income Potential:** $50K-200K/year (if successful)
- **Passion Factor:** ?

**vs. Studio Moser:**
- **Time to First Revenue:** 1-2 months
- **Competitive Intensity:** Medium
- **Technical Complexity:** Low (use existing skills)
- **Income Potential:** $50K-150K/year
- **Passion Factor:** High (creative freedom)

**vs. Supernormal Games:**
- **Time to First Revenue:** 12+ months
- **Competitive Intensity:** Very High
- **Technical Complexity:** High
- **Income Potential:** Uncertain (could be $0 or $100K+)
- **Passion Factor:** High (already committed)

**RECOMMENDATION:**
Focus on Studio Moser for fastest ROI, keep Supernormal Games as passion project. Only build ebook reader if you're specifically passionate about reading tech.

### Alternative Approach: Design Consulting for Existing Reader

Rather than build from scratch, Tim could:
1. **Offer to redesign existing reader** (Readwise, Koodo, etc.)
2. **Get paid upfront** ($20K-50K consulting)
3. **Negotiate equity stake** (5-10% if they're interested)
4. **Less risk, faster return** than solo building

**This leverages Tim's actual strength:** Premium design direction for existing products, not building from scratch.

---

**Bottom Line for Tim:** Great market opportunity, but building solo while running Moby is extremely hard. Consider partnering or consulting instead of solo build.
