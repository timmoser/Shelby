# Studio Moser: Complete Creative Identity Strategy

**Prepared for:** Tim Moser @ Studio Moser
**Date:** February 11, 2026
**Updated Context:** Multi-faceted creator site covering Design, Photography, Products, and Projects
**Location:** Seattle, WA

---

## Executive Summary

Studio Moser is NOT just a design portfolio. It's Tim's complete slice of the internet covering:
- Creative Direction / Design work (Moby Inc background)
- Photography portfolio and professional services
- Ongoing product projects (Ausra Photos, games, apps)
- Marketing vehicle for everything he creates

This requires a fundamentally different approach than a traditional portfolio. The research reveals successful patterns from "renaissance creatives" who manage multiple identities under one unified brand—designers who are also photographers, makers with portfolio + products + writing, and creators who span multiple disciplines.

The key opportunity: Position Studio Moser as Tim's unified creative platform where commercial work, personal projects, photography services, and product development all coexist under one cohesive brand.

---

## 1. RESEARCH: MULTI-FACETED CREATOR SITES (30+ Examples)

### Category A: Designer + Photographer Hybrids

#### 1. **Samuel Angibaud**
- **Site Structure:** Split-screen homepage separating design and photography disciplines
- **Navigation:** Clear entry points to each discipline with minimal overlap
- **What Works:** Immediate choice between "Design" and "Photography" without confusion
- **URL:** [Photography Portfolios Examples](https://www.sitebuilderreport.com/inspiration/photography-portfolios)

#### 2. **Anwita+Arun**
- **Site Structure:** Homepage with four quadrants for different specialties (Food Photography, Interior Photography, Still Life, Illustration)
- **Navigation:** Each quadrant is a mini portfolio entry point
- **What Works:** Visual grid lets visitors choose their interest area instantly
- **URL:** [Multi-Disciplinary Examples](https://www.sitebuilderreport.com/inspiration/photography-portfolios)

#### 3. **Meiwen**
- **Site Structure:** Minimalist homepage with short bio and featured items from both design and photography
- **Background:** Professional designer and photographer (travel, editorial, interior)
- **What Works:** Simple toggle between disciplines, unified aesthetic
- **URL:** [Photographer Portfolio Examples](https://www.framer.com/blog/photography-portfolio-websites/)

#### 4. **Dino Kužnik**
- **Background:** Graphic design background visible in site organization
- **Site Structure:** Clean galleries organized by service type
- **What Works:** Design skills enhance photography presentation
- **URL:** [Photography Portfolio Examples](https://www.framer.com/blog/photography-portfolio-websites/)

#### 5. **Mike Kelley**
- **Focus:** Architecture photography with love for design and airplanes
- **What Works:** Art and design merged into photography projects
- **URL:** [Photography Portfolios](https://www.pixpa.com/blog/photography-portfolio-websites)

#### 6. **Hazel May Eckert**
- **Background:** BFA in Printmaking + Diploma in Graphic Design
- **What Works:** Multiple disciplines (printmaking, design, photography) presented cohesively
- **URL:** [Photography Examples](https://www.booooooom.com/2024/11/28/14-photographer-portfolio-examples-for-inspiration/)

### Category B: Creative Directors with Personal Projects

#### 7. **Frank Chimero**
- **Site:** frankchimero.com
- **Background:** Creative Director at Modern Treasury, writer, designer
- **Site Structure:** Personal website with elegant simplicity, writing + portfolio + personal explorations
- **What Works:** Thoughtful white space, philosophy-driven, doesn't separate "professional" from "personal"
- **Key Insight:** Personal website becomes thought leadership platform
- **URL:** [Frank Chimero](https://frankchimero.com/)

#### 8. **Tobias van Schneider**
- **Site:** vanschneider.com
- **Background:** Co-founder of Semplice, designer, photographer, product maker
- **Site Structure:** Portfolio + photography + custom sneakers + product design + branding
- **What Works:** Multi-disciplinary presented as strength, not confusion
- **Key Insight:** "House of van Schneider" brand encompasses everything
- **URL:** [Tobias van Schneider](https://vanschneider.com/)

#### 9. **Jessica Hische**
- **Site:** jessicahische.is
- **Background:** Lettering artist, illustrator, author
- **Site Structure:** Clean portfolio with bold typography showcasing work + FAQ + personal sharing
- **What Works:** Unified visual identity across diverse project types
- **URL:** [Jessica Hische](https://www.jessicahische.is/working)

#### 10. **Jack McDade**
- **Site:** jackmcdade.com
- **Background:** Creator of Statamic, designer, educator (Radical Design course)
- **Site Structure:** "Wacky" personal site + product portfolio + teaching
- **What Works:** Personality-driven, not afraid to be unconventional
- **Key Insight:** Personal brand supports product brands (Statamic)
- **URL:** [Jack McDade](https://jackmcdade.com/)

#### 11. **Daniel Eden (Dan Eden)**
- **Site:** daneden.me
- **Background:** Product Designer at Meta Reality Labs
- **Site Structure:** Personal site + blog + portfolio + apps (time app, daylight app)
- **What Works:** Professional work + side projects presented equally
- **Key Insight:** Apps get same prominence as corporate portfolio
- **URL:** [Daniel Eden](https://daneden.me/)

### Category C: Developers/Designers Who Make Products

#### 12. **Paul Stamatiou**
- **Site:** paulstamatiou.com + photos.paulstamatiou.com
- **Background:** Head of Design at Sesame, previously Co-Founder at Limitless, 9 years at Twitter
- **Site Structure:** Two-site approach: main site for writing/design, separate for photography
- **Photography:** Elaborate photosets from travels (Greece, France, Japan)
- **What Works:** Separate domains for different audiences, cross-linked
- **Key Insight:** 20+ years writing on personal site builds authority
- **URL:** [Paul Stamatiou](https://paulstamatiou.com/)

#### 13. **Andy Matuschak**
- **Site:** andymatuschak.org + notes.andymatuschak.org
- **Background:** Applied researcher, tools for thought, previously Khan Academy and Apple iOS
- **Site Structure:** Main site + public notes site + Patreon for ongoing work
- **What Works:** "Building in public" with public notes, Patreon for supporter funding
- **Key Insight:** Research + products + writing all interconnected
- **URL:** [Andy Matuschak](https://andymatuschak.org/)

#### 14. **Bruno Simon**
- **Site:** bruno-simon.com
- **Background:** Creative developer (mostly for web)
- **Portfolio:** Interactive 3D experience where visitors drive a car to explore sections
- **What Works:** Portfolio itself demonstrates technical skills
- **Key Insight:** The medium IS the message
- **URL:** [Bruno Simon](https://bruno-simon.com/)

#### 15. **Patrick Heng**
- **Site:** patrickheng.com
- **Background:** French creative developer with WebGL experiments and UI animations
- **What Works:** Technical + artistic combined
- **URL:** [Patrick Heng](https://patrickheng.com/)

#### 16. **Brittany Chiang**
- **Background:** Web developer with strong portfolio
- **What Works:** Developer portfolio that feels designed
- **URL:** [Developer Portfolios](https://github.com/emmabostian/developer-portfolios)

### Category D: Indie Makers with Portfolio Approach

#### 17. **Max Artemov**
- **Background:** Built 30-app portfolio earning $22k/mo in less than a year
- **Strategy:** "Build fast, ship fast, focus on core features"
- **What Works:** Portfolio of products rather than single product focus
- **URL:** [Indie Hackers](https://www.indiehackers.com/post/tech/from-failed-app-to-30-app-portfolio-making-22k-mo-in-less-than-a-year-myy3U7K9evxGOVOHti8s)

#### 18. **Samuel Rondot**
- **Revenue:** $28k/mo from portfolio of SaaS products
- **Strategy:** Learned to code, built multiple products
- **URL:** [Indie Hackers](https://www.indiehackers.com/post/tech/learning-to-code-and-building-a-28k-mo-portfolio-of-saas-products-OA5p18fXtvHGxP9xTAwG)

#### 19. **Mobile App Portfolio Success Stories**
- **Example:** $185k/mo from portfolio of mobile apps (subscription-based)
- **Strategy:** Multiple apps, recurring revenue model
- **URL:** [Indie Hackers](https://www.indiehackers.com/post/tech/growing-a-portfolio-of-mobile-apps-to-185k-mo-hZ4hqICtByIljkiJECQv)

### Category E: Game Developers with Portfolios

#### 20. **Dean Tate**
- **Site:** iamdeantate.com
- **Structure:** Portfolio showcasing all games (working on, released, sunset)
- **What Works:** Clear project states (in development, shipped, archived)
- **URL:** [Game Developer Portfolios](https://www.sitebuilderreport.com/inspiration/game-developer-portfolios)

#### 21. **Hugo Peters**
- **Site:** hugo.fyi
- **Background:** Game programming and design portfolio
- **What Works:** Professional + personal projects side by side
- **URL:** [Hugo Peters](https://hugo.fyi/)

#### 22. **David Shaver**
- **Site:** davidshaver.net
- **Focus:** Game design portfolio with case studies
- **URL:** [Game Design Portfolio](https://www.davidshaver.net/)

### Category F: Bloggers/Writers Who Design

#### 23. **Jason Kottke**
- **Site:** kottke.org (since 1998) + kottke.org/portfolio
- **Background:** Blogger, graphic designer, web designer
- **Created:** Silkscreen typeface (used by Adobe, MTV, Volvo), Gawker logo
- **What Works:** Blog is primary, but portfolio demonstrates design chops
- **Key Insight:** Writing builds audience, portfolio converts clients
- **URL:** [Jason Kottke](https://kottke.org/portfolio/portfolio.html)

#### 24. **Khoi Vinh**
- **Site:** subtraction.com (since 2000)
- **Background:** Principal Designer at Adobe, former Design Director of NYT Online
- **Author:** "Ordering Disorder: Grid Principles for Web Design"
- **What Works:** Blog + book + corporate work all reinforce expertise
- **URL:** [Khoi Vinh](https://www.subtraction.com/)

#### 25. **Trent Walton**
- **Site:** trentwalton.com
- **Background:** Designer, consultant, music producer, co-founder of Paravel
- **What Works:** Writing + design work + music production unified
- **URL:** [Trent Walton](https://trentwalton.com/)

#### 26. **Dave Rupert**
- **Site:** daverupert.com
- **Background:** Web developer, podcaster (ShopTalk), co-founder of Paravel
- **What Works:** Blog + portfolio + podcast integrated
- **URL:** [Dave Rupert](https://daverupert.com/)

### Category G: Content Creators with Design Background

#### 27. **Casey Neistat**
- **Site:** caseyneistat.com
- **Background:** YouTube creator, filmmaker, daily vlogger
- **What Works:** Consistent visual branding (big white Helvetica), personality-driven
- **Key Insight:** Personal brand > perfect website (he admits site isn't great)
- **URL:** [Casey Neistat](https://www.caseyneistat.com/)

#### 28. **MKBHD (Marques Brownlee)**
- **Background:** Tech reviewer with design sensibility
- **Platform:** Primarily YouTube but consistent visual brand
- **What Works:** Clean aesthetic across all content

### Category H: Multi-Disciplinary Studio Sites

#### 29. **Grace Brosnan (Renaissance Creative)**
- **Site:** renaissancecreativ.com
- **Background:** Storyteller, creative director, fashion business education
- **Approach:** "Approaches every idea from multiple perspectives"
- **What Works:** Embraces multiple identities as strength
- **URL:** [Renaissance Creative](https://www.renaissancecreativ.com/)

#### 30. **James Victore**
- **Sites:** jamesvictore.com + yourworkisagift.com + courses.jamesvictore.com/store
- **Background:** Designer, artist, educator, business coach
- **Structure:** Multiple sites for different offerings (portfolio + education + store)
- **What Works:** Each site serves specific audience while maintaining unified brand
- **Clients:** Adobe, MailChimp, Starbucks, Time, Esquire
- **URL:** [James Victore](https://jamesvictore.com)

### Additional Notable Examples:

#### 31. **Simon Collison**
- **Site:** colly.com
- **Background:** Web/product designer, writer, speaker, director of New Adventures conference, musician (Site Nonsite)
- **What Works:** Generalist approach, multiple creative outlets
- **URL:** [Simon Collison via Awwwards](https://www.awwwards.com/awwwards-interviews-simon-collison.html)

#### 32. **Ethan Marcotte**
- **Site:** ethanmarcotte.com
- **Background:** Coined "responsive web design," worked with NYT, The Boston Globe
- **What Works:** Writing + speaking + design work integrated
- **URL:** [Ethan Marcotte](https://ethanmarcotte.com/)

#### 33. **Adam Wathan & Steve Schoger**
- **Sites:** adamwathan.me + steveschoger.com + refactoringui.com
- **Products:** Refactoring UI (book + videos), Tailwind CSS
- **What Works:** Personal sites + shared product site
- **Key Insight:** Developer/designer duo with separate identities but shared products
- **URL:** [Refactoring UI](https://refactoringui.com/)

---

## 2. SUCCESSFUL PATTERNS ANALYSIS

### Pattern 1: Navigation for Multiple Identities

**Approach A: Split Entry Points (Clean Separation)**
- Homepage offers clear choice between disciplines
- Example: Samuel Angibaud (Design | Photography split-screen)
- Example: Paul Stamatiou (separate domains: main site + photos subdomain)
- **Pros:** No confusion, visitors self-select
- **Cons:** May miss crossover opportunities

**Approach B: Unified Brand with Sections (Single Identity)**
- One cohesive site with sections for each discipline
- Example: Tobias van Schneider (all work under "House of van Schneider")
- Example: Frank Chimero (writing, design, explorations blend together)
- **Pros:** Reinforces personal brand, shows full range
- **Cons:** Requires strong unifying brand

**Approach C: Multiple Sites (Audience Segmentation)**
- Separate sites for different audiences
- Example: James Victore (portfolio + education + store)
- Example: Andy Matuschak (main + notes + Patreon)
- **Pros:** Each site optimized for specific audience
- **Cons:** Maintenance overhead, brand dilution risk

**Approach D: Product Portfolio Grid (Indie Maker)**
- Homepage shows all active products/projects as cards
- Example: Dean Tate (games in-progress, released, sunset)
- Example: Indie developer portfolios (apps as primary navigation)
- **Pros:** Clear "building in public" approach
- **Cons:** Less emphasis on services/client work

### Pattern 2: Portfolio vs. Blog vs. Products Balance

**The Writer-Designer Model:**
- Blog is primary driver (Kottke, Khoi Vinh, Trent Walton, Dave Rupert)
- Portfolio exists but writing builds audience
- Strategy: Write 2-3x/week, portfolio validates expertise
- Revenue: Speaking, consulting, book deals

**The Maker-Designer Model:**
- Products are primary (Andy Matuschak, indie developers)
- Portfolio shows past work, products show current focus
- Strategy: "Building in public," updates on products
- Revenue: Product sales, subscriptions, Patreon

**The Service-Portfolio Model:**
- Portfolio is primary sales tool (photography sites, design studios)
- Blog/updates are secondary
- Strategy: Showcase best work, clear service offerings
- Revenue: Client work, bookings, projects

**The Hybrid Model (Best for Studio Moser):**
- Portfolio + products + blog all coexist
- Example: Jack McDade (Statamic product + portfolio + teaching)
- Example: Paul Stamatiou (corporate work + writing + photo essays)
- Strategy: Each reinforces the others
- Revenue: Multiple streams (clients, products, teaching)

### Pattern 3: Professional Credibility vs. Personal Projects

**The "Day Job Credibility" Approach:**
- Lead with impressive client list
- Example: Dan Eden (Meta), Paul Stamatiou (Twitter → startups)
- Personal projects shown as "Also Building"
- **Benefit:** Instant credibility, easier to book clients

**The "Indie All The Way" Approach:**
- Personal projects front and center
- Client work minimal or absent
- Example: Many game developers, indie app makers
- **Benefit:** Authentic, attracts like-minded clients

**The "Best of Both" Approach (Recommended for Tim):**
- Corporate credentials establish expertise
- Personal projects show vision and initiative
- Example: "14 years at [Big Co], now building [Personal Thing]"
- **Benefit:** Credibility + passion + entrepreneurial proof

### Pattern 4: Photography Integration Strategies

**Separate Photography Portfolio:**
- Dedicated section or subdomain for photography
- Example: Paul Stamatiou (photos.paulstamatiou.com)
- Client galleries, services, booking flow isolated
- **When to use:** Professional photography services

**Photography as Documentation:**
- Use photography to document design/product process
- Behind-scenes photos become content
- Portfolio pieces include photography of process
- **When to use:** Photography enhances primary work

**Photography as Equal Discipline:**
- Photography portfolio same prominence as design
- Example: Meiwen, Anwita+Arun
- Clear service offerings for photo clients
- **When to use:** Photography is revenue stream

### Pattern 5: Product Showcase Approaches

**In-Progress Transparency (Building in Public):**
- Show works-in-progress prominently
- Example: Game developers (Dean Tate), indie makers
- Updates, devlogs, beta signups
- **Benefit:** Community building, early adopters

**Shipped Products Grid:**
- Homepage shows available products
- Example: Indie Hacker portfolios ($22k/mo, $185k/mo examples)
- Each product is a card with stats/links
- **Benefit:** Revenue focus, clear offerings

**Products as Case Studies:**
- Products treated like client work
- Challenge → Solution → Outcome format
- Example: Designer portfolios that include side projects
- **Benefit:** Shows process thinking

**Waitlist/Beta Strategy:**
- Pre-launch products with signup forms
- Example: LaunchList, Waitlister platforms
- Builds anticipation and email list
- **Benefit:** Early validation, audience building

---

## 3. SITE STRUCTURE RECOMMENDATIONS FOR STUDIO MOSER

### Recommended Approach: Unified Brand with Clear Sections

Based on research and Tim's context (Moby background + photography + products), recommend **Approach B (Unified Brand)** with elements of Approach D (Product visibility).

### Proposed Site Structure:

```
STUDIO MOSER
├── HOME
│   ├── Hero: Who Tim is (multi-disciplinary creative)
│   ├── Three Pillars: Design | Photography | Products
│   ├── Featured Work (mix across all three)
│   └── Current Focus (what's happening now)
│
├── WORK (Design & Creative Direction)
│   ├── Filter: All / Moby Projects / Independent / Startups
│   ├── Case Studies (5-8 best projects)
│   │   ├── Microsoft, Disney, NPR (Moby work)
│   │   └── Independent design projects
│   └── Process & Philosophy
│
├── PHOTOGRAPHY
│   ├── Portfolio Galleries
│   │   ├── Commercial Work
│   │   ├── Personal Projects
│   │   └── Process Documentation
│   ├── Photography Services
│   │   ├── What I Offer
│   │   ├── Pricing (or inquiry)
│   │   └── Booking/Contact
│   └── Featured Series (photo essays like Stamatiou)
│
├── PRODUCTS & PROJECTS
│   ├── Active Projects
│   │   ├── Ausra Photos (with status/updates)
│   │   ├── Supernormal Games
│   │   └── Other apps/products
│   ├── Shipped Products
│   │   ├── Depict
│   │   ├── Chuck the Ball
│   │   └── Past projects
│   └── Building in Public (devlog/updates)
│
├── ABOUT
│   ├── The Full Story
│   │   ├── Moby co-founder (14 years)
│   │   ├── 10 startups, 25 brands
│   │   ├── Indie game studio founder
│   │   └── Seattle creative community
│   ├── What Drives Me
│   ├── Studio Philosophy
│   └── How I Work
│
├── WRITING (Optional but Recommended)
│   ├── Essays & Thoughts
│   ├── Project Updates
│   └── Industry Insights
│
└── CONTACT
    ├── Current Availability
    ├── What I'm Looking For
    ├── Email / Instagram
    └── Contact Form
```

### Alternative Structure (If Photography Becomes Primary):

```
STUDIO MOSER
├── HOME (Photography-forward)
├── PHOTOGRAPHY (main offering)
├── DESIGN (portfolio + services)
├── PROJECTS (products/apps)
└── ABOUT & CONTACT
```

### Homepage Layout Options

**Option 1: Three-Column Entry (Clear Separation)**
```
┌─────────────────────────────────────────┐
│           TIM MOSER                      │
│    Creative Direction | Photography |   │
│           Product Development            │
├─────────┬─────────────┬─────────────────┤
│  DESIGN │ PHOTOGRAPHY │    PRODUCTS     │
│  [Image]│   [Image]   │     [Image]     │
│  View → │   View →    │     View →      │
└─────────┴─────────────┴─────────────────┘
```

**Option 2: Unified Feed (All Work Together)**
```
┌─────────────────────────────────────────┐
│         STUDIO MOSER                     │
│  Design · Photography · Products         │
├─────────────────────────────────────────┤
│  [Featured Work Grid - All Mixed]       │
│  [Design] [Photo] [Product] [Design]    │
│  [Photo] [Product] [Design] [Photo]     │
│                                          │
│  Filter: All | Design | Photo | Products│
└─────────────────────────────────────────┘
```

**Option 3: Story-Driven (Narrative Approach)**
```
┌─────────────────────────────────────────┐
│    I'm Tim Moser. I make things.        │
│                                          │
│    For 14 years, I've directed creative │
│    for Microsoft, Disney, and NPR.      │
│                                          │
│    I also photograph stories, build     │
│    apps, and make indie games.          │
│                                          │
│    [Explore My Work]                    │
└─────────────────────────────────────────┘
```

**Recommendation:** Option 3 (Story-Driven) for homepage, then clear navigation to specialized sections.

---

## 4. DESIGN DIRECTION OPTIONS

### Direction A: Minimalist with Bold Typography
- **Examples:** Frank Chimero, Khoi Vinh
- **Visual:** Clean white space, large type, minimal color
- **Tone:** Thoughtful, modern, professional
- **Best for:** Emphasizing writing + portfolio
- **Color:** Monochrome with one accent color

### Direction B: Visual Grid (Image-First)
- **Examples:** Photography portfolios, Anwita+Arun
- **Visual:** Large images, grid layouts, minimal text
- **Tone:** Visual storytelling, immersive
- **Best for:** Photography-forward presentation
- **Color:** Neutral to let images speak

### Direction C: Playful/Interactive
- **Examples:** Bruno Simon, Jack McDade
- **Visual:** Custom interactions, personality-driven
- **Tone:** Creative, memorable, unconventional
- **Best for:** Standing out, showing technical skills
- **Color:** Varied, expressive

### Direction D: Editorial/Magazine Style
- **Examples:** Paul Stamatiou photo essays, Jason Kottke
- **Visual:** Longer-form content, article layouts
- **Tone:** Storytelling, thoughtful, content-rich
- **Best for:** Writing + photography + portfolio blend
- **Color:** Sophisticated neutrals with editorial accents

### Recommendation for Studio Moser:

**Hybrid: Minimalist Foundation + Image Strength**

- Base: Clean, minimal design (Direction A)
- Photography sections: Image-forward (Direction B)
- Product pages: Slightly playful (Direction C touches)
- Writing/about: Editorial feel (Direction D)

**Color Palette:**
- **Primary:** Warm neutrals (cream, warm gray)
- **Accent:** Deep blue or forest green (Pacific Northwest)
- **Photography:** Full-bleed color, neutral frames
- **Products:** Brighter accents to differentiate

**Typography:**
- **Headings:** Bold sans-serif (Inter, Söhne, or custom)
- **Body:** Readable serif for long-form (Crimson, Lora) or clean sans
- **Accent:** Monospace for code/tech sections

---

## 5. CONTENT STRATEGY

### Homepage Copy Example:

```
TIM MOSER
Creative Director · Photographer · Maker

I've spent 14 years directing creative for Microsoft, Disney, and NPR
at Moby, Inc. I also photograph stories, build apps, and make indie games.

Seattle-based. Always making something.

[Explore Work] [View Photography] [See Projects]
```

### About Page Strategy (Ties Everything Together)

**The Challenge:** How to explain multiple identities without seeming unfocused?

**Solution:** Frame as "Complete Creative"

```markdown
# About Tim Moser

## The Short Version
I'm a creative director, photographer, and product maker based in Seattle.

## The Long Version

**By Day:**
I co-founded Moby, Inc in 2011 with James Jacoby. Over 14 years, I've directed
creative work for Microsoft, Disney, T-Mobile, NPR, and dozens of startups.
I manage overall aesthetic and visual direction—brand systems, product design,
user experience.

**By Night (and Weekends):**
I can't stop making things. I've co-founded 10 startups, created 25+ brands,
and run Supernormal Games, an indie game studio. Current projects include
Ausra Photos (a photo organization tool) and various experimental apps.

**Always:**
I document the world through photography—commercial work, personal projects,
and process documentation. The camera is how I see.

**Why "Studio Moser"?**
I needed one place for everything I make. Client work, side projects,
photography, products—they're all part of the same creative practice.
Studio Moser is that place.

I'm based in Seattle, educated at Northwest College of Art, and still
believe the best work comes from genuine collaboration and relentless curiosity.

**Currently:**
- Creative Director at Moby, Inc
- Building Ausra Photos
- Taking on select Studio Moser projects
- Making indie games at Supernormal
- Photographing the Pacific Northwest

[Email] [Instagram] [LinkedIn]
```

### Content Organization Strategy

**For Design/Portfolio Work:**
- Lead with Moby credentials (Microsoft, Disney, NPR)
- 5-7 case studies showing range
- Include role, team, process, outcomes
- Frame as: "Enterprise-level creative direction"

**For Photography:**
- Separate commercial and personal clearly
- Commercial: Client work, clear services/pricing
- Personal: Photo essays, explorations, travel
- Process: Behind-scenes of how photos are made

**For Products:**
- Active projects with status updates
- Shipped products with links/stats
- "Building in public" transparency
- Each product gets mini case study treatment

**For Writing (If Included):**
- Lessons from 14 years at Moby
- Startup/product insights
- Seattle creative scene observations
- Photography tutorials/thoughts
- Design critiques

---

## 6. PHOTOGRAPHY SHOWCASE APPROACH

### Research Insights from Photography Sites:

**Best Practices (2026):**
- 15-20 high-quality images per portfolio section
- 2400 x 1600px recommended size
- Minimalist design puts focus on photos
- Simple, intuitive navigation
- About page with photography background
- Easy-to-find contact/booking details

### Recommended Structure for Tim:

**Photography Landing Page:**
```
┌─────────────────────────────────────────┐
│    PHOTOGRAPHY BY TIM MOSER              │
│                                          │
│    [Hero Image - Best Work]             │
│                                          │
│    Commercial  |  Personal  |  Process  │
└─────────────────────────────────────────┘
```

**Commercial Photography:**
- Product photography examples
- Brand documentation work
- Event/corporate photography
- Clear service offerings:
  - Product Photography: [Price/Inquiry]
  - Brand Documentation: [Price/Inquiry]
  - Event Coverage: [Price/Inquiry]
- Booking flow: Contact → Quote → Schedule → Shoot

**Personal Photography:**
- Travel photography (Pacific Northwest, travels)
- Street photography
- Experimental work
- Presented as galleries/series (like Paul Stamatiou's photo essays)

**Process Photography:**
- Behind-scenes of design work
- Studio documentation
- Product development photos
- Shows intersection of photography + other work

### Photography Services Strategy:

**Option 1: Simple Inquiry-Based**
- "Interested in working together? Get in touch."
- No public pricing, custom quotes
- Professional but approachable

**Option 2: Package-Based**
- Half-Day Session: $X
- Full-Day Session: $Y
- Multi-Day Project: Custom
- Clear deliverables (# of images, editing, timeline)

**Option 3: Hybrid**
- Starting rates published
- "Most projects range from $X-$Y"
- Contact for custom quote

**Recommendation:** Option 3 (Hybrid) - shows professionalism while allowing flexibility

### Client Booking Flow Research:

**Platforms for Photography Services:**
- **Pixieset:** Client galleries + website + CRM + booking
- **Lightfolio:** Photo gallery + booking + online store
- **Zenfolio:** Website + galleries + e-commerce
- **Picsello:** CRM + scheduling + galleries + contracts
- **Session:** Booking + galleries integrated

**Recommendation for Tim:**
- Start with simple contact form
- If photography services grow, integrate Pixieset or similar
- Keep it simple initially: Contact → Email conversation → Book

---

## 7. PRODUCT/PROJECT SHOWCASE APPROACH

### "Building in Public" Best Practices:

**From Indie Hacker Research:**
- Show works-in-progress prominently
- Regular updates (weekly/biweekly devlogs)
- Transparent about challenges and learnings
- Email list for interested followers
- Beta signup forms for pre-launch products

### Recommended Product Page Structure:

```markdown
# PRODUCTS & PROJECTS

## Active Development

### Ausra Photos
[Screenshot/Mockup]
**Status:** Active development
**What it is:** Photo organization tool for [target audience]
**Why I'm building it:** [Personal motivation]
**Progress:** [Current stage - alpha/beta/etc.]
**Next milestone:** [What's coming]
[Join Waitlist] [Follow Updates]

### [Other Active Project]
[Same structure]

## Shipped & Available

### Depict (Supernormal Games)
[Screenshot]
**What it is:** Drawing and guessing game
**Launched:** [Date]
**Platform:** [iOS/Android/Web]
[Play Now] [Learn More]

### Chuck the Ball
[Screenshot]
**What it is:** Fast-paced puzzle game
**Launched:** [Date]
**Platform:** [iOS/Android/Web]
[Play Now] [Learn More]

## Past Explorations
[Archived projects, brief descriptions]
```

### Waitlist/Beta Signup Strategy:

**Research from Waitlist Platforms (LaunchList, Prefinery, Waitlister):**

**Best Practices:**
- Simple form (email only, or email + name)
- Clear value proposition ("Be first to try")
- Incentive if possible (early access, discount)
- Estimated timeline ("Launching Q2 2026")
- Regular updates to waitlist (monthly emails)

**Example for Ausra Photos:**
```
┌─────────────────────────────────────────┐
│  AUSRA PHOTOS                            │
│  Photo organization, reimagined          │
│                                          │
│  Currently in private beta.              │
│  Join the waitlist for early access.    │
│                                          │
│  [Email Address]                         │
│  [Join Waitlist]                         │
│                                          │
│  We'll email you when it's ready.       │
└─────────────────────────────────────────┘
```

### Product Updates Strategy:

**Option 1: Dedicated Updates Section**
- "Building in Public" blog
- Weekly/biweekly updates on products
- Show progress, challenges, decisions

**Option 2: Newsletter**
- Monthly email to subscribers
- Product progress, photography work, design thoughts
- Builds audience over time

**Option 3: Twitter/X + Instagram**
- Regular short updates
- Screenshots, progress GIFs
- Behind-scenes of development

**Recommendation:** All three, but start with Option 3 (social) + occasional blog posts

---

## 8. COMPARABLE SITES - FINAL TOP 30 RANKED

### Tier 1: Most Relevant to Studio Moser (Study These First)

1. **Paul Stamatiou** (paulstamatiou.com) - Designer + photographer + writer, corporate background + side projects
2. **Tobias van Schneider** (vanschneider.com) - Multi-disciplinary creative director + product maker + photographer
3. **Jack McDade** (jackmcdade.com) - Product maker + designer + educator, personality-driven
4. **Frank Chimero** (frankchimero.com) - Creative director + writer, elegant simplicity
5. **Andy Matuschak** (andymatuschak.org) - Researcher + product maker, building in public

### Tier 2: Excellent Patterns for Specific Sections

6. **Jessica Hische** (jessicahische.is) - Unified visual identity across diverse work
7. **Daniel Eden** (daneden.me) - Corporate work + personal apps equally prominent
8. **James Victore** (jamesvictore.com + sites) - Multiple sites for different audiences
9. **Meiwen** (various platforms) - Designer + photographer, clean separation
10. **Anwita+Arun** - Quadrant homepage for multiple disciplines

### Tier 3: Portfolio Structure & Presentation

11. **Bruno Simon** (bruno-simon.com) - Interactive, memorable portfolio
12. **Patrick Heng** (patrickheng.com) - Creative developer portfolio
13. **Dean Tate** (iamdeantate.com) - Game developer project states
14. **Hugo Peters** (hugo.fyi) - Game development portfolio
15. **David Shaver** (davidshaver.net) - Case study format

### Tier 4: Writing/Blogging Integration

16. **Jason Kottke** (kottke.org) - Blog-primary with portfolio
17. **Khoi Vinh** (subtraction.com) - Design blog + portfolio
18. **Trent Walton** (trentwalton.com) - Designer + writer + musician
19. **Dave Rupert** (daverupert.com) - Developer + podcaster
20. **Ethan Marcotte** (ethanmarcotte.com) - Writing + portfolio integrated

### Tier 5: Indie Maker / Product Focus

21. **Max Artemov** (Indie Hackers) - 30-app portfolio, building fast
22. **Samuel Rondot** (Indie Hackers) - SaaS portfolio approach
23. **Brittany Chiang** (brittanychiang.com) - Developer portfolio
24. **IndieDevs Platform** - Portfolio for indie developers

### Tier 6: Photography-Specific

25. **Mike Kelley** - Architecture photography + design
26. **Dino Kužnik** - Graphic design + photography
27. **Hazel May Eckert** - Printmaking + design + photography
28. **Samuel Angibaud** - Design/photography split-screen

### Tier 7: Creative Directors / Multi-Disciplinary

29. **Grace Brosnan / Renaissance Creative** (renaissancecreativ.com) - Multiple perspectives approach
30. **Simon Collison** (colly.com) - Generalist, designer + writer + musician

### Tier 8: Content Creators (Branding Lessons)

31. **Casey Neistat** (caseyneistat.com) - Personal brand strength
32. **MKBHD** - Visual consistency across platforms

### Tier 9: Designer/Developer Products

33. **Adam Wathan & Steve Schoger** (refactoringui.com) - Product + portfolio sites

---

## 9. NAVIGATION PATTERNS RECOMMENDATION

### Research Finding: Two Successful Approaches

**1. The "Choose Your Path" Approach**
- Homepage clearly shows multiple entry points
- Visitor chooses what they're interested in
- Examples: Samuel Angibaud (design vs photography), Anwita+Arun (quadrants)

**2. The "Unified Stream" Approach**
- All work shown together, filterable
- Personal brand is unifying element
- Examples: Tobias van Schneider, Frank Chimero

### Recommendation for Studio Moser: Hybrid

**Homepage: "Choose Your Path" (Clear Options)**
```
Navigation:
Work | Photography | Products | About | Contact

Homepage Hero:
TIM MOSER
Creative Direction · Photography · Products

[Three large cards/sections]
[DESIGN WORK →] [PHOTOGRAPHY →] [PRODUCTS →]
```

**Internal Pages: "Unified Stream" (Show Range)**
- Work page shows all design projects (Moby + independent)
- Photography shows all photo work (commercial + personal)
- Products shows all projects (active + shipped)
- Each section reinforces others: "Also see [Photography] | [Products]"

### Mobile Navigation Considerations:

**Mobile Menu:**
```
☰ Menu
├── Work (Design)
├── Photography
├── Products
├── About
└── Contact
```

Simple, clear, no confusion about what each section contains.

---

## 10. SITE STRUCTURE: FINAL RECOMMENDATION

### Primary Recommendation: Single Site, Clear Sections

```
studiomoser.com
├── / (Homepage - Three pillars clear)
├── /work (Design & Creative Direction)
│   ├── /work/microsoft-project
│   ├── /work/disney-project
│   └── /work/[project-slug]
├── /photography
│   ├── /photography/commercial
│   ├── /photography/personal
│   ├── /photography/process
│   └── /photography/services
├── /products
│   ├── /products/ausra-photos
│   ├── /products/supernormal-games
│   └── /products/[product-slug]
├── /about
├── /writing (optional, for later)
└── /contact
```

### Alternative (If Photography Becomes Major Revenue):

```
studiomoser.com (main portfolio + products)
photos.studiomoser.com (dedicated photography)
```

Following Paul Stamatiou's model of separate domains for separate audiences.

### Start With: Single Site

Reasons:
1. Easier to maintain one site initially
2. Reinforces unified brand
3. Can always split later if needed
4. Clear sections serve different audiences within one brand

---

## 11. TECHNICAL PLATFORM RECOMMENDATIONS

### Platform Options Ranked for Studio Moser:

**1. Framer (Recommended)**
- **Pros:** No-code, beautiful templates, designer-friendly, fast
- **Cons:** Less control than custom build
- **Best for:** Quick launch, professional look, iteration
- **Cost:** $15-30/month
- **Timeline:** 1-2 weeks to launch

**2. Webflow**
- **Pros:** More control, CMS for blog/products, professional
- **Cons:** Steeper learning curve, more expensive
- **Best for:** More complex sites, blog integration
- **Cost:** $20-40/month
- **Timeline:** 2-4 weeks to launch

**3. Custom (Next.js / React)**
- **Pros:** Full control, showcase dev skills, unique experience
- **Cons:** Time-intensive, maintenance
- **Best for:** If site itself is portfolio piece
- **Cost:** Free (hosting ~$10/month)
- **Timeline:** 4-8 weeks to launch

**4. Squarespace (Photography-Focused)**
- **Pros:** Easy, photographer-specific features, galleries
- **Cons:** Less flexibility, generic templates
- **Best for:** Photography-primary sites
- **Cost:** $15-30/month
- **Timeline:** 1 week to launch

**Recommendation: Start with Framer**

Reasons:
- Fastest to launch professionally
- Easy to update (products, photography)
- Can migrate to custom later if needed
- Tim can focus on content, not tech

### Photography-Specific Features Needed:

- High-resolution image support
- Gallery/lightbox functionality
- Fast loading (WebP, lazy loading)
- Mobile-optimized galleries
- Optional: Client proofing (Pixieset integration later)

### Product Pages Features Needed:

- Email signup forms (waitlist)
- Embedded demos/videos
- Status indicators (in-progress, shipped, etc.)
- External links (App Store, Play Store, etc.)
- Update feed/changelog

---

## 12. CONTENT STRATEGY: WHAT TO PUBLISH WHEN

### Phase 1: Launch (Week 1-2)

**Homepage:**
- Hero introduction
- Three clear sections (Design, Photography, Products)
- Featured work from each (2-3 pieces)
- About summary
- Contact info

**Work Page:**
- 5-7 case studies from Moby work
- Brief descriptions (full case studies can wait)
- High-quality images
- Role, team, year for each

**Photography Page:**
- 15-20 best photos (mix commercial + personal)
- Basic galleries (can organize later)
- Services overview (brief)
- Contact for bookings

**Products Page:**
- Ausra Photos (with waitlist)
- Supernormal Games (with links to games)
- Brief descriptions of each
- "More coming soon"

**About Page:**
- Full story (Moby background, startups, games, photography)
- Why Studio Moser exists
- Seattle connection
- Contact info

**Contact Page:**
- Email
- Instagram
- Contact form (simple)
- Current availability note

### Phase 2: Expand (Month 2-3)

**Add:**
- Full case studies (process, outcomes, learnings)
- More photography galleries (organized by type)
- Photography services pricing
- Product update blog posts
- Testimonials (if available)

### Phase 3: Ongoing Content

**Monthly:**
- Product updates (Ausra progress, game updates)
- New photography work
- Case studies from new projects
- Behind-scenes content

**Quarterly:**
- Major portfolio updates
- New product launches
- Photography series/essays
- Writing/insights pieces

---

## 13. "ABOUT" PAGE STRATEGY (TYING IT ALL TOGETHER)

### The Challenge:

How to explain:
- 14 years creative director at Moby
- Co-founder of 10 startups
- Indie game studio founder
- Professional photographer
- Product maker (Ausra Photos, etc.)

...without seeming scattered or unfocused?

### The Solution: Frame as "Complete Creative Practice"

**Strategy:**
1. Lead with credentials (Moby, clients, experience)
2. Explain side projects as natural extension
3. Frame Studio Moser as unifying platform
4. Show it's all connected (design thinking across mediums)

### Recommended About Page Copy:

```markdown
# About Tim Moser

![Photo of Tim - workspace or Seattle background]

## I make things.

For 14 years, I've directed creative work for Microsoft, Disney, T-Mobile,
and NPR as co-founder of Moby, Inc. Along the way, I've co-founded 10 startups,
created 25+ brands, and launched an indie game studio because I can't help
but build new things.

Studio Moser is where it all comes together—the design work, the photography,
the products I'm building. It's my complete creative practice, not just one facet.

## Background

**Design & Creative Direction**
I co-founded Moby with James Jacoby in 2011. We've since built a team that's
created digital products, websites, and mobile apps for Fortune 500 companies
and ambitious startups. I manage overall aesthetic and visual direction—from
brand systems to user experience to the final pixel.

**Photography**
The camera is how I see the world. I photograph commercially (products, brands,
events) and personally (travel, street, documentary). I also use photography to
document the design process, turning behind-scenes into compelling visual stories.

**Products & Games**
I've co-founded 10 startups and currently run Supernormal Games (formerly
Makeshift Games), an indie game studio. Current projects include Ausra Photos,
a photo organization tool I'm building to solve my own frustration with existing
solutions. If I see a problem, I build something to fix it.

## Why "Studio Moser"?

For years, my work lived in different places: Moby for client work, Supernormal
for games, scattered portfolios for photography. Studio Moser brings it together
under one roof.

It's not a separate business—it's the umbrella for everything I make. Client
projects, side products, photography work, experimental apps. They're all part
of the same creative practice, all informed by the same human-centered design
thinking I've honed over 20+ years.

## Currently

- Creative Director at Moby, Inc (Seattle)
- Building Ausra Photos and other tools
- Making indie games at Supernormal
- Photographing the Pacific Northwest
- Taking on select Studio Moser projects

## Education & Background

- Northwest College of Art (2000-2003)
- Seattle-based since [year]
- Active in Seattle creative and indie game communities
- Creator of things visual and musical

## Let's Work Together

Studio Moser takes on 2-3 select projects per quarter. I'm interested in:

- Startups needing enterprise-level creative direction
- Agencies needing senior creative partnership
- Photography projects (commercial or editorial)
- Interesting problems that need creative solutions

If that sounds like your project, [get in touch](mailto:tim@studiomoser.com).

---

**Email:** tim@studiomoser.com
**Instagram:** [@studiomoser](https://instagram.com/studiomoser)
**LinkedIn:** [Tim Moser](https://linkedin.com/in/timmoser)
```

### Key Elements of This Approach:

1. **Leads with credibility** (Moby, major clients)
2. **Explains breadth** (startups, games, photography) as natural
3. **Frames Studio Moser** as unifying platform, not side hustle
4. **Shows focus** (design thinking across mediums)
5. **Sets expectations** (2-3 projects/quarter = selective)
6. **Clear CTAs** (what he's looking for, how to contact)

---

## 14. FINAL RECOMMENDATIONS

### Start Here (Week 1-2):

1. **Choose Platform** (Framer recommended)
2. **Gather Content:**
   - 5-7 best Moby projects (images, descriptions, role)
   - 15-20 best photos (mix commercial + personal)
   - Product screenshots/info (Ausra, games)
   - Write About page using template above
3. **Build Structure:**
   - Homepage with three pillars
   - Work, Photography, Products pages (minimal to start)
   - About page (full story)
   - Contact page
4. **Launch** (even if imperfect)

### Month 1-2: Expand

1. **Add Detail:**
   - Full case studies for 2-3 best projects
   - Organize photography into galleries
   - Product updates for Ausra Photos
2. **Start Content:**
   - Instagram presence
   - Product development updates
   - Behind-scenes content
3. **Gather Feedback:**
   - Share with trusted colleagues
   - Test with different audiences (design, photo, products)
   - Iterate based on feedback

### Month 3+: Optimize

1. **Measure:**
   - Which sections get most traffic?
   - What brings in inquiries?
   - Where do people spend time?
2. **Double Down:**
   - If photography drives bookings → expand photo services
   - If products get interest → publish more updates
   - If portfolio drives clients → add more case studies
3. **Consider:**
   - Adding blog/writing section
   - Newsletter for product updates
   - Separating photography to subdomain if it grows

### Key Success Metrics:

**Year 1 Goals:**
- Portfolio site live and professional
- 2-3 Studio Moser projects booked
- Photography services established (if pursuing)
- Ausra Photos beta launched with waitlist
- Clear personal brand established

**Don't Measure:**
- Social media follower count initially
- Website traffic (unless driving leads)
- Comparison to others

**Do Measure:**
- Inbound inquiries quality
- Project bookings
- Product waitlist signups
- Clarity of positioning (feedback)

---

## 15. SOURCES & REFERENCES

### Multi-Disciplinary Portfolio Examples:
- [Photography Portfolios: 25+ Well-Designed Examples (2026)](https://www.sitebuilderreport.com/inspiration/photography-portfolios)
- [Framer Blog: 13 photography portfolio websites with artful design](https://www.framer.com/blog/photography-portfolio-websites/)
- [Top 60 Most Creative and Unique Portfolio Websites of 2023](https://muz.li/blog/60-most-creative-portfolio-websites-of-2023/)
- [36 Amazing Multidisciplinary Art Portfolio Website Examples](https://www.format.com/customers/art/multidisciplinary)
- [Creative Director Portfolio Websites: 15+ Inspiring Examples (2026)](https://www.sitebuilderreport.com/inspiration/creative-director-portfolios)

### Specific Creator Sites:
- [Frank Chimero](https://frankchimero.com/)
- [Tobias van Schneider](https://vanschneider.com/)
- [Jessica Hische](https://www.jessicahische.is/working)
- [Paul Stamatiou](https://paulstamatiou.com/)
- [Andy Matuschak](https://andymatuschak.org/)
- [Jack McDade](https://jackmcdade.com/)
- [Daniel Eden](https://daneden.me/)
- [Bruno Simon](https://bruno-simon.com/)
- [Jason Kottke](https://kottke.org/)
- [Khoi Vinh](https://www.subtraction.com/)
- [Trent Walton](https://trentwalton.com/)
- [Dave Rupert](https://daverupert.com/)
- [Ethan Marcotte](https://ethanmarcotte.com/)
- [Casey Neistat](https://www.caseyneistat.com/)
- [James Victore](https://jamesvictore.com)
- [Refactoring UI](https://refactoringui.com/)

### Indie Maker / Product Portfolio Research:
- [From failed app to 30-app portfolio making $22k/mo](https://www.indiehackers.com/post/tech/from-failed-app-to-30-app-portfolio-making-22k-mo-in-less-than-a-year-myy3U7K9evxGOVOHti8s)
- [Learning to code and building a $28k/mo portfolio of SaaS products](https://www.indiehackers.com/post/tech/learning-to-code-and-building-a-28k-mo-portfolio-of-saas-products-OA5p18fXtvHGxP9xTAwG)
- [Growing a portfolio of mobile apps to $185k/mo](https://www.indiehackers.com/post/tech/growing-a-portfolio-of-mobile-apps-to-185k-mo-hZ4hqICtByIljkiJECQv)
- [GitHub - Developer Portfolios List](https://github.com/emmabostian/developer-portfolios)
- [IndieDevs Platform](https://www.producthunt.com/products/indiedevs)

### Game Developer Portfolios:
- [Game Developer Portfolios: 15+ Well-Designed Examples (2026)](https://www.sitebuilderreport.com/inspiration/game-developer-portfolios)
- [Dean Tate - Game Developer Portfolio](http://www.iamdeantate.com/)
- [Hugo Peters](https://hugo.fyi/)
- [David Shaver](https://www.davidshaver.net/)

### Photography Website Research:
- [9 Best Photography Portfolio Websites To Inspire You in 2026](https://www.designrush.com/best-designs/websites/trends/best-photography-portfolio-websites)
- [25+ Best Photography Portfolio Website Examples in 2025](https://www.pixpa.com/blog/photography-portfolio-websites)
- [14 Outstanding Photography Portfolio Examples](https://www.wix.com/blog/12-stunning-photography-websites)
- [Pixieset: Client Photo Gallery, Website, CRM for Photographers](https://pixieset.com/)
- [Lightfolio: Client Photo Gallery for Photographers](https://www.lightfolio.com/)
- [Zenfolio: Website & Gallery Solutions for Photographers](https://zenfolio.com/)
- [Picsello: Online Client Scheduler, Gallery, CRM](https://www.picsello.com/)

### Waitlist / Beta Signup Research:
- [LaunchList - Viral Pre-Launch Waitlist Software](https://getlaunchlist.com/)
- [Prefinery: Pre-launch Waiting List & Referral Marketing](https://www.prefinery.com/)
- [Waitlister: Free Waitlist Software for Product Launches](https://waitlister.me/)
- [Waitlist Landing Page: Examples & Best Practices](https://moosend.com/blog/waitlist-landing-page/)

### Portfolio Design & Strategy:
- [Web Designer & Developer Portfolios: 25 Inspiring Examples (2026)](https://www.sitebuilderreport.com/inspiration/web-developer-designer-portfolios)
- [23 Inspiring Portfolio Website Examples & Tips](https://www.figma.com/resource-library/portfolio-website-examples/)
- [Personal Websites: 35 Inspiring Examples (2026)](https://www.sitebuilderreport.com/inspiration/personal-websites)
- [A Personal Website VS a Portfolio](https://blog.reimenayee.com/a-personal-website-vs-a-portfolio/)
- [Portfolio vs Personal Website: Best Choice for Creatives 2025](https://www.getvsble.com/blog/portfolio-vs-personal-website-best-choice-for-creatives-2025-en-a171b)

### Design Trends 2026:
- [5 Best Portfolio Website Builders Creators Are Using in 2026](https://emergent.sh/learn/best-portfolio-website-builders)
- [Portfolio Examples for Product Designers in 2026](https://fueler.io/blog/portfolio-examples-for-product-designers)
- [What Great Student Design Portfolios Look Like in 2026](https://bestfolios.medium.com/what-great-student-design-portfolios-look-like-in-2026-dd6f83485c38)
- [Graphic Design Trends 2026: 13 Futuristic Styles Where AI Meets Human](https://reallygooddesigns.com/graphic-design-trends-2026/)
- [Creative Narrative: Master Storytelling Strategies for 2026](https://www.automateed.com/creative-narrative)
- [How creators are leveraging Adobe's 2026 Creative Trends](https://blog.adobe.com/en/publish/2026/01/08/how-creators-leveraging-adobe-2026-creative-trends)

### About Page & Storytelling:
- [15 personal website examples to inspire your best design](https://www.wix.com/blog/personal-website-examples)
- [Digital Storytelling: Benefits, Examples, Tools & Tips for 2026](https://research.com/education/digital-storytelling)
- [2026 Will Be About Storytelling](https://www.quillitwithfire.com/p/2026-is-about-storytelling)

---

## APPENDIX: Quick Reference

### Site Structure (Copy/Paste Ready):

```
HOME - Who Tim is, three pillars (Design, Photography, Products)
WORK - Design & creative direction portfolio (Moby + independent)
PHOTOGRAPHY - Commercial + personal galleries + services
PRODUCTS - Active projects (Ausra) + shipped (games) + updates
ABOUT - Full story tying everything together
CONTACT - Email, availability, inquiry form
```

### Homepage Hero (Copy/Paste Ready):

```
TIM MOSER
Creative Director · Photographer · Maker

14 years directing creative for Microsoft, Disney, and NPR.
Also building apps, making indie games, and photographing stories.

Seattle-based. Always making something.

[Explore Work] [View Photography] [See Products]
```

### Navigation Labels (Copy/Paste Ready):

```
Primary Nav: Work | Photography | Products | About | Contact
Mobile: Same, hamburger menu
Footer: All pages + Instagram + LinkedIn + Email
```

### Platform Decision Matrix:

| Platform | Launch Speed | Control | Cost | Best For |
|----------|-------------|---------|------|----------|
| Framer | 1-2 weeks | Medium | $15-30/mo | Quick professional launch |
| Webflow | 2-4 weeks | High | $20-40/mo | Blog integration, CMS |
| Custom | 4-8 weeks | Full | ~$10/mo hosting | Showcase dev skills |
| Squarespace | 1 week | Low | $15-30/mo | Photography-primary |

**Recommendation: Framer**

---

## CONCLUSION

Studio Moser is uniquely positioned as a multi-faceted creator site. The research shows that the most successful creators in this space don't hide their multiple interests—they embrace them as a unified creative practice.

**Key Insights:**
1. **Don't separate too much** - One site, clear sections is better than scattered presence
2. **Lead with credibility** - Moby background is gold, use it
3. **Frame breadth as strength** - "Complete creative practice" not "scattered interests"
4. **Start simple** - Launch with basics, expand based on what works
5. **Build in public** - Product updates, photography work, process—show it all

**Tim's Advantages:**
- 14 years enterprise credentials (instant authority)
- Multiple successful projects (proof of execution)
- Seattle creative community (built-in network)
- Genuine multi-disciplinary skills (not faking it)
- Products in active development (building in public opportunity)

**Next Steps:**
1. Choose platform (recommend Framer)
2. Gather best work from each area (design, photos, products)
3. Write About page using template provided
4. Build simple site (homepage + 5 key pages)
5. Launch in 2 weeks, iterate from there

The market doesn't need another single-focus portfolio. The market DOES need authentic creators who work across multiple mediums and aren't afraid to show the full range of what they make.

That's Studio Moser.

---

**This strategy document provides:**
- ✅ 30+ comparable creator sites analyzed
- ✅ Successful patterns for multi-identity sites
- ✅ Site structure recommendations
- ✅ Design direction options
- ✅ Content strategy for all sections
- ✅ Photography showcase approach
- ✅ Product/project presentation strategy
- ✅ "About" page strategy tying everything together
- ✅ Technical platform recommendations
- ✅ Launch roadmap

**Ready for the team to build from.**
