# NanoClaw Fork Comparison Report
**Generated:** 2026-02-11  
**Upstream:** gavrielc/nanoclaw  
**Fork:** qwibitai/nanoclaw

## Executive Summary

Our fork has diverged significantly from upstream, with **4 custom commits** containing major architectural changes. We are **fully up-to-date** with upstream/main (no upstream commits we're missing). The divergence is intentional and substantial - we've converted from WhatsApp-only to iMessage-only, added collaboration features, and fixed critical scheduler bugs.

---

## Divergence Point

**Commit:** `8eb80d4ed0d9e1e13f5cd2932d0c343751a00b5e`  
**Message:** fix: prevent infinite message replay on container timeout (#164)  
**Status:** This is the last common commit between our fork and upstream

---

## Our Custom Commits (4 total)

### 1. `1c73042` - docs: update add-imessage skill for Channel architecture
**Date:** 2026-02-11 11:48:39 -0800  
**Type:** Documentation  
**Changes:**
- Updated add-imessage skill documentation to reflect implementation status
- Documented IMessageChannel class architecture
- Removed WhatsApp comparison references

### 2. `1614c91` - refactor: convert iMessage to Channel architecture, remove WhatsApp
**Date:** 2026-02-11 11:47:43 -0800  
**Type:** Major Refactor - **CRITICAL TO PRESERVE**  
**Changes:**
- Created `src/channels/imessage.ts` with IMessageChannel class implementing Channel interface
- **REMOVED WhatsApp channel entirely** (`src/channels/whatsapp.ts` deleted)
- Simplified `src/index.ts` to only use iMessage
- Removed WhatsApp-specific message loop and recovery functions
- Updated approval workflow for channel architecture

**Impact:** This is a fundamental architectural change that makes our fork incompatible with upstream's WhatsApp focus.

### 3. `0e5f890` - Merge remote improvements with iMessage and scheduler fix
**Date:** 2026-02-11 11:35:32 -0800  
**Type:** Merge Commit  
**Changes:**
- Merged upstream refactoring (tests, channels abstraction, router module)
- Preserved iMessage integration
- Preserved collaboration folder watching
- Preserved scheduler race condition fix
- Removed Telegram integration (no longer needed)

**Merged from upstream:**
- Refactored WhatsApp into channels/whatsapp.ts
- Added router.ts for message formatting
- Added ipc.ts for IPC watching
- Added comprehensive test suite (vitest)
- Added GitHub Actions CI

### 4. `ac68170` - feat: major improvements - iMessage, Telegram, collaboration, scheduler fix
**Date:** 2026-02-11 11:03:53 -0800  
**Type:** Major Feature Addition - **CRITICAL TO PRESERVE**  
**Changes:**

#### New Features:
- **iMessage Integration:** Native macOS iMessage support via database access and AppleScript
  - Isolated agents per contact with approval workflow
  - Optional collaboration workspace for multi-agent coordination
  - Host-level file watching (fswatch) to wake sleeping agents
  - Add-imessage skill for easy setup

- **Telegram Integration:** Full Telegram bot support
  - Can replace or complement WhatsApp
  - Configurable as control-only or passive notification channel
  - Add-telegram skill for setup

- **Collaboration Folder Watching:** Host-level file monitoring
  - Uses fswatch (macOS) / inotifywait (Linux)
  - Automatically wakes agents when collaboration files change
  - Zero CPU when idle, instant wake on file changes
  - Bidirectional agent coordination

#### Bug Fixes:
- **Scheduler race condition fix:** Prevents scheduled tasks from being re-enqueued while running
  - Tasks now update next_run immediately on start
  - Prevents infinite timeout/retry loops
  - Fixes issue where long-running tasks were enqueued multiple times

#### Configuration Changes:
- Per-group idle timeout configuration
- Enhanced database schema with iMessage approval workflow
- Changed default ASSISTANT_NAME from 'Andy' to 'Shelby'
- Reduced default IDLE_TIMEOUT from 30min to 5min
- Added iMessage collaboration folder configuration

---

## Upstream Commits We Don't Have

**Status:** NONE - We are fully up-to-date with upstream/main

Our fork is based on the latest upstream/main commit (`8eb80d4`), so there are no upstream changes we're missing.

---

## File Differences Summary

**Total Changes:** 18 files modified (2,455 insertions, 372 deletions)

### New Files (Ours Only):
1. `.claude/skills/add-imessage/SKILL.md` (+901 lines) - iMessage integration skill
2. `apply-imessage-integration.cjs` (+233 lines) - iMessage setup script
3. `container/agent-runner/src/file-watcher.sh` (+45 lines) - Shell script for file watching
4. `container/agent-runner/src/file-watcher.ts` (+85 lines) - TypeScript file watcher
5. `src/channels/imessage.ts` (+317 lines) - iMessage channel implementation
6. `src/collaboration-watcher.ts` (+183 lines) - Collaboration folder watcher
7. `src/telegram.ts` (+216 lines) - Telegram integration

### Deleted Files (Removed from Upstream):
1. `src/channels/whatsapp.ts` (-283 lines) - **WhatsApp channel removed**

### Modified Files:
1. `container/Dockerfile` (+3/-0) - Added fswatch for file watching
2. `container/agent-runner/src/index.ts` (+118 insertions) - File watcher integration
3. `groups/global/CLAUDE.md` (+4/-4) - Minor documentation updates
4. `groups/main/CLAUDE.md` (+8/-8) - Minor documentation updates
5. `src/config.ts` (+20 modifications) - iMessage/Telegram config, changed defaults
6. `src/db.ts` (+122 insertions) - iMessage approval workflow schema
7. `src/index.ts` (+123 modifications) - Replaced WhatsApp with iMessage
8. `src/task-scheduler.ts` (+7 insertions) - Race condition fix
9. `src/types.ts` (+3 modifications) - Type updates
10. `src/whatsapp-auth.ts` (+156 modifications) - Likely still used for some auth logic

---

## Analysis: What's Truly Custom vs Upstream

### 100% Custom (Must Preserve During Rebases):

1. **iMessage Integration** - Entire feature suite
   - `src/channels/imessage.ts`
   - `apply-imessage-integration.cjs`
   - `.claude/skills/add-imessage/`
   - Database schema changes in `src/db.ts`
   - iMessage-specific config in `src/config.ts`

2. **WhatsApp Removal** - Major architectural divergence
   - Deletion of `src/channels/whatsapp.ts`
   - Removal of WhatsApp references from `src/index.ts`
   - This makes us incompatible with upstream's core functionality

3. **Collaboration Watcher** - Unique feature
   - `src/collaboration-watcher.ts`
   - `container/agent-runner/src/file-watcher.ts`
   - `container/agent-runner/src/file-watcher.sh`
   - Dockerfile fswatch installation

4. **Telegram Integration** - Our implementation
   - `src/telegram.ts`
   - Telegram config in `src/config.ts`
   - Note: Upstream has Telegram support too, but likely different implementation

5. **Scheduler Race Condition Fix** - Critical bug fix
   - Changes to `src/task-scheduler.ts`
   - Updates next_run immediately to prevent re-enqueueing
   - Should potentially be contributed back to upstream

6. **Configuration Defaults** - Our preferences
   - ASSISTANT_NAME: 'Shelby' (upstream uses 'Andy')
   - IDLE_TIMEOUT: 5min (upstream uses 30min)
   - iMessage collaboration folder path

### Potentially from Upstream (Need to Verify):

1. **Channel Interface** - Likely from upstream's refactor-index branch
   - The Channel interface that IMessageChannel implements
   - Router module for message formatting
   - IPC module for IPC watching

2. **Test Suite** - From upstream
   - vitest configuration
   - GitHub Actions CI

3. **General Refactoring** - From upstream
   - Code quality improvements
   - Module extraction

---

## Rebase Risk Assessment

**Risk Level:** HIGH - Extensive conflicts expected

### Major Conflicts to Expect:

1. **src/index.ts** - Heavy modifications
   - Upstream: WhatsApp-focused
   - Ours: iMessage-focused
   - Resolution: Keep our version, manual merge of upstream improvements

2. **src/channels/whatsapp.ts** - Deleted in our fork
   - Upstream: Continues to improve WhatsApp
   - Ours: Completely removed
   - Resolution: Stay deleted, ignore upstream WhatsApp changes

3. **src/config.ts** - Different defaults and new configs
   - Upstream: WhatsApp configs
   - Ours: iMessage/Telegram configs
   - Resolution: Keep our configs, selectively merge upstream improvements

4. **src/db.ts** - Schema divergence
   - Upstream: WhatsApp-focused schema
   - Ours: iMessage approval workflow
   - Resolution: Keep our schema, check for other improvements

### Low-Risk Areas (Can Take Upstream):

1. Container management improvements
2. General bug fixes (non-WhatsApp)
3. Documentation improvements
4. Test infrastructure
5. Type improvements

---

## Recommendations

### 1. Do NOT Rebase
Our fork has diverged too significantly. Rebasing would create hundreds of conflicts and risk losing critical functionality.

### 2. Cherry-Pick Selectively
Review upstream commits individually and cherry-pick only non-WhatsApp improvements:
- Bug fixes in task-scheduler, container management
- Performance improvements
- Type safety improvements
- General refactoring that doesn't touch WhatsApp

### 3. Consider Contributing Back
Our scheduler race condition fix (`src/task-scheduler.ts`) is a legitimate bug fix that benefits upstream. Consider submitting a PR.

### 4. Monitor Upstream for Ideas
Upstream continues active development. Watch for:
- New skills that could be adapted
- Performance optimizations
- Security fixes
- Container management improvements

### 5. Document Fork Rationale
This fork is fundamentally different:
- **Upstream:** WhatsApp-focused multi-platform agent
- **Ours:** iMessage-focused macOS agent with collaboration features

We should maintain this as a long-term fork rather than trying to stay in sync.

---

## Files to Protect During Any Merge/Rebase

Critical files that must not be overwritten:
- `src/channels/imessage.ts`
- `src/collaboration-watcher.ts`
- `container/agent-runner/src/file-watcher.ts`
- `container/agent-runner/src/file-watcher.sh`
- `.claude/skills/add-imessage/`
- `apply-imessage-integration.cjs`
- `src/telegram.ts`

Files requiring careful manual merge:
- `src/index.ts` (completely different architecture)
- `src/config.ts` (different defaults and configs)
- `src/db.ts` (different schema)
- `src/task-scheduler.ts` (our bug fix)

---

## Upstream Branch Status

Upstream has several feature branches we should be aware of:
- `upstream/refactor-index` - Already merged into our codebase
- `upstream/feat/telegram-integration-with-swarms` - Telegram swarm feature
- `upstream/feat/per-group-queue-reliability` - Queue improvements (older, likely merged)

These branches show upstream is also actively refactoring, which makes rebase even riskier.

---

## Conclusion

This fork represents a **fundamental architectural divergence** from upstream. We've:
1. Removed WhatsApp entirely
2. Added comprehensive iMessage support
3. Added collaboration features
4. Fixed critical scheduler bugs
5. Changed configuration defaults

**Bottom Line:** Treat this as a long-term fork. Do not attempt to rebase. Cherry-pick useful improvements selectively. Consider our changes as a separate product direction rather than a temporary deviation.
