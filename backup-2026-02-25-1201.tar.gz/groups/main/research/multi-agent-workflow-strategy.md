# Multi-Agent Workflow Strategy for NanoClaw
## Comprehensive Research & Implementation Plan

**Prepared for:** Tim @ Studio Moser
**Date:** February 11, 2026
**Research Focus:** Understanding Antfarm, multi-agent systems, and practical implementation for Tim's projects

---

## Table of Contents

1. [What is Antfarm?](#1-what-is-antfarm)
2. [Multi-Agent Research Findings](#2-multi-agent-research-findings)
3. [NanoClaw Capabilities](#3-nanoclaw-capabilities)
4. [Do We Need Antfarm?](#4-do-we-need-antfarm)
5. [Practical Setup for Tim's Projects](#5-practical-setup-for-tims-projects)
6. [Implementation Plan](#6-implementation-plan)

---

## 1. What is Antfarm?

### Overview

Antfarm is a TypeScript CLI tool that orchestrates teams of AI agents running in OpenClaw. Rather than managing individual AI interactions, it enables coordinated multi-agent workflows where specialized agents handle distinct tasks in sequence. The system emphasizes deterministic, reproducible processes over unstructured conversations.

**Source:** [GitHub - snarktank/antfarm](https://github.com/snarktank/antfarm)

### Core Architecture

**Technology Stack:**
- YAML-based workflow definitions
- SQLite for state persistence
- Cron jobs for orchestration
- TypeScript with zero external dependencies
- Runs locally wherever OpenClaw is available

**Key Design Philosophy:** "YAML + SQLite + cron. That's it." The system deliberately avoids Redis, Kafka, or container orchestrators to remain minimal and portable.

### Agent Coordination Model

Antfarm uses a polling-based architecture with these key characteristics:

1. **Independent polling** — Each agent claims available work steps autonomously
2. **Context isolation** — Fresh session per step eliminates context window bloat and hallucination from prior exchanges
3. **Sequential handoff** — Agents pass results to successors with git history and progress files maintaining memory
4. **Verification gates** — Downstream agents validate upstream work against strict acceptance criteria (developers don't self-grade)

This design follows "the Ralph loop" — autonomous agents operating with clean context boundaries.

### Pre-Built Workflows

**feature-dev** (7 agents):
- Decomposes feature requests into stories
- Implements each story
- Verifies independently
- Tests comprehensively
- Creates PRs
- Enforces code review before shipping

**security-audit** (7 agents):
- Scans repositories for vulnerabilities
- Prioritizes by severity
- Patches each finding
- Re-audits afterward
- Generates tested fix PRs

**bug-fix** (6 agents):
- Reproduces reported issues
- Investigates root causes
- Patches problems
- Validates fixes through regression testing

### Key Features & Capabilities

**Reliability Features:**
- Automatic retry logic for failed steps
- Human escalation when retries exhaust
- No silent failures
- Dashboard monitoring for real-time visibility (port 3333)

**Customization:**
- Define custom agents and workflows in plain YAML
- Specify acceptance criteria, retry policies, and verification gates
- Reusable agent specifications and workspace configurations

**Security Measures:**
- Workflows exclusively from the official GitHub repository
- Pre-merge security review for prompt injection attacks
- Transparent YAML/Markdown definitions readable before installation
- Community contributions welcome with mandatory security review

### How It Works (Three Phases)

**Define:** Structure agents and steps in YAML with clear personas, workspaces, and acceptance criteria.

**Install:** Single command provisions agent workspaces, establishes cron polling, and configures permissions without external infrastructure.

**Run:** Agents autonomously claim steps, complete work, and pass context forward. SQLite tracks state; cron drives execution forward.

### Technical Requirements

- Node.js >= 22
- OpenClaw v2026.2.9+
- Web dashboard (port 3333) for monitoring runs and viewing agent output
- Supports workflow resumption after failures

### Antfarm's Core Value Proposition

Antfarm represents a departure from conversational AI toward **orchestrated** AI work, emphasizing:
- Reproducibility
- Verification
- Clear separation of concerns between specialized agents
- Assembly-line style processing where each agent has a specific job

---

## 2. Multi-Agent Research Findings

### OpenClaw Multi-Agent Capabilities

OpenClaw enables multiple isolated agents (separate workspace + agentDir + sessions), with inbound messages routed to agents via bindings.

**Key Features:**
- Different personalities per agent (AGENTS.md, SOUL.md)
- Separate auth + sessions (no cross-talk unless explicitly enabled)
- Multiple channel accounts in one running Gateway
- Routing system that binds inbound messages to agentId by (channel, accountId, peer)

**Real-World Usage:**
Early adopters run multiple OpenClaw instances, each with different personas (coder, writer, etc.), with a primary instance delegating to them. Users report running seven AI agents, each with its own identity, memory, tools, permissions, and model, coordinated through Telegram groups functioning like company departments.

**Sources:**
- [Multi-Agent Routing - OpenClaw](https://docs.openclaw.ai/concepts/multi-agent)
- [OpenClaw: Ultimate Guide to AI Agent Workforce 2026](https://o-mega.ai/articles/openclaw-creating-the-ai-agent-workforce-ultimate-guide-2026)
- [Run Multiple OpenClaw AI Agents with Elastic Scaling](https://www.digitalocean.com/blog/openclaw-digitalocean-app-platform)

### Claude Agent Teams (Anthropic's Official Implementation)

Released with Claude Opus 4.6 in February 2026, Agent Teams allows multiple Claude instances to coordinate autonomously, challenge each other's findings, and tackle complex codebases in parallel.

**How It Works:**
- One session acts as the team lead, coordinating work, assigning tasks, and synthesizing results
- Teammates work independently, each in its own context window
- Direct communication between teammates without going through the lead
- Shared task list for coordination
- Autonomous coordination patterns

**Key Capabilities:**

1. **Parallel Exploration**: Multiple teammates investigate different aspects simultaneously, then share and challenge each other's findings

2. **Direct Communication**: Teammates message each other, claim tasks from a shared list, and work through problems collaboratively

3. **Autonomous Coordination**: Agents coordinate autonomously — one on parsing, another on code generation, another on optimization passes — all communicating and validating each other's work

**Notable Demonstration:**
Nicholas Carlini (Anthropic's Safeguards team) tasked 16 agents with writing a Rust-based C compiler from scratch capable of compiling the Linux kernel. After nearly 2,000 Claude Code sessions and $20,000 in API costs, the agent team produced a 100,000-line compiler that can build Linux 6.9 on x86, ARM, and RISC-V.

**Best Use Cases:**
- Research and review
- New modules or features
- Debugging with competing hypotheses
- Cross-layer coordination (frontend, backend, tests)

**Sources:**
- [Orchestrate teams of Claude Code sessions - Official Docs](https://code.claude.com/docs/en/agent-teams)
- [Claude Opus 4.6 Agent Teams Tutorial](https://www.nxcode.io/resources/news/claude-agent-teams-parallel-ai-development-guide-2026)
- [How to Set Up Claude Code Agent Teams](https://darasoba.medium.com/how-to-set-up-and-use-claude-code-agent-teams-and-actually-get-great-results-9a34f8648f6d)
- [Anthropic releases Opus 4.6 with new 'agent teams'](https://techcrunch.com/2026/02/05/anthropic-releases-opus-4-6-with-new-agent-teams/)

### Agent Teams vs Sub-Agents

**Sub-Agents:**
- Run within a single session
- Report results back to main agent only
- No inter-agent communication
- Lower token cost (results summarized)
- Best for: Focused tasks where only the result matters

**Agent Teams:**
- Own context window, fully independent
- Teammates message each other directly
- Shared task list with self-coordination
- Higher token cost (separate Claude instances)
- Best for: Complex work requiring discussion and collaboration

**Source:** [Claude Code Agent Teams: Multi-Session Orchestration](https://claudefa.st/blog/guide/agents/agent-teams)

### Multi-Agent Design Patterns (Industry Best Practices)

Research from Microsoft, AWS, and industry leaders reveals seven foundational patterns for 2026:

1. **Sequential/Linear Orchestration**: Agents chained in predefined order, each processing output from the previous agent

2. **Hierarchical Pattern**: Agents organized into layers, higher-level agents oversee or delegate to lower-level agents

3. **Orchestrator-Worker Pattern**: Central orchestrator assigns tasks to worker agents and manages execution (similar to master-worker in distributed computing)

4. **Reflection Pattern**: Agent critically evaluates its own output before finalizing, converting AI from generator to self-correcting system

5. **Multi-Agent Collaboration**: Multiple intelligent agents collaborate, adapt, and operate in real-time to solve complex tasks

6. **Planning Pattern**: Agent plans approach before execution

7. **Human-in-the-Loop**: Human oversight and intervention at key decision points

**Key Industry Insights:**

- **Model Context Protocol (MCP)**: Emerging standard ensuring smooth, secure connection between AI agents and external systems
- **40% of enterprise applications** will feature task-specific AI agents by 2026
- **10x productivity gains** reported by companies using multi-agent workflows with MCP
- **The scaling gap**: Nearly 2/3 of organizations experiment with AI agents, but fewer than 1 in 4 have successfully scaled to production

**Critical Success Factors:**
- Strong data pipelines with real-time access
- API-first integration strategy
- Real-time monitoring of agent behavior
- Choosing patterns upfront reduces cycle time
- Willingness to redesign workflows rather than layering agents onto legacy processes

**Sources:**
- [The 2026 Guide to AI Agent Workflows](https://www.vellum.ai/blog/agentic-workflows-emerging-architectures-and-design-patterns)
- [Best Practices for AI Agent Implementations: Enterprise Guide 2026](https://onereach.ai/blog/best-practices-for-ai-agent-implementations/)
- [Top AI Agentic Workflow Patterns That Will Lead in 2026](https://medium.com/@Deep-concept/top-ai-agentic-workflow-patterns-that-will-lead-in-2026-0e4755fdc6f6)
- [AI Agent Orchestration Patterns - Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)
- [Guidance for Multi-Agent Orchestration on AWS](https://aws.amazon.com/solutions/guidance/multi-agent-orchestration-on-aws/)

### Common Pitfalls to Avoid

1. **Unnecessary coordination complexity**: Using complex patterns when basic sequential orchestration would suffice
2. **Adding agents without meaningful specialization**: Every agent should have a clear, distinct purpose
3. **Overlooking latency impacts**: Multiple-hop communication can add significant delays
4. **File conflicts**: Two agents editing the same file leads to overwrites
5. **Context bloat**: Long-running agents accumulating unnecessary context
6. **Silent failures**: Systems that don't report errors clearly

---

## 3. NanoClaw Capabilities

### What is NanoClaw?

NanoClaw is a minimalist, secure Claude assistant that runs in Apple containers, consisting of just 500 lines of TypeScript with full filesystem isolation and WhatsApp integration.

**Core Philosophy:** Not a framework — working software designed to be forked and modified, with no configuration sprawl.

**Sources:**
- [GitHub - gavrielc/nanoclaw](https://github.com/gavrielc/nanoclaw)
- [NanoClaw: A Slimmed-Down Version of ClawdBot](https://ai-engineering-trend.medium.com/nanoclaw-a-slimmed-down-version-of-clawdbot-achieved-in-just-500-lines-of-code-c208dc16ee8f)
- [Show HN: NanoClaw](https://news.ycombinator.com/item?id=46850205)

### Security Through Container Isolation

NanoClaw replaces application-level security with operating system-level isolation:
- Agents run inside actual Linux containers using Apple Container technology
- Each chat gets its own sandboxed context
- Explicit filesystem mounts determine what AI can see
- Complete filesystem isolation between groups

This is a direct reaction to OpenClaw's security architecture (which runs directly on host machine with unrestricted access).

### Built-In Multi-Agent Features

Based on the CLAUDE.md system instructions, NanoClaw has sophisticated multi-agent capabilities:

#### 1. Team Creation & Management

**TeamCreate Tool:**
- Creates team with task list (1:1 correspondence)
- Team file at `~/.claude/teams/{team-name}.json`
- Task list directory at `~/.claude/tasks/{team-name}/`
- Supports multiple agent types (read-only, full-capability, custom)

**Team Workflow:**
1. Create team (creates both team and task list)
2. Create tasks using Task tools
3. Spawn teammates with `team_name` and `name` parameters
4. Assign tasks using TaskUpdate with `owner`
5. Teammates work on assigned tasks
6. Teammates go idle between turns (automatic notifications)
7. Shutdown team via SendMessage with type: "shutdown_request"

#### 2. Automatic Message Delivery

- Messages from teammates automatically delivered (no manual polling)
- Messages appear as new conversation turns (like user messages)
- If busy (mid-turn), messages queued and delivered when turn ends
- UI shows notification with sender name when messages waiting

#### 3. Task List Coordination

Shared task list at `~/.claude/tasks/{team-name}/`:
- All teammates can access
- Check TaskList periodically, especially after completing tasks
- Claim unassigned, unblocked tasks with TaskUpdate
- Prefer tasks in ID order (lowest first)
- Create new tasks with TaskCreate
- Mark completed with TaskUpdate
- If all tasks blocked, notify team lead or help resolve blocking

#### 4. Teammate Discovery

Team config at `~/.claude/teams/{team-name}/config.json`:
- Contains `members` array
- Each member has: name (for messaging), agentId (reference), agentType (role)
- Always refer to teammates by NAME for messaging/assignment

#### 5. Communication Tools (SendMessage)

**Message Types:**

a) **Direct Message (type: "message")**
   - Send to single specific teammate
   - Requires: recipient, content, summary
   - Important: Plain text output NOT visible to team — must use tool

b) **Broadcast (type: "broadcast")**
   - Send same message to ALL teammates at once
   - WARNING: Expensive, scales linearly with team size
   - Use only for critical issues requiring team-wide attention
   - Default to "message" instead

c) **Shutdown Request (type: "shutdown_request")**
   - Ask teammate to gracefully shut down
   - Teammate can approve (exit) or reject (continue working)

d) **Shutdown Response (type: "shutdown_response")**
   - Approve or reject shutdown request
   - Must extract requestId from JSON message

e) **Plan Approval Response (type: "plan_approval_response")**
   - Approve or reject teammate's plan
   - For teammates with `plan_mode_required`
   - After approval, teammate exits plan mode and proceeds

#### 6. Idle State Management

- Teammates go idle after every turn (normal and expected)
- Idle does NOT mean done or unavailable
- Idle teammates can receive messages
- System sends automatic idle notifications
- Do not treat idle as error
- Peer DM visibility in idle notifications

### NanoClaw's Group Management System

NanoClaw has sophisticated group isolation:

**Container Mounts:**
- `/workspace/project` - Project root (read-write)
- `/workspace/group` - Current group folder (read-write)
- Each group gets own container with isolated filesystem

**Group Registration:**
- Configured in `/workspace/project/data/registered_groups.json`
- Each group has: name, folder, trigger, requiresTrigger, containerConfig
- Can add additional mounts per group via `containerConfig.additionalMounts`
- Groups can be added/removed dynamically

**Memory Management:**
- Each group has own CLAUDE.md with instructions
- Conversations folder for searchable history
- Memory files (customers.md, preferences.md, etc.)
- Global memory at `/workspace/project/groups/global/CLAUDE.md`

**Scheduling System:**
- Schedule tasks to run later or recurring (cron, interval, once)
- Context modes: "group" (with chat history) or "isolated" (fresh session)
- Can schedule for other groups using `target_group_jid`

### What NanoClaw Already Does Well

1. **Container isolation per chat/group** — better security than Antfarm or OpenClaw
2. **WhatsApp integration** — native messaging platform support
3. **Scheduled tasks** — cron-style recurring jobs without external dependencies
4. **Group-specific memory and context** — isolated per chat
5. **Simple codebase** — 500 lines, easy to understand and modify
6. **Built-in team coordination** — TeamCreate, task lists, messaging
7. **Automatic message delivery** — no manual polling required
8. **Task ownership and claiming** — file-locking prevents race conditions
9. **Flexible agent types** — read-only, full-capability, custom
10. **Plan approval workflows** — require approval before implementation

---

## 4. Do We Need Antfarm?

### What Antfarm Provides That NanoClaw Doesn't

1. **Pre-built workflow templates** — feature-dev, security-audit, bug-fix with proven patterns
2. **YAML workflow definitions** — declarative, version-controlled workflow specifications
3. **Verification gates** — strict acceptance criteria where downstream agents validate upstream work
4. **Retry logic and human escalation** — automatic retry with escalation when exhausted
5. **Web dashboard** — monitoring interface on port 3333
6. **Sequential handoff with clean context** — fresh session per step (no context bloat)
7. **Cron-based polling** — agents autonomously claim work steps
8. **Git history as memory** — progress files + git for maintaining state between steps
9. **Assembly-line workflow** — each agent has one specific job in sequence
10. **"Developers don't self-grade"** — verification is separate from implementation

### What NanoClaw Already Does Well (Advantages Over Antfarm)

1. **Container isolation** — OS-level security (Antfarm doesn't have this)
2. **WhatsApp native** — built-in messaging platform (Antfarm requires separate setup)
3. **Simpler codebase** — 500 lines vs larger TypeScript project
4. **Real-time coordination** — automatic message delivery (no polling delay)
5. **Flexible team structures** — not limited to sequential workflows
6. **Group management** — multi-chat support with isolation
7. **Direct agent communication** — agents can message each other directly
8. **Task dependencies** — sophisticated task management with blocking
9. **Interactive control** — can message individual teammates mid-execution
10. **Already running** — no additional installation required

### Gap Analysis

| Capability | Antfarm | NanoClaw | Gap? |
|------------|---------|----------|------|
| Multi-agent coordination | ✅ Sequential polling | ✅ Real-time messaging | No gap |
| Task management | ✅ SQLite + steps | ✅ Task lists with dependencies | No gap |
| Workflow definitions | ✅ YAML templates | ❌ Ad-hoc prompts | **YES** |
| Verification gates | ✅ Acceptance criteria | ⚠️ Manual (can be added) | Partial |
| Retry logic | ✅ Built-in | ⚠️ Manual (can be added) | Partial |
| Pre-built workflows | ✅ feature-dev, bug-fix, security-audit | ❌ None | **YES** |
| Dashboard monitoring | ✅ Web UI on port 3333 | ❌ Terminal only | **YES** |
| Context isolation | ⚠️ Fresh session per step | ✅ Container per group | No gap (better) |
| Security isolation | ❌ Runs on host | ✅ OS-level containers | No gap (better) |
| Messaging platform | ⚠️ Needs setup | ✅ WhatsApp native | No gap (better) |
| Direct agent messaging | ❌ Sequential only | ✅ Any-to-any | No gap (better) |
| Installation complexity | Medium (Node.js, setup) | None (already running) | No gap (better) |

### Recommendation: Build on NanoClaw, Borrow Patterns from Antfarm

**Don't install Antfarm.** Instead:

1. **Use NanoClaw's built-in team coordination** — it's more flexible and already running
2. **Borrow Antfarm's workflow patterns** — create YAML-style workflow definitions that NanoClaw can execute
3. **Add verification gates** — implement acceptance criteria checks in workflows
4. **Create workflow templates** — build feature-dev, bug-fix equivalents for NanoClaw
5. **Add retry logic** — implement retry + escalation patterns

**Why this approach:**
- NanoClaw has superior security (container isolation)
- Real-time messaging is better than polling
- WhatsApp integration already works
- Simpler to maintain (500 lines vs full framework)
- More flexible (not locked into sequential patterns)
- Can still use Antfarm's proven workflow structures

**What to adopt from Antfarm:**
- Workflow template structure (YAML-inspired)
- Verification gate pattern (downstream validates upstream)
- Retry + escalation logic
- Assembly-line specialization (each agent has one clear job)
- "Developers don't self-grade" principle

---

## 5. Practical Setup for Tim's Projects

Based on Tim's profile, he has 5 active projects that could benefit from multi-agent workflows:

1. Studio Moser (portfolio website, branding, Instagram, photography)
2. Ausra Photos (native Mac/iPad/iOS app)
3. dawnmoser.com (Squarespace site - mostly complete)
4. Ebook Reader App (in development)
5. Shopify Store (physical products)

### Multi-Agent Strategy by Project

#### Project 1: Studio Moser (Portfolio Website)

**Best Pattern:** Hierarchical with cross-layer coordination

**Agent Team Structure:**

```
Team Lead (Coordinator)
├── Content Strategist (copy, messaging, brand voice)
├── Visual Designer (layout, color, typography)
├── Technical Developer (implementation, performance)
└── SEO Specialist (optimization, analytics)
```

**Why this works:**
- Portfolio sites need parallel work on copy, design, and implementation
- SEO runs continuously as content is created
- Cross-layer coordination between design and development
- Content and design can work independently initially

**Workflow:**

1. **Research Phase** (Parallel)
   - Content Strategist: Analyze competitor portfolios, define voice
   - Visual Designer: Mood boards, style research
   - Technical Developer: Platform evaluation (static site, CMS, etc.)
   - SEO Specialist: Keyword research, competitive analysis

2. **Planning Phase** (Sequential with reviews)
   - Content Strategist: Site structure, page outlines → Review gate
   - Visual Designer: Design system, mockups → Review gate
   - Technical Developer: Architecture plan → Review gate
   - SEO Specialist: SEO strategy doc → Review gate

3. **Implementation Phase** (Parallel with coordination)
   - Content Strategist: Write all copy
   - Visual Designer: Create assets (images, graphics)
   - Technical Developer: Build site structure
   - Agents coordinate on: alt text, image optimization, responsive design

4. **Verification Phase** (Independent checks)
   - Technical Developer: Performance audit, accessibility check
   - SEO Specialist: SEO audit, meta tags, structured data
   - Visual Designer: Cross-browser testing, design QA
   - Content Strategist: Copy review, brand consistency

**Task Assignment Example:**

```
Team: studio-moser-site
Tasks:
1. [Content] Research competitor portfolio sites (10 examples)
2. [Design] Create mood board and style direction
3. [Tech] Evaluate 3 platform options with pros/cons
4. [SEO] Keyword research for Seattle-based design studio
5. [Content] Draft homepage copy (depends: 1)
6. [Design] Create homepage mockup (depends: 2)
7. [Tech] Set up development environment (depends: 3)
8. [SEO] Create SEO strategy doc (depends: 4)
9. [Content] Write all page copy (depends: 5)
10. [Design] Create all visual assets (depends: 6)
11. [Tech] Implement site (depends: 7, 9, 10)
12. [SEO] Implement SEO optimizations (depends: 11)
13. [All] Final review and QA (depends: 12)
```

#### Project 2: Ausra Photos (Native App Development)

**Best Pattern:** Orchestrator-worker with verification gates

**Agent Team Structure:**

```
Team Lead (Product Manager)
├── Architecture Agent (system design, data flow)
├── iOS Developer (Swift, SwiftUI, iOS-specific features)
├── macOS Developer (AppKit, Mac-specific features)
├── Backend Developer (sync, backup, cloud storage)
├── QA Tester (test plans, bug verification)
└── Documentation Writer (user docs, API docs)
```

**Why this works:**
- Native app across 3 platforms needs platform-specific agents
- Shared codebase components need architecture coordination
- Backend sync is complex and needs dedicated agent
- QA validates each platform implementation independently

**Workflow Pattern: Feature Development**

Example: "Implement photo tagging system"

1. **Architecture Phase**
   - Architecture Agent: Design data model for tags
   - Architecture Agent: Define sync protocol
   - Architecture Agent: Create API specification
   - → Verification gate: Team Lead reviews architecture

2. **Implementation Phase (Parallel)**
   - iOS Developer: Implement tagging UI in SwiftUI
   - macOS Developer: Implement tagging UI in AppKit
   - Backend Developer: Build tag sync endpoints
   - Documentation Writer: Draft user guide for tagging
   - Each implementation includes unit tests

3. **Integration Phase**
   - iOS Developer: Integrate with backend sync
   - macOS Developer: Integrate with backend sync
   - QA Tester: Create cross-platform test plan
   - → Verification gate: QA runs test suite

4. **Verification Phase**
   - QA Tester: Test on iOS (all devices)
   - QA Tester: Test on macOS (Intel & Apple Silicon)
   - QA Tester: Test sync between platforms
   - Documentation Writer: Update with actual screenshots
   - → Verification gate: All tests pass + docs complete

**Task Assignment Example:**

```
Team: ausra-photos-tagging
Tasks:
1. [Arch] Design tag data model and sync protocol
2. [Arch] Create API specification for tagging
3. [iOS] Implement tagging UI in SwiftUI (depends: 1, 2)
4. [Mac] Implement tagging UI in AppKit (depends: 1, 2)
5. [Backend] Build tag sync endpoints (depends: 2)
6. [Docs] Draft tagging user guide (depends: 1)
7. [iOS] Write unit tests for iOS tagging (depends: 3)
8. [Mac] Write unit tests for Mac tagging (depends: 4)
9. [Backend] Write API tests for sync (depends: 5)
10. [QA] Create cross-platform test plan (depends: 3, 4, 5)
11. [QA] Run full test suite on all platforms (depends: 7, 8, 9, 10)
12. [Docs] Update guide with screenshots (depends: 11)
13. [Lead] Final review and merge (depends: 11, 12)
```

#### Project 3: dawnmoser.com (Website Completion)

**Best Pattern:** Sequential with minimal coordination (mostly complete)

**Agent Team Structure:**

```
Team Lead (Project Coordinator)
├── Content Collector (gather personal essays from sources)
├── Template Specialist (select and customize Squarespace template)
├── Copywriter (draft all page copy)
└── Site Builder (build in Squarespace, finalize)
```

**Why this works:**
- Project is well-defined with clear decisions already made
- Sequential workflow is most efficient (each step feeds the next)
- Small team since scope is narrow
- Mostly execution, minimal research needed

**Workflow: Sequential Assembly Line**

1. **Content Collector** → Gathers all personal essays from existing sources
   - Output: Compiled markdown file with all essays
   - Verification: Count matches expectations, all sources checked

2. **Template Specialist** → Selects Squarespace template
   - Input: Brand positioning, content structure
   - Output: 3 template recommendations with justification
   - Verification: Templates support dual-purpose (professional + personal)

3. **Copywriter** → Drafts all page copy
   - Input: Essays, positioning, decisions made
   - Output: Complete copy for all pages (About, Services, Contact, Essays)
   - Verification: Brand voice consistent, "contact for pricing" included

4. **Site Builder** → Builds site in Squarespace
   - Input: Copy, template selection, visual direction
   - Output: Complete live site
   - Verification: All links work, mobile responsive, SEO basics done

**Task Assignment Example:**

```
Team: dawnmoser-site
Tasks:
1. [Collector] Gather personal essays from all sources
2. [Collector] Compile into structured markdown
3. [Template] Research 5 Squarespace templates (depends: 2)
4. [Template] Select top 3 with pros/cons (depends: 3)
5. [Copy] Draft homepage copy (depends: 2, 4)
6. [Copy] Draft About page copy (depends: 2, 4)
7. [Copy] Draft Services page copy (depends: 2, 4)
8. [Copy] Draft first 5 essay posts (depends: 2)
9. [Builder] Set up Squarespace, select template (depends: 4)
10. [Builder] Build all pages with copy (depends: 5, 6, 7, 9)
11. [Builder] Import and format essays (depends: 8, 9)
12. [Builder] Final polish and SEO basics (depends: 10, 11)
```

#### Project 4: Ebook Reader App (Development)

**Best Pattern:** Research-heavy with competing hypotheses

**Agent Team Structure:**

```
Team Lead (Product Manager)
├── Market Researcher (competitive analysis, user research)
├── UX Designer (user flows, wireframes, prototypes)
├── iOS Developer (implementation)
├── Backend Developer (if needed for sync/library management)
├── Reader Tech Specialist (ebook formats, rendering libraries)
└── Monetization Strategist (business model, pricing)
```

**Why this works:**
- Ebook readers have complex technical requirements (formats, rendering)
- Market is crowded; needs differentiation research
- UX is critical for success
- Technical challenges warrant dedicated specialist
- Business model needs careful consideration

**Workflow Pattern: Research → Design → Build**

1. **Research Phase (Parallel exploration)**
   - Market Researcher: Analyze top 10 ebook readers
   - Reader Tech Specialist: Evaluate rendering libraries (epub, pdf, mobi)
   - Monetization Strategist: Research pricing models and revenue
   - UX Designer: User research on reading habits

2. **Design Phase (Synthesis)**
   - Team discusses findings (agents challenge each other)
   - UX Designer: Create user flows based on research
   - UX Designer: Wireframes for core features
   - Monetization Strategist: Define feature tiers (if freemium)
   - → Verification gate: Review and approve design

3. **Technical Planning**
   - Reader Tech Specialist: Recommend tech stack
   - iOS Developer: Architecture plan
   - Backend Developer: Define sync requirements (if needed)
   - → Verification gate: Approve architecture

4. **Implementation (Iterative)**
   - iOS Developer: Build core reading experience
   - Reader Tech Specialist: Integrate rendering library
   - Backend Developer: Build sync (if needed)
   - UX Designer: Test and provide feedback
   - Iterate until ready

**Task Assignment Example:**

```
Team: ebook-reader-app
Tasks:
1. [Market] Analyze top 10 ebook readers (features, pricing, reviews)
2. [Tech] Evaluate 3 epub rendering libraries
3. [Monetization] Research pricing models (paid, freemium, subscription)
4. [UX] User research on reading habits and pain points
5. [UX] Define unique value proposition (depends: 1, 4)
6. [UX] Create user flows for core features (depends: 5)
7. [UX] Wireframes for main screens (depends: 6)
8. [Tech] Recommend tech stack (depends: 2)
9. [iOS] Architecture plan (depends: 8)
10. [Monetization] Define feature tiers and pricing (depends: 3, 5)
11. [iOS] Build MVP reading experience (depends: 9)
12. [Tech] Integrate rendering library (depends: 11)
13. [UX] Usability testing and feedback (depends: 12)
14. [iOS] Iterate based on feedback (depends: 13)
```

#### Project 5: Shopify Store (Physical Products)

**Best Pattern:** Marketing-focused parallel execution

**Agent Team Structure:**

```
Team Lead (Business Manager)
├── Product Strategist (product selection, positioning)
├── Shopify Developer (store setup, customization)
├── Graphic Designer (product mockups, branding)
├── Copywriter (product descriptions, About page)
├── SEO/Marketing Specialist (optimization, launch strategy)
└── Operations Specialist (shipping, fulfillment, pricing)
```

**Why this works:**
- Physical product businesses need strong branding and marketing
- Multiple parallel tracks (products, store, marketing)
- Each agent has clear domain expertise
- Operations is complex (shipping, fulfillment) and needs focus

**Workflow Pattern: Launch Preparation**

1. **Foundation Phase (Parallel)**
   - Product Strategist: Research product ideas (t-shirts + what else?)
   - Graphic Designer: Develop brand identity
   - Operations Specialist: Research print-on-demand vs inventory
   - SEO/Marketing: Competitive analysis for niche

2. **Planning Phase (Synthesis)**
   - Product Strategist: Final product selection with rationale
   - Operations Specialist: Pricing strategy with margins
   - SEO/Marketing: Marketing strategy and launch plan
   - → Verification gate: Approve products and pricing

3. **Creation Phase (Parallel)**
   - Graphic Designer: Create all product designs
   - Copywriter: Write product descriptions
   - Shopify Developer: Set up store, theme customization
   - SEO/Marketing: Create SEO-optimized content structure

4. **Implementation Phase**
   - Shopify Developer: Add all products to store
   - Graphic Designer: Create product mockups for each design
   - Copywriter: Write About page, policies, FAQs
   - Operations Specialist: Set up shipping, fulfillment integration

5. **Pre-Launch Phase**
   - SEO/Marketing: SEO audit and optimization
   - Operations Specialist: Test order flow end-to-end
   - Copywriter: Email sequences for launch
   - → Verification gate: All systems tested and ready

**Task Assignment Example:**

```
Team: shopify-store-launch
Tasks:
1. [Product] Research product ideas (categories, niches)
2. [Design] Develop brand identity (logo, colors, fonts)
3. [Ops] Research POD vs inventory (pros/cons/costs)
4. [Marketing] Competitive analysis for chosen niche
5. [Product] Final product selection (depends: 1, 4)
6. [Ops] Create pricing strategy with margins (depends: 3, 5)
7. [Marketing] Marketing and launch plan (depends: 4, 5)
8. [Design] Create product designs (depends: 2, 5)
9. [Copy] Write product descriptions (depends: 5, 8)
10. [Shopify] Set up store and theme (depends: 2)
11. [Shopify] Add products to store (depends: 8, 9, 10)
12. [Design] Create product mockups (depends: 8, 11)
13. [Copy] Write About, policies, FAQs (depends: 2, 6)
14. [Ops] Set up shipping and fulfillment (depends: 6, 10)
15. [Marketing] SEO audit and optimization (depends: 11, 13)
16. [Ops] Test order flow end-to-end (depends: 11, 14)
17. [Copy] Create launch email sequences (depends: 7)
18. [Lead] Final review and launch approval (depends: 15, 16, 17)
```

### Cross-Project Roles and Responsibilities

Some agent roles appear across multiple projects:

**SEO Specialist:**
- Studio Moser: Portfolio SEO, local search
- dawnmoser.com: Writing portfolio SEO
- Shopify Store: Product and content SEO

**Copywriter:**
- Studio Moser: Portfolio and service copy
- dawnmoser.com: All page copy
- Shopify Store: Product descriptions, policies

**Developer:**
- Studio Moser: Website implementation
- Ausra Photos: App development (specialized by platform)
- Ebook Reader: App development

**Designer:**
- Studio Moser: Web design
- Shopify Store: Brand and product design
- Ebook Reader: UI/UX design

**Researcher:**
- All projects: Competitive analysis, market research
- Specialized by domain

### Example Workflow: Studio Moser Portfolio Site (Detailed)

Let's walk through the complete workflow for Studio Moser as a detailed example.

#### Phase 1: Team Setup

**Create team:**
```
Team name: studio-moser-portfolio
Members:
- team-lead (coordinator, Sonnet 4.5)
- content-strategist (Sonnet 4.5)
- visual-designer (Sonnet 4.5)
- tech-dev (Sonnet 4.5)
- seo-specialist (Sonnet 4.5)
```

**Initial team brief (sent to all teammates):**
```
Project: Studio Moser portfolio website
Goal: Modern, professional portfolio showcasing design work, photography, and services
Audience: Potential clients in Seattle area, design/creative industry
Timeline: 4-6 weeks to launch
Brand: Minimal, sophisticated, photography-forward

Each of you has a specific role. Work independently on your tasks,
but coordinate when tasks overlap (e.g., SEO and content strategy,
design and technical implementation).

Verification gates required at end of each phase.
```

#### Phase 2: Research (Week 1)

**Task list:**
```
Tasks created by team-lead:

1. [content-strategist] Research 10 competitor design studio portfolios
   Status: pending

2. [content-strategist] Analyze messaging and positioning patterns
   Status: pending
   Depends: 1

3. [visual-designer] Create mood board from research
   Status: pending

4. [visual-designer] Define visual direction and style
   Status: pending
   Depends: 3

5. [tech-dev] Evaluate platform options (Next.js, Astro, Webflow, etc.)
   Status: pending

6. [tech-dev] Recommendation with pros/cons/costs
   Status: pending
   Depends: 5

7. [seo-specialist] Keyword research for "Seattle design studio"
   Status: pending

8. [seo-specialist] Create SEO strategy document
   Status: pending
   Depends: 7
```

**Agent activities (parallel):**

*content-strategist claims task 1:*
- Researches competitor sites
- Analyzes positioning, services offered, tone of voice
- Documents findings in `/workspace/team-files/research/competitor-analysis.md`
- Marks task 1 complete, claims task 2

*visual-designer claims task 3:*
- Collects visual inspiration
- Creates mood board
- Documents in `/workspace/team-files/research/mood-board.md`
- Marks task 3 complete, claims task 4

*tech-dev claims task 5:*
- Evaluates Next.js, Astro, Webflow, Framer
- Tests each platform quickly
- Documents pros/cons/costs
- Marks task 5 complete, claims task 6

*seo-specialist claims task 7:*
- Keyword research using SEO tools
- Competitive SEO analysis
- Documents keywords and search volume
- Marks task 7 complete, claims task 8

**Coordination examples:**

*content-strategist → visual-designer:*
```
"I noticed several competitors lead with large photography. Our research
shows this resonates with the audience. Consider photography-forward
layouts in your visual direction."
```

*visual-designer → content-strategist:*
```
"Looking at minimalist direction with generous whitespace. This will
affect content strategy—we'll need concise, punchy copy rather than
long explanations. Can you plan accordingly?"
```

**Phase 2 completion:**
- All research tasks marked complete
- team-lead runs verification gate:
  - Reviews all research documents
  - Ensures consistency across findings
  - Approves to proceed to planning phase

#### Phase 3: Planning (Week 2)

**Task list (sequential with reviews):**
```
9. [content-strategist] Create site structure and page outline
   Status: pending
   Depends: 1, 2

10. [content-strategist] Define brand voice and messaging guide
    Status: pending
    Depends: 9

11. [REVIEW-GATE] team-lead reviews content strategy
    Status: pending
    Depends: 10

12. [visual-designer] Design system (typography, colors, spacing)
    Status: pending
    Depends: 4, 11

13. [visual-designer] Homepage mockup
    Status: pending
    Depends: 12

14. [REVIEW-GATE] team-lead reviews design
    Status: pending
    Depends: 13

15. [tech-dev] Technical architecture plan
    Status: pending
    Depends: 6, 14

16. [tech-dev] Performance and hosting strategy
    Status: pending
    Depends: 15

17. [REVIEW-GATE] team-lead reviews technical plan
    Status: pending
    Depends: 16

18. [seo-specialist] On-page SEO plan
    Status: pending
    Depends: 8, 11

19. [seo-specialist] Technical SEO requirements
    Status: pending
    Depends: 18

20. [REVIEW-GATE] team-lead reviews SEO plan
    Status: pending
    Depends: 19
```

**Agent activities (mostly sequential with some parallel):**

*content-strategist:*
- Creates site structure (Home, Work, About, Services, Contact)
- Defines content for each page
- Creates messaging guide
- Submits for review at task 11

*team-lead review gate 11:*
- Reviews content strategy
- Provides feedback if needed
- If rejected: content-strategist revises and resubmits
- If approved: marks task 11 complete, unblocks design tasks

*visual-designer (after gate 11 passes):*
- Creates design system based on mood board and brand voice
- Creates homepage mockup showing photography-forward approach
- Submits for review at task 14

*tech-dev (works in parallel with design):*
- Recommends Next.js with static generation
- Plans image optimization strategy (important for photography)
- Defines hosting on Vercel or similar
- Waits for design review before finalizing architecture

*seo-specialist (works in parallel):*
- Creates on-page SEO plan (meta tags, headers, alt text)
- Technical SEO requirements (sitemap, structured data, performance)
- Waits for content and design to finalize before implementation

**Coordination during planning:**

*tech-dev → visual-designer:*
```
"For the photography-forward approach, we need to optimize for Core Web
Vitals. Can you design with image lazy loading and progressive loading
in mind? I'm planning to use next/image with blur placeholders."
```

*seo-specialist → content-strategist:*
```
"Your messaging guide is excellent. For SEO, we need to incorporate
target keywords naturally. Primary keyword 'Seattle design studio' should
appear in H1, first paragraph, and at least one more time on homepage."
```

**Phase 3 completion:**
- All planning tasks and review gates complete
- team-lead synthesizes all plans
- Confirms alignment across content, design, tech, SEO
- Approves to proceed to implementation

#### Phase 4: Implementation (Weeks 3-4)

**Task list (parallel with coordination):**
```
21. [content-strategist] Write homepage copy
    Status: pending
    Depends: 11

22. [content-strategist] Write About page copy
    Status: pending
    Depends: 11

23. [content-strategist] Write Services page copy
    Status: pending
    Depends: 11

24. [content-strategist] Write all alt text for images
    Status: pending
    Depends: 21, 22, 23

25. [visual-designer] Create homepage design assets
    Status: pending
    Depends: 14

26. [visual-designer] Create About page design assets
    Status: pending
    Depends: 14

27. [visual-designer] Create Services page design assets
    Status: pending
    Depends: 14

28. [visual-designer] Optimize all images for web
    Status: pending
    Depends: 25, 26, 27

29. [tech-dev] Set up Next.js project
    Status: pending
    Depends: 17

30. [tech-dev] Implement design system in code
    Status: pending
    Depends: 29

31. [tech-dev] Build homepage
    Status: pending
    Depends: 21, 25, 30

32. [tech-dev] Build About page
    Status: pending
    Depends: 22, 26, 30

33. [tech-dev] Build Services page
    Status: pending
    Depends: 23, 27, 30

34. [tech-dev] Implement responsive design
    Status: pending
    Depends: 31, 32, 33

35. [seo-specialist] Create meta tags and structured data
    Status: pending
    Depends: 20

36. [seo-specialist] Set up sitemap and robots.txt
    Status: pending
    Depends: 20
```

**Agent activities (high parallelism):**

*content-strategist (Week 3):*
- Writes all copy according to messaging guide
- Coordinates with visual-designer on image captions
- Creates alt text optimized for SEO and accessibility

*visual-designer (Week 3):*
- Selects and edits photography for each page
- Creates any needed graphics or icons
- Optimizes images (WebP format, multiple sizes)
- Coordinates with tech-dev on image specs

*tech-dev (Week 3-4):*
- Sets up Next.js with TypeScript
- Implements design system (components, styles)
- Builds each page as content and assets become available
- Implements responsive design and performance optimizations
- Heavy coordination with visual-designer on implementation details

*seo-specialist (Week 4):*
- Creates meta tags for each page
- Implements structured data (Person, Organization, LocalBusiness)
- Sets up sitemap and robots.txt
- Coordinates with tech-dev on technical implementation

**Key coordination moments:**

*visual-designer → tech-dev (multiple messages):*
```
"Homepage hero image is 3200x2000px. I've created 5 sizes (400w, 800w,
1200w, 1600w, 2400w) in WebP with JPG fallback. All in /assets/hero/"

"The portfolio grid should show 3 columns on desktop, 2 on tablet, 1 on
mobile. Can you confirm the breakpoints you're using?"

"I'm seeing the font weight looks heavier than the mockup. Are you using
font-display: swap? That might be causing FOUT."
```

*content-strategist → seo-specialist:*
```
"I've incorporated 'Seattle design studio' naturally on the homepage.
Also included 'product design Seattle' and 'brand design services' in
Services copy. Can you review for SEO?"
```

*tech-dev → seo-specialist:*
```
"I've implemented your meta tags. Core Web Vitals are looking good:
LCP: 1.2s, FID: 8ms, CLS: 0.02. Should meet all SEO requirements."
```

**Phase 4 completion:**
- All implementation tasks complete
- Site built and running on staging
- team-lead does preliminary review
- Ready for verification phase

#### Phase 5: Verification (Week 5)

**Task list (independent audits):**
```
37. [tech-dev] Performance audit (Lighthouse, Core Web Vitals)
    Status: pending
    Depends: 34

38. [tech-dev] Accessibility audit (WCAG 2.1 AA)
    Status: pending
    Depends: 34

39. [tech-dev] Cross-browser testing (Chrome, Safari, Firefox)
    Status: pending
    Depends: 34

40. [seo-specialist] SEO audit (technical + on-page)
    Status: pending
    Depends: 35, 36

41. [seo-specialist] Verify all meta tags and structured data
    Status: pending
    Depends: 40

42. [visual-designer] Design QA (compare to mockups)
    Status: pending
    Depends: 34

43. [visual-designer] Mobile design review
    Status: pending
    Depends: 34

44. [content-strategist] Copy review and proofreading
    Status: pending
    Depends: 34

45. [content-strategist] Brand consistency check
    Status: pending
    Depends: 44

46. [FINAL-REVIEW] team-lead final review
    Status: pending
    Depends: 37, 38, 39, 40, 41, 42, 43, 44, 45
```

**Agent activities (all independent verification):**

*tech-dev:*
- Runs Lighthouse audits (targets: 95+ on all metrics)
- WCAG 2.1 AA accessibility check with axe DevTools
- Cross-browser testing on macOS and Windows
- Documents any issues found
- **Verification principle:** Developer doesn't self-grade; but does verify technical metrics

*seo-specialist:*
- Full SEO audit with tools (Screaming Frog, etc.)
- Verifies all meta tags present and correct
- Tests structured data with Google's tool
- Checks sitemap and robots.txt
- **Verification principle:** SEO specialist validates implementation against their plan

*visual-designer:*
- Pixel-perfect comparison to mockups
- Tests responsive design on actual devices
- Verifies color accuracy, typography, spacing
- Checks all images render correctly
- **Verification principle:** Designer verifies implementation matches design

*content-strategist:*
- Proofreads all copy for typos, grammar
- Checks brand voice consistency
- Verifies all alt text present and appropriate
- Tests contact form copy and error messages
- **Verification principle:** Strategist verifies messaging and brand

**Issue resolution (example):**

*seo-specialist finds issue:*
```
Task 40 issue found: Homepage missing meta description.
Creating new task for fix.

New task 46a: [tech-dev] Add meta description to homepage
```

*tech-dev fixes and responds:*
```
Task 46a complete: Added meta description.
seo-specialist please re-verify task 40.
```

*seo-specialist re-verifies:*
```
Task 40 verified: All meta tags now present. Marking complete.
```

**Phase 5 completion:**
- All verification tasks complete
- Issues identified and resolved
- team-lead does final comprehensive review
- Site ready for launch

#### Phase 6: Launch & Cleanup (Week 6)

**Final tasks:**
```
47. [tech-dev] Set up production hosting
    Status: pending

48. [tech-dev] Configure custom domain and SSL
    Status: pending
    Depends: 47

49. [seo-specialist] Submit sitemap to Google Search Console
    Status: pending
    Depends: 48

50. [content-strategist] Set up analytics and tracking
    Status: pending
    Depends: 48

51. [team-lead] Launch site and announce to Tim
    Status: pending
    Depends: 49, 50

52. [team-lead] Archive project documentation
    Status: pending
    Depends: 51
```

**Launch sequence:**

1. tech-dev deploys to production, configures domain
2. seo-specialist submits sitemap, sets up Search Console
3. content-strategist sets up Google Analytics
4. team-lead does final smoke test
5. team-lead announces launch to Tim
6. team-lead archives all project documentation

**Team shutdown:**

```
team-lead → all teammates:
"Studio Moser portfolio site is live at studiomoser.com.
All tasks complete. Requesting team shutdown."

team-lead sends shutdown_request to each teammate:
- content-strategist: Approves shutdown
- visual-designer: Approves shutdown
- tech-dev: Approves shutdown
- seo-specialist: Approves shutdown

team-lead runs TeamDelete
Team resources cleaned up.
```

#### Metrics from this workflow:

**Timeline:**
- 5-6 weeks from start to launch
- Parallelization saved ~40% time vs sequential

**Task count:**
- 52 tasks across 5 agents
- Average 10 tasks per agent
- 4 verification gates

**Coordination messages:**
- ~30 inter-agent messages
- Most critical: design ↔ tech, content ↔ SEO
- Minimal broadcast messages (only for major milestones)

**Quality gates:**
- 4 formal review gates (end of each planning phase)
- Continuous informal review via agent coordination
- Independent verification phase caught all issues

**Success factors:**
- Clear role separation (no overlap)
- Parallel work where possible
- Coordination on dependencies
- Verification principle (agents validate each other's work)
- Team lead orchestrated but didn't implement

---

### Example Workflow: Ausra Photos Feature Development (Detailed)

Let's walk through implementing a specific feature for Ausra Photos.

#### Scenario: Implement Smart Albums Feature

**Feature:** Smart Albums that automatically organize photos based on criteria (date, location, tags, people).

#### Phase 1: Team Setup

**Create team:**
```
Team name: ausra-smart-albums
Members:
- team-lead (product manager, Sonnet 4.5)
- architect (system design, Sonnet 4.5)
- ios-dev (Swift/SwiftUI, Sonnet 4.5)
- mac-dev (Swift/AppKit, Sonnet 4.5)
- backend-dev (sync/storage, Sonnet 4.5)
- qa-tester (testing, Sonnet 4.5)
```

**Initial brief:**
```
Feature: Smart Albums for Ausra Photos
Goal: Users can create dynamic albums based on rules (date, location, tags, people)
Platforms: iOS, macOS, backend sync
Requirements:
- Rule-based filtering (AND/OR logic)
- Real-time updates as photos change
- Sync across devices
- Performance must be excellent (< 100ms to update)

Timeline: 3 weeks
```

#### Phase 2: Architecture (Week 1, Days 1-2)

**Task list:**
```
1. [architect] Design Smart Album data model
   Status: pending

2. [architect] Define rule engine architecture
   Status: pending
   Depends: 1

3. [architect] Design sync protocol for Smart Albums
   Status: pending
   Depends: 1

4. [architect] Performance optimization strategy
   Status: pending
   Depends: 2

5. [REVIEW-GATE] team-lead reviews architecture
   Status: pending
   Depends: 2, 3, 4
```

**architect activities:**

*Task 1: Data model*
```swift
// Documents in /workspace/team-files/architecture/data-model.md

SmartAlbum {
  id: UUID
  name: String
  rules: [Rule]
  matchMode: .all | .any  // AND or OR logic
  created: Date
  modified: Date
  syncToken: String
}

Rule {
  type: .date | .location | .tag | .person
  operator: .equals | .contains | .before | .after | .within
  value: Any
}

// Examples:
// Rule: type = .date, operator = .within, value = "last 30 days"
// Rule: type = .tag, operator = .contains, value = "vacation"
```

*Task 2: Rule engine*
```
Architecture decision: Core Data predicate-based filtering

Approach:
- Convert SmartAlbum rules to NSPredicate
- Leverage Core Data's efficient querying
- Use NSFetchedResultsController for real-time updates
- Cache predicate compilation for performance

Performance target: < 100ms for 10,000 photos
```

*Task 3: Sync protocol*
```
Sync approach: Operational Transform (OT)

Smart Album operations:
- CREATE: Full album definition
- UPDATE_RULES: Rule changes only
- DELETE: Album removal
- RENAME: Name change only

Conflict resolution: Last-write-wins with timestamp
Optimization: Only sync rule changes, not photo membership
```

*Task 4: Performance optimization*
```
Strategies:
1. Lazy evaluation: Only compute membership when album viewed
2. Indexing: Core Data indexes on date, location, tags
3. Incremental updates: When photo changes, only re-evaluate affected albums
4. Background processing: Rule evaluation on background queue
5. Caching: Cache membership until photo or rule changes
```

**Review gate 5:**

team-lead reviews architecture:
- Validates data model supports all requirements
- Confirms sync protocol handles edge cases
- Verifies performance strategy is sound
- Approves architecture, unblocks implementation

#### Phase 3: Platform Implementation (Week 1 Day 3 - Week 2)

**Task list (parallel implementation):**
```
6. [ios-dev] Implement SmartAlbum data model in Core Data
   Status: pending
   Depends: 5

7. [ios-dev] Build rule engine (NSPredicate conversion)
   Status: pending
   Depends: 6

8. [ios-dev] Create Smart Album UI in SwiftUI
   Status: pending
   Depends: 7

9. [ios-dev] Implement rule builder UI
   Status: pending
   Depends: 8

10. [ios-dev] Add real-time updates with NSFetchedResultsController
    Status: pending
    Depends: 8

11. [mac-dev] Implement SmartAlbum data model in Core Data
    Status: pending
    Depends: 5

12. [mac-dev] Build rule engine (NSPredicate conversion)
    Status: pending
    Depends: 11

13. [mac-dev] Create Smart Album UI in AppKit
    Status: pending
    Depends: 12

14. [mac-dev] Implement rule builder UI (macOS style)
    Status: pending
    Depends: 13

15. [mac-dev] Add real-time updates with NSFetchedResultsController
    Status: pending
    Depends: 13

16. [backend-dev] Implement Smart Album sync endpoints
    Status: pending
    Depends: 5

17. [backend-dev] Add OT conflict resolution
    Status: pending
    Depends: 16

18. [backend-dev] Performance optimization (indexing, caching)
    Status: pending
    Depends: 16
```

**Agent activities (parallel):**

*ios-dev (Week 1-2):*
- Implements Core Data model matching architecture
- Builds rule engine that converts SmartAlbum → NSPredicate
- Creates SwiftUI views for Smart Albums
- Builds rule builder UI (intuitive, touch-friendly)
- Wires up NSFetchedResultsController for live updates
- **Documents iOS-specific implementation decisions**

*mac-dev (Week 1-2):*
- Implements Core Data model (identical to iOS)
- Builds rule engine (shares logic with iOS via framework)
- Creates AppKit views for Smart Albums
- Builds rule builder UI (keyboard-friendly, native Mac controls)
- Wires up NSFetchedResultsController for live updates
- **Documents macOS-specific implementation decisions**

*backend-dev (Week 1-2):*
- Creates Smart Album API endpoints (CRUD operations)
- Implements OT-based sync with conflict resolution
- Adds database indexing for performance
- Implements caching layer
- **Documents API and sync protocol**

**Coordination during implementation:**

*ios-dev → mac-dev:*
```
"I've implemented the rule engine in a shared framework at
AusraCore/RuleEngine.swift. You can import this directly rather than
duplicating the logic. NSPredicate generation works the same on both
platforms."
```

*mac-dev → ios-dev:*
```
"Thanks! Using the shared rule engine. I added a few helper methods for
date range generation—pushed to AusraCore. You might want to use them for
'Last 30 days' presets."
```

*backend-dev → ios-dev, mac-dev:*
```
"API endpoints are live on staging. Sync protocol:

POST /api/v1/smart-albums - Create
PUT /api/v1/smart-albums/{id} - Update
DELETE /api/v1/smart-albums/{id} - Delete
GET /api/v1/smart-albums/sync?since={token} - Sync

Full documentation at /docs/api/smart-albums.md
```

*ios-dev → backend-dev:*
```
"Testing sync now. Found issue: When I create album with 5 rules, sync
response only includes 4. Looks like 'location' rules aren't serializing
correctly. Can you check Rule serialization?"
```

*backend-dev → ios-dev:*
```
"Fixed! LocationRule wasn't registered in JSON encoder. Deployed fix to
staging. Can you re-test?"
```

*ios-dev → backend-dev:*
```
"Confirmed fixed. All rules syncing correctly now."
```

#### Phase 4: Integration & Testing (Week 2-3)

**Task list:**
```
19. [ios-dev] Integrate iOS app with backend sync
    Status: pending
    Depends: 10, 16

20. [ios-dev] Write unit tests for rule engine
    Status: pending
    Depends: 19

21. [mac-dev] Integrate macOS app with backend sync
    Status: pending
    Depends: 15, 16

22. [mac-dev] Write unit tests for rule engine
    Status: pending
    Depends: 21

23. [backend-dev] Write API tests for all endpoints
    Status: pending
    Depends: 17, 18

24. [qa-tester] Create cross-platform test plan
    Status: pending
    Depends: 19, 21

25. [qa-tester] Test iOS Smart Albums (all scenarios)
    Status: pending
    Depends: 20, 24

26. [qa-tester] Test macOS Smart Albums (all scenarios)
    Status: pending
    Depends: 22, 24

27. [qa-tester] Test sync between devices
    Status: pending
    Depends: 23, 25, 26

28. [qa-tester] Performance testing (10k+ photos)
    Status: pending
    Depends: 27

29. [REVIEW-GATE] All tests pass
    Status: pending
    Depends: 25, 26, 27, 28
```

**qa-tester activities:**

*Task 24: Test plan*
```
Smart Albums Test Plan
======================

Test Scenarios:

1. Album Creation
   - Create album with single rule (date)
   - Create album with multiple rules (AND logic)
   - Create album with multiple rules (OR logic)
   - Create album with each rule type (date, location, tag, person)

2. Album Updates
   - Add rule to existing album
   - Remove rule from album
   - Change rule operator
   - Change rule value
   - Rename album

3. Real-time Updates
   - Add photo matching album rules (should appear immediately)
   - Remove photo from album (edit tags)
   - Change photo date (should move albums)

4. Sync
   - Create album on iOS, verify appears on Mac
   - Create album on Mac, verify appears on iOS
   - Edit album on iOS, verify updates on Mac
   - Delete album on Mac, verify deletes on iOS
   - Conflict test: Edit same album on both devices offline

5. Performance
   - Create album with complex rules on library of 10,000 photos
   - Measure time to compute membership (target: < 100ms)
   - Measure time to update when photo changes (target: < 50ms)

6. Edge Cases
   - Album with no matching photos
   - Album with rules that match all photos
   - Album with invalid rule (date in future)
   - Sync with poor network (timeout handling)
```

*Task 25-26: Platform testing*
- Executes all scenarios on each platform
- Documents bugs found
- Verifies fixes

*Task 27: Sync testing*
```
Sync Test Results:

✅ Create on iOS → Appears on Mac (2.3s)
✅ Create on Mac → Appears on iOS (1.8s)
✅ Edit on iOS → Updates on Mac (1.2s)
✅ Delete on Mac → Deletes on iOS (0.9s)
❌ CONFLICT: Edit on both devices offline → Sync fails with error

Bug filed: Conflict resolution not handling rule updates correctly
Assigned to: backend-dev
```

*backend-dev fixes conflict resolution bug:*
```
Fixed conflict resolution. Issue was timestamp comparison using device
time instead of server time. Now using server timestamp. Deployed to
staging. qa-tester please re-test task 27.
```

*qa-tester re-tests:*
```
✅ CONFLICT: Edit on both devices offline → Last-write-wins correctly
Sync conflict test now passes. Task 27 complete.
```

*Task 28: Performance testing*
```
Performance Test Results (10,000 photo library):

✅ Album creation with 1 rule: 45ms
✅ Album creation with 5 rules (AND): 78ms
✅ Album creation with 5 rules (OR): 82ms
✅ Photo change triggering album update: 23ms
✅ Album rule change recomputation: 61ms

All performance targets met (< 100ms). Task 28 complete.
```

**Review gate 29:**

team-lead reviews all test results:
- All functional tests pass
- All sync tests pass
- Performance targets met
- No critical bugs remaining
- Approves feature as ready for release

#### Phase 5: Documentation & Release (Week 3)

**Task list:**
```
30. [architect] Write technical documentation
    Status: pending
    Depends: 29

31. [ios-dev] Add inline code comments
    Status: pending
    Depends: 29

32. [mac-dev] Add inline code comments
    Status: pending
    Depends: 29

33. [team-lead] Create release notes
    Status: pending
    Depends: 29

34. [team-lead] Update user-facing help docs
    Status: pending
    Depends: 29

35. [team-lead] Merge to main branch
    Status: pending
    Depends: 30, 31, 32, 33, 34
```

**Final activities:**

*architect:* Documents architecture decisions, data model, sync protocol
*ios-dev, mac-dev:* Add code comments for future maintainability
*team-lead:* Creates release notes, updates help docs, merges feature

**Team shutdown:**

```
team-lead → all teammates:
"Smart Albums feature complete and merged. Release notes published.
Great work everyone! Requesting team shutdown."

Team shutdown sequence:
- architect: Approves
- ios-dev: Approves
- mac-dev: Approves
- backend-dev: Approves
- qa-tester: Approves

TeamDelete executed. Team resources cleaned up.
```

#### Metrics from this workflow:

**Timeline:**
- 3 weeks from architecture to release
- 2 platforms + backend implemented in parallel

**Task count:**
- 35 tasks across 6 agents
- Heavy parallelization in implementation phase

**Coordination messages:**
- ~25 inter-agent messages
- Most critical: iOS ↔ Mac ↔ Backend coordination
- Bug discovery and resolution via QA ↔ Devs

**Quality outcomes:**
- 1 sync bug found and fixed during testing
- Performance targets exceeded
- Cross-platform feature parity achieved

**Success factors:**
- Solid architecture phase prevented rework
- Shared code between iOS and Mac (rule engine)
- Dedicated QA agent caught bugs before release
- Backend dev and platform devs coordinated tightly
- Verification principle: QA validated all implementations

---

## 6. Implementation Plan

### Step-by-Step Setup Instructions

#### Step 1: Enable Agent Teams in NanoClaw

NanoClaw already has team coordination built-in via the TeamCreate tool and SendMessage tool. No additional installation required.

**Verify team tools are available:**

1. Check that TeamCreate tool exists in tool definitions
2. Check that SendMessage tool exists with all message types
3. Check that TaskCreate, TaskUpdate, TaskList tools exist

These should all be available in NanoClaw by default based on the CLAUDE.md system instructions.

#### Step 2: Create Workflow Templates

Create workflow template files that define common patterns. Store these in `/workspace/project/groups/global/workflows/`.

**Example: Feature Development Workflow Template**

```markdown
# Feature Development Workflow

## Overview
Multi-agent workflow for implementing new features with parallel development and verification gates.

## Agent Roles

### Architect
- **Responsibilities:** System design, data models, API specifications
- **Agent Type:** full-capability
- **Tools:** Read, Write, Edit, Bash
- **Verification:** Team lead reviews architecture before implementation begins

### Platform Developers (iOS, macOS, Backend, Frontend, etc.)
- **Responsibilities:** Implementation on their respective platforms
- **Agent Type:** full-capability
- **Tools:** Read, Write, Edit, Bash
- **Verification:** QA tests implementation against requirements

### QA Tester
- **Responsibilities:** Test planning, execution, bug verification
- **Agent Type:** full-capability
- **Tools:** Read, Write, Bash
- **Verification:** All tests must pass before release

### Documentation Writer (Optional)
- **Responsibilities:** Technical docs, user guides, API docs
- **Agent Type:** full-capability
- **Tools:** Read, Write
- **Verification:** Team lead reviews documentation

## Workflow Phases

### Phase 1: Architecture (Sequential)
1. Architect: Design system
2. Architect: Create specifications
3. **GATE:** Team lead reviews and approves architecture
4. Proceed to implementation

### Phase 2: Implementation (Parallel)
1. Each platform developer implements concurrently
2. Developers coordinate on shared components
3. Documentation writer drafts docs in parallel
4. Each developer writes unit tests
5. **GATE:** QA reviews test coverage

### Phase 3: Integration (Sequential)
1. QA: Create integration test plan
2. QA: Test each platform independently
3. QA: Test cross-platform integration (if applicable)
4. QA: Performance testing
5. **GATE:** All tests pass

### Phase 4: Release (Sequential)
1. Documentation: Finalize docs with screenshots
2. Team lead: Create release notes
3. Team lead: Merge and release
4. Team shutdown

## Verification Principles

1. **Architects don't implement** - Clear separation between design and implementation
2. **Developers don't self-grade** - QA validates all implementations
3. **Independent verification** - Each agent verifies from their perspective
4. **Gates are blocking** - Cannot proceed until gate passes

## Task Breakdown Example

For feature "Smart Albums":
- [Arch] Design data model
- [Arch] Design sync protocol
- [GATE] Architecture review
- [iOS] Implement data model (depends: GATE)
- [Mac] Implement data model (depends: GATE)
- [Backend] Implement sync endpoints (depends: GATE)
- [iOS] Build UI (depends: [iOS] data model)
- [Mac] Build UI (depends: [Mac] data model)
- [Docs] Draft user guide (depends: [Arch])
- [iOS] Write tests (depends: [iOS] UI)
- [Mac] Write tests (depends: [Mac] UI)
- [Backend] Write tests (depends: [Backend] sync)
- [QA] Create test plan (depends: all implementations)
- [QA] Test iOS (depends: [QA] test plan)
- [QA] Test Mac (depends: [QA] test plan)
- [QA] Test sync (depends: [QA] iOS, [QA] Mac)
- [GATE] All tests pass
- [Docs] Finalize with screenshots (depends: GATE)
- [Lead] Release (depends: [Docs])
```

**Example: Website Development Workflow Template**

```markdown
# Website Development Workflow

## Overview
Multi-agent workflow for building websites with parallel work on content, design, implementation, and SEO.

## Agent Roles

### Content Strategist
- **Responsibilities:** Site structure, copywriting, brand voice
- **Agent Type:** full-capability
- **Verification:** Team lead reviews messaging and voice

### Visual Designer
- **Responsibilities:** Visual design, mockups, assets
- **Agent Type:** full-capability
- **Verification:** Team lead reviews design against brand

### Technical Developer
- **Responsibilities:** Implementation, performance, hosting
- **Agent Type:** full-capability
- **Verification:** Technical metrics (Lighthouse, accessibility)

### SEO Specialist
- **Responsibilities:** SEO strategy, optimization, analytics
- **Agent Type:** full-capability
- **Verification:** SEO audit passes all checks

## Workflow Phases

### Phase 1: Research (Parallel)
1. Content Strategist: Competitor analysis, positioning
2. Visual Designer: Mood board, visual research
3. Technical Developer: Platform evaluation
4. SEO Specialist: Keyword research, SEO strategy
5. All agents coordinate on findings

### Phase 2: Planning (Sequential with reviews)
1. Content Strategist: Site structure and messaging
2. **GATE:** Team lead reviews content strategy
3. Visual Designer: Design system and mockups
4. **GATE:** Team lead reviews design
5. Technical Developer: Architecture plan
6. **GATE:** Team lead reviews technical plan
7. SEO Specialist: SEO implementation plan
8. **GATE:** Team lead reviews SEO plan

### Phase 3: Implementation (Parallel)
1. Content Strategist: Write all copy
2. Visual Designer: Create all assets
3. Technical Developer: Build site
4. SEO Specialist: Create meta tags, structured data
5. Heavy coordination between Developer and Designer
6. Coordination between Strategist and SEO on copy

### Phase 4: Verification (Independent audits)
1. Technical Developer: Performance, accessibility, cross-browser
2. SEO Specialist: SEO audit, verify implementation
3. Visual Designer: Design QA, responsive testing
4. Content Strategist: Copy review, brand consistency
5. **GATE:** All audits pass

### Phase 5: Launch (Sequential)
1. Technical Developer: Production deployment
2. SEO Specialist: Submit sitemap, analytics
3. Team lead: Final review and launch announcement
4. Team shutdown

## Verification Principles

1. **Cross-functional review** - Designer reviews developer's implementation
2. **Independent audits** - Each agent audits from their domain
3. **Technical metrics** - Lighthouse scores, Core Web Vitals
4. **SEO validation** - All meta tags, structured data verified

## Coordination Points

Key moments requiring agent coordination:
- Designer → Developer: Image specs, responsive breakpoints, animations
- Content → SEO: Keyword integration, meta descriptions
- Developer → SEO: Technical SEO implementation
- Designer → Content: Image captions, alt text
```

**Example: Bug Fix Workflow Template**

```markdown
# Bug Fix Workflow

## Overview
Multi-agent workflow for investigating and fixing bugs with verification.

## Agent Roles

### Investigator
- **Responsibilities:** Root cause analysis, reproduction
- **Agent Type:** full-capability
- **Verification:** Must reproduce bug reliably

### Fixer
- **Responsibilities:** Implement fix, write tests
- **Agent Type:** full-capability
- **Verification:** QA verifies fix works

### QA Tester
- **Responsibilities:** Verify fix, regression testing
- **Agent Type:** full-capability
- **Verification:** Original bug fixed, no regressions

## Workflow Phases

### Phase 1: Investigation (Sequential)
1. Investigator: Reproduce bug
2. Investigator: Identify root cause
3. Investigator: Document findings
4. **GATE:** Team lead confirms reproduction and cause

### Phase 2: Fix (Sequential)
1. Fixer: Implement fix
2. Fixer: Write test case for bug
3. Fixer: Verify fix locally
4. **GATE:** Fixer confirms fix ready for QA

### Phase 3: Verification (Sequential)
1. QA: Verify original bug is fixed
2. QA: Run regression test suite
3. QA: Test edge cases
4. **GATE:** All tests pass

### Phase 4: Release (Sequential)
1. Team lead: Review fix and tests
2. Team lead: Merge and release
3. Team shutdown

## Verification Principles

1. **Separate investigation from fixing** - Fresh perspective
2. **Developers don't self-grade** - QA verifies all fixes
3. **Regression testing required** - Ensure fix doesn't break other things
4. **Test case required** - Every bug gets a test to prevent recurrence
```

#### Step 3: Create Project-Specific Configuration

For each of Tim's projects, create a configuration file defining the team structure.

**Create directory:**
```bash
mkdir -p /workspace/project/groups/global/project-configs
```

**Example: Studio Moser Project Config**

```yaml
# /workspace/project/groups/global/project-configs/studio-moser.yaml

project:
  name: Studio Moser Portfolio Website
  description: Modern portfolio showcasing design work and photography
  type: website
  workflow_template: website-development

team:
  name: studio-moser-portfolio
  lead:
    agent_type: coordinator
    model: sonnet-4.5

  members:
    - name: content-strategist
      agent_type: full-capability
      model: sonnet-4.5
      role: Content Strategist
      responsibilities:
        - Site structure and messaging
        - Copywriting and brand voice
        - Content strategy

    - name: visual-designer
      agent_type: full-capability
      model: sonnet-4.5
      role: Visual Designer
      responsibilities:
        - Visual design and mockups
        - Design assets creation
        - Design QA

    - name: tech-dev
      agent_type: full-capability
      model: sonnet-4.5
      role: Technical Developer
      responsibilities:
        - Website implementation
        - Performance optimization
        - Hosting and deployment

    - name: seo-specialist
      agent_type: full-capability
      model: sonnet-4.5
      role: SEO Specialist
      responsibilities:
        - SEO strategy
        - On-page and technical SEO
        - Analytics setup

phases:
  - name: Research
    type: parallel
    agents: [content-strategist, visual-designer, tech-dev, seo-specialist]
    gate_required: false

  - name: Planning
    type: sequential
    agents: [content-strategist, visual-designer, tech-dev, seo-specialist]
    gate_required: true
    gate_reviewer: team-lead

  - name: Implementation
    type: parallel
    agents: [content-strategist, visual-designer, tech-dev, seo-specialist]
    gate_required: false
    coordination: high

  - name: Verification
    type: parallel
    agents: [content-strategist, visual-designer, tech-dev, seo-specialist]
    gate_required: true
    gate_reviewer: team-lead

  - name: Launch
    type: sequential
    agents: [tech-dev, seo-specialist, team-lead]
    gate_required: false

verification_gates:
  - name: Content Strategy Review
    phase: Planning
    reviewer: team-lead
    criteria:
      - Site structure is clear and logical
      - Brand voice is well-defined
      - Messaging aligns with target audience

  - name: Design Review
    phase: Planning
    reviewer: team-lead
    criteria:
      - Design matches brand direction
      - Mockups are complete
      - Responsive design considered

  - name: Technical Review
    phase: Planning
    reviewer: team-lead
    criteria:
      - Platform choice justified
      - Performance strategy defined
      - Hosting plan clear

  - name: SEO Review
    phase: Planning
    reviewer: team-lead
    criteria:
      - Keyword strategy documented
      - Technical SEO plan complete
      - Analytics plan defined

  - name: Final Verification
    phase: Verification
    reviewer: team-lead
    criteria:
      - Lighthouse score 95+ (all metrics)
      - SEO audit passes
      - Design QA complete
      - Copy reviewed
```

**Example: Ausra Photos Project Config**

```yaml
# /workspace/project/groups/global/project-configs/ausra-photos.yaml

project:
  name: Ausra Photos
  description: Native photo management app for Mac, iPad, iOS
  type: native-app
  platforms: [ios, macos, ipad]
  workflow_template: feature-development

team:
  name: ausra-photos-team
  lead:
    agent_type: product-manager
    model: sonnet-4.5

  members:
    - name: architect
      agent_type: full-capability
      model: sonnet-4.5
      role: System Architect
      responsibilities:
        - System design and data models
        - API specifications
        - Performance strategy
      verification: Team lead reviews architecture

    - name: ios-dev
      agent_type: full-capability
      model: sonnet-4.5
      role: iOS Developer
      responsibilities:
        - iOS implementation (Swift/SwiftUI)
        - iOS-specific features
        - iOS unit tests
      verification: QA tests iOS implementation

    - name: mac-dev
      agent_type: full-capability
      model: sonnet-4.5
      role: macOS Developer
      responsibilities:
        - macOS implementation (Swift/AppKit)
        - Mac-specific features
        - macOS unit tests
      verification: QA tests macOS implementation

    - name: backend-dev
      agent_type: full-capability
      model: sonnet-4.5
      role: Backend Developer
      responsibilities:
        - Sync and backup services
        - API implementation
        - Backend tests
      verification: QA tests API and sync

    - name: qa-tester
      agent_type: full-capability
      model: sonnet-4.5
      role: QA Tester
      responsibilities:
        - Test planning
        - Cross-platform testing
        - Bug verification
        - Performance testing
      verification: All tests must pass

phases:
  - name: Architecture
    type: sequential
    agents: [architect]
    gate_required: true
    gate_reviewer: team-lead

  - name: Implementation
    type: parallel
    agents: [ios-dev, mac-dev, backend-dev]
    gate_required: false
    coordination: high

  - name: Integration
    type: sequential
    agents: [ios-dev, mac-dev, backend-dev, qa-tester]
    gate_required: true
    gate_reviewer: qa-tester

  - name: Verification
    type: parallel
    agents: [qa-tester]
    gate_required: true
    gate_reviewer: team-lead

  - name: Release
    type: sequential
    agents: [team-lead]
    gate_required: false

coordination_patterns:
  - agents: [ios-dev, mac-dev]
    pattern: shared-code
    description: Share rule engine and core logic via framework

  - agents: [ios-dev, backend-dev]
    pattern: api-integration
    description: Coordinate on API contracts and testing

  - agents: [mac-dev, backend-dev]
    pattern: api-integration
    description: Coordinate on API contracts and testing

verification_gates:
  - name: Architecture Review
    phase: Architecture
    reviewer: team-lead
    criteria:
      - Data model supports all requirements
      - Sync protocol handles conflicts
      - Performance strategy is sound

  - name: Integration Tests Pass
    phase: Integration
    reviewer: qa-tester
    criteria:
      - All unit tests pass
      - Integration tests pass
      - No critical bugs

  - name: Final Verification
    phase: Verification
    reviewer: team-lead
    criteria:
      - All platforms tested
      - Sync tested cross-platform
      - Performance targets met
      - No regressions
```

#### Step 4: Create Helper Script for Team Creation

Create a script that reads project configs and creates teams using NanoClaw's built-in tools.

**Create script:**

```bash
# /workspace/project/groups/global/scripts/create-team.sh

#!/bin/bash
# Helper script to create multi-agent teams from project configs

PROJECT_CONFIG=$1

if [ -z "$PROJECT_CONFIG" ]; then
    echo "Usage: ./create-team.sh <project-config-file>"
    exit 1
fi

if [ ! -f "$PROJECT_CONFIG" ]; then
    echo "Error: Config file not found: $PROJECT_CONFIG"
    exit 1
fi

echo "Creating team from config: $PROJECT_CONFIG"
echo "This script will output the prompt to send to Claude to create the team."
echo ""
echo "=== TEAM CREATION PROMPT ==="
echo ""

# Parse YAML and generate prompt
# (In practice, you'd use a YAML parser or ask Claude to read the config)

echo "Read the project configuration at: $PROJECT_CONFIG"
echo ""
echo "Then create a multi-agent team according to the configuration:"
echo "1. Use TeamCreate to create the team with the specified name"
echo "2. Spawn each teammate listed in the config using Task tool"
echo "3. Assign each teammate their role and responsibilities"
echo "4. Create initial task list based on the workflow phases"
echo "5. Send initial briefing to all teammates"
echo ""
echo "Make sure to follow the verification gates defined in the config."
```

**Make executable:**
```bash
chmod +x /workspace/project/groups/global/scripts/create-team.sh
```

#### Step 5: Create Team Management Commands

Tim can issue simple commands to create and manage teams.

**Example commands:**

```
"Create a team for Studio Moser portfolio website using the studio-moser config"

"Create a team for implementing Smart Albums in Ausra Photos"

"Show me all active teams"

"Shut down the studio-moser-portfolio team"

"Create a bug-fix team to investigate the photo import crash"
```

#### Step 6: File Structure and Conventions

**Directory structure:**

```
/workspace/project/groups/global/
├── workflows/
│   ├── feature-development.md
│   ├── website-development.md
│   ├── bug-fix.md
│   └── research-and-design.md
├── project-configs/
│   ├── studio-moser.yaml
│   ├── ausra-photos.yaml
│   ├── ebook-reader.yaml
│   └── shopify-store.yaml
├── scripts/
│   ├── create-team.sh
│   └── team-status.sh
└── docs/
    ├── multi-agent-guide.md
    └── verification-gates.md

/workspace/group/active-teams/
├── studio-moser-portfolio/
│   ├── team-brief.md
│   ├── task-list.md
│   └── coordination-log.md
├── ausra-smart-albums/
│   ├── team-brief.md
│   ├── task-list.md
│   └── coordination-log.md
└── (other active teams)

~/.claude/teams/
├── studio-moser-portfolio/
│   └── config.json
└── ausra-smart-albums/
    └── config.json

~/.claude/tasks/
├── studio-moser-portfolio/
│   ├── task-001.json
│   ├── task-002.json
│   └── ...
└── ausra-smart-albums/
    ├── task-001.json
    ├── task-002.json
    └── ...
```

**File naming conventions:**

- Team names: lowercase with hyphens (e.g., `studio-moser-portfolio`)
- Agent names: lowercase with hyphens (e.g., `content-strategist`, `ios-dev`)
- Task IDs: Prefix with agent role (e.g., `[iOS]`, `[Content]`, `[QA]`)
- Task dependencies: Use task IDs (e.g., `depends: 5, 7, 9`)

#### Step 7: Communication Patterns Between Agents

**Message types and when to use them:**

1. **Direct Message (type: "message")** - Default choice
   - Use for: Coordination, questions, feedback to one specific agent
   - Example: "ios-dev → mac-dev: I've pushed the shared rule engine to AusraCore"

2. **Broadcast (type: "broadcast")** - Use sparingly
   - Use for: Critical blockers, major milestones, urgent team-wide issues
   - Example: "Found critical security vulnerability, all agents stop work"

3. **Shutdown Request** - End of project
   - Use when: All tasks complete, ready to clean up
   - Example: "Team lead → all: Project complete, requesting shutdown"

**Communication best practices:**

- **Be specific:** Include file paths, task IDs, specific issues
- **Coordinate early:** Message dependent agents before finishing your task
- **Document decisions:** Important decisions go in team coordination log
- **Use task updates:** Mark tasks complete immediately, don't wait
- **Challenge each other:** Agents should provide critical feedback
- **Verify upstream work:** Downstream agents validate upstream work

**Example communication flow:**

```
[Architect finishes data model]
architect → team-lead: "Task 1 complete: Data model documented at
/workspace/team-files/architecture/data-model.md. Ready for review."

[Team lead reviews]
team-lead → architect: "Data model approved. One suggestion: Add index on
date field for performance. Otherwise looks good."

architect → team-lead: "Index added to data model. Updated documentation."

team-lead: [Marks architecture gate task as complete]
team-lead → ios-dev, mac-dev, backend-dev: "Architecture approved. You can
begin implementation. Data model at /workspace/team-files/architecture/
data-model.md"

[Developers begin parallel implementation]
ios-dev: [Claims task: Implement data model]
mac-dev: [Claims task: Implement data model]
backend-dev: [Claims task: Implement sync endpoints]

[iOS developer encounters issue]
ios-dev → architect: "Question about data model: Should SmartAlbum.rules
be ordered? The spec doesn't clarify."

architect → ios-dev: "Good catch. Rules should be ordered (user defines
priority). Updated spec to clarify."

ios-dev → mac-dev, backend-dev: "FYI: Rules are ordered. Check updated spec."

[iOS developer shares code]
ios-dev → mac-dev: "I've implemented the rule engine in shared framework
AusraCore/RuleEngine.swift. You can import this instead of duplicating."

mac-dev → ios-dev: "Thanks! Using shared engine. Found I needed to add a
helper for date ranges. Pushed to AusraCore—you might want to use it too."

ios-dev → mac-dev: "Perfect, using your date helpers. Much cleaner."

[Integration begins]
backend-dev → ios-dev, mac-dev: "Sync endpoints ready on staging. Full API
docs at /docs/api/smart-albums.md. Let me know if you hit any issues."

ios-dev: [Tests sync integration]
ios-dev → backend-dev: "Found issue: Location rules not syncing correctly.
Only 4 of 5 rules appeared."

backend-dev → ios-dev: "Investigating... Found it. LocationRule not registered
in JSON encoder. Fixed and deployed to staging."

ios-dev → backend-dev: "Confirmed fixed. All rules syncing now. Thanks!"

[QA verification]
qa-tester → ios-dev, mac-dev, backend-dev: "Beginning integration testing.
Test plan at /workspace/team-files/qa/test-plan.md"

qa-tester: [Finds sync conflict bug]
qa-tester → backend-dev: "Sync conflict test failing. When editing same
album on both devices offline, sync fails with 409 error."

backend-dev → qa-tester: "Fixed conflict resolution. Issue was timestamp
comparison. Re-test when ready."

qa-tester → backend-dev: "Conflict test now passing. Marking task complete."

[Final verification]
qa-tester → team-lead: "All tests pass. Performance targets exceeded.
Feature ready for release."

team-lead → all: "Great work! Feature complete. Proceeding to release."
```

#### Step 8: Monitoring and Management

**How Tim can monitor teams:**

1. **Check active teams:**
   ```
   "Show me all active teams and their status"
   ```

2. **Check specific team:**
   ```
   "What's the status of the studio-moser-portfolio team?"
   ```

3. **View task list:**
   ```
   "Show me the task list for ausra-smart-albums team"
   ```

4. **Message a specific agent:**
   ```
   "Tell the ios-dev on ausra-smart-albums team to prioritize the sync bug"
   ```

5. **Shut down a team:**
   ```
   "Shut down the studio-moser-portfolio team"
   ```

**Automated monitoring (optional):**

Create a monitoring script that checks team status periodically:

```bash
# /workspace/project/groups/global/scripts/monitor-teams.sh

#!/bin/bash
# Monitor active teams and report status

TEAMS_DIR="$HOME/.claude/teams"

echo "=== Active Teams ==="
echo ""

for team_dir in "$TEAMS_DIR"/*; do
    if [ -d "$team_dir" ]; then
        team_name=$(basename "$team_dir")
        config="$team_dir/config.json"

        if [ -f "$config" ]; then
            echo "Team: $team_name"

            # Count members
            member_count=$(jq '.members | length' "$config")
            echo "  Members: $member_count"

            # Count tasks
            tasks_dir="$HOME/.claude/tasks/$team_name"
            if [ -d "$tasks_dir" ]; then
                task_count=$(ls "$tasks_dir" | wc -l)
                pending=$(grep -l '"status":"pending"' "$tasks_dir"/* 2>/dev/null | wc -l)
                in_progress=$(grep -l '"status":"in_progress"' "$tasks_dir"/* 2>/dev/null | wc -l)
                completed=$(grep -l '"status":"completed"' "$tasks_dir"/* 2>/dev/null | wc -l)

                echo "  Tasks: $task_count total ($pending pending, $in_progress in progress, $completed completed)"
            fi

            echo ""
        fi
    fi
done
```

#### Step 9: Example Workflows for Each Project Type

**For Studio Moser (Website):**

```
"Create a team for the Studio Moser portfolio website. Use the website-
development workflow with 4 agents: content strategist, visual designer,
technical developer, and SEO specialist. Follow the verification gates
defined in the studio-moser project config."
```

**For Ausra Photos (Feature):**

```
"Create a team to implement Smart Albums for Ausra Photos. Use the feature-
development workflow with 6 agents: architect, iOS developer, macOS developer,
backend developer, QA tester, and documentation writer. Architecture must be
reviewed before implementation begins."
```

**For Bug Fix:**

```
"Create a bug-fix team to investigate the photo import crash in Ausra Photos.
Use 3 agents: investigator, fixer, and QA tester. Follow the bug-fix workflow
with verification gates."
```

**For Research:**

```
"Create a research team to explore ebook reader features. Use 4 agents with
competing perspectives: market researcher, technical specialist, UX designer,
and monetization strategist. Have them challenge each other's findings."
```

#### Step 10: Scaling and Optimization

**When to use agent teams:**

✅ **Use teams when:**
- Complex project with multiple independent work streams
- Cross-functional work (design + dev + SEO + content)
- Parallel exploration (competing hypotheses)
- Large feature spanning multiple platforms
- Verification gates needed (QA separate from dev)

❌ **Don't use teams when:**
- Simple, single task
- Sequential work with heavy dependencies
- Same-file edits (will cause conflicts)
- Quick fixes or minor changes
- Only one perspective needed

**Token optimization:**

1. **Right-size teams:** Don't add agents without clear roles
2. **Shut down promptly:** Clean up teams when work is complete
3. **Avoid broadcasts:** Use direct messages instead
4. **Reuse agents:** Same agent can work on multiple sequential tasks
5. **Share context via files:** Don't repeat context in messages

**Performance optimization:**

1. **Maximize parallelism:** Identify work that can happen simultaneously
2. **Minimize blocking:** Only add gates when verification is truly needed
3. **Clear task dependencies:** Use depends field accurately
4. **Agent specialization:** Each agent has one clear domain
5. **Coordinate early:** Agents message dependencies proactively

---

## Summary & Recommendations

### Key Findings

1. **NanoClaw already has sophisticated multi-agent capabilities** — No need to install Antfarm or additional tools

2. **Antfarm's workflow patterns are valuable** — The structure, verification gates, and "developers don't self-grade" principle should be adopted

3. **Real-time coordination is better than polling** — NanoClaw's automatic message delivery is superior to Antfarm's cron-based polling

4. **Container isolation is a major advantage** — NanoClaw's OS-level security is better than OpenClaw/Antfarm's host-based approach

5. **Workflow templates enable consistency** — Creating reusable workflow definitions (inspired by Antfarm's YAML) will help Tim use teams effectively

### Recommended Approach

**Phase 1: Foundation (Week 1)**
- Create workflow templates (feature-dev, website-dev, bug-fix)
- Create project configs for Tim's 5 projects
- Document team creation and management process

**Phase 2: First Project (Weeks 2-3)**
- Start with Studio Moser portfolio website
- Use website-development workflow
- 4-agent team: content, design, dev, SEO
- Document lessons learned

**Phase 3: Expand (Weeks 4+)**
- Apply learnings to Ausra Photos feature development
- Create custom workflows as needed
- Refine verification gate patterns
- Build library of reusable patterns

### Success Metrics

- **Time savings:** Parallel work should reduce project timelines by 30-40%
- **Quality improvements:** Verification gates should catch issues before release
- **Consistency:** Workflow templates should make team creation straightforward
- **Team coordination:** Agents should coordinate autonomously with minimal intervention

### Next Actions for Tim

1. **Review this report** and decide which project to start with
2. **Choose first project** (recommend Studio Moser portfolio for learning)
3. **Request team creation** using a simple command
4. **Monitor team progress** and provide feedback as needed
5. **Document lessons** for future team workflows

---

## Sources & References

### Antfarm
- [GitHub - snarktank/antfarm](https://github.com/snarktank/antfarm)
- [Antfarm — Build your agent team with one command](https://www.antfarm.cool/)

### OpenClaw Multi-Agent
- [Multi-Agent Routing - OpenClaw](https://docs.openclaw.ai/concepts/multi-agent)
- [OpenClaw: Ultimate Guide to AI Agent Workforce 2026](https://o-mega.ai/articles/openclaw-creating-the-ai-agent-workforce-ultimate-guide-2026)
- [Run Multiple OpenClaw AI Agents with Elastic Scaling](https://www.digitalocean.com/blog/openclaw-digitalocean-app-platform)
- [OpenClaw Full Tutorial for Beginners](https://www.freecodecamp.org/news/openclaw-full-tutorial-for-beginners/)

### Claude Agent Teams
- [Orchestrate teams of Claude Code sessions - Official Docs](https://code.claude.com/docs/en/agent-teams)
- [Claude Opus 4.6 Agent Teams Tutorial](https://www.nxcode.io/resources/news/claude-agent-teams-parallel-ai-development-guide-2026)
- [How to Set Up Claude Code Agent Teams](https://darasoba.medium.com/how-to-set-up-and-use-claude-code-agent-teams-and-actually-get-great-results-9a34f8648f6d)
- [Claude Code Agent Teams: Multi-Session Orchestration](https://claudefa.st/blog/guide/agents/agent-teams)
- [Anthropic releases Opus 4.6 with new 'agent teams'](https://techcrunch.com/2026/02/05/anthropic-releases-opus-4-6-with-new-agent-teams/)
- [AddyOsmani.com - Claude Code Swarms](https://addyosmani.com/blog/claude-code-agent-teams/)
- [Anthropic - Building C Compiler](https://www.anthropic.com/engineering/building-c-compiler)

### Multi-Agent Design Patterns
- [The 2026 Guide to AI Agent Workflows](https://www.vellum.ai/blog/agentic-workflows-emerging-architectures-and-design-patterns)
- [Best Practices for AI Agent Implementations: Enterprise Guide 2026](https://onereach.ai/blog/best-practices-for-ai-agent-implementations/)
- [Top AI Agentic Workflow Patterns That Will Lead in 2026](https://medium.com/@Deep-concept/top-ai-agentic-workflow-patterns-that-will-lead-in-2026-0e4755fdc6f6)
- [AI Agent Orchestration Patterns - Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/ai-agent-design-patterns)
- [Guidance for Multi-Agent Orchestration on AWS](https://aws.amazon.com/solutions/guidance/multi-agent-orchestration-on-aws/)
- [Four Design Patterns for Event-Driven, Multi-Agent Systems](https://www.confluent.io/blog/event-driven-multi-agent-systems/)

### NanoClaw
- [GitHub - gavrielc/nanoclaw](https://github.com/gavrielc/nanoclaw)
- [NanoClaw: A Slimmed-Down Version of ClawdBot](https://ai-engineering-trend.medium.com/nanoclaw-a-slimmed-down-version-of-clawdbot-achieved-in-just-500-lines-of-code-c208dc16ee8f)
- [Show HN: NanoClaw](https://news.ycombinator.com/item?id=46850205)

---

**Report End**

*Generated: February 11, 2026*
*Research conducted by: Shelby (NanoClaw)*
*For: Tim @ Studio Moser*
