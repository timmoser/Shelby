# Tim - Profile

## Basic Info
- Name: Tim
- Location: Seattle, WA
- Roles: Designer & Developer
- Business: Studio Moser
- Focus: Digital & physical products, photography

## Active Projects

### Studio Moser
- New portfolio website
- Branding & marketing (direction TBD - to be developed)
- Instagram presence
- Photography services (part of studio offering)

### Ausra Photos
- Photo management and backup app
- Platforms: Native Mac, iPad, iOS
- Status: Existing codebase, Tim building it
- My role: Research, branding, business strategy

### dawnmoser.com
- Portfolio website for wife Dawn (dual-purpose: professional + personal writing)
- Platform: Squarespace (decided)
- Status: Strategy updated & ready for execution (Feb 10, 2026)
- Strategy: Dual-platform serving freelance + full-time opportunities + personal essay blog/newsletter
- Positioning: "Professional Writer. Personal Storyteller."
- Decisions: All personal essays migrate, "contact for pricing", no fixed timeline
- Next: Gather personal essays → Select Squarespace template → Draft all page copy → Build site
- Files: iCloud/Shelby/dawnmoser-com/
- Key docs: NEXT-IMMEDIATE-ACTIONS.md, DECISIONS-MADE.md

### Ebook Reader App
- Name TBD
- In development

### Dawn's Job Hunt
- Goal: Senior content strategy role, $100-130K
- Status: Strategy complete, 5 resume versions created (Feb 10, 2026)
- Market: 46+ Seattle roles, 13% growth
- Deliverables: Job hunt strategy, ghost job detection, tracking systems, LinkedIn templates, 5 tailored resumes
- Resume versions: Master, B2B SaaS, Healthcare, Senior Strategist, Content Marketing Manager
- Next: Start networking & applying, customize resumes per job, LinkedIn profile optimization
- Files: iCloud/Shelby/dawn-job-hunt/
- Key docs: JOB-HUNT-STRATEGY.md, RESUME-VERSIONS-GUIDE.md

### Shopify Store
- Physical products (t-shirts, etc.)
- Name TBD

## Working Style
- Bounces between projects as needed
- No strict priority order

## Communication Preferences
- Less verbose, more to the point
- Friendly, helpful, proactive
- No fluff or over-explanation
- **Messaging Dawn**: Use the collaboration folder (`/workspace/extra/collaboration/`) — drop a file with instructions for Dawn's agent. Do NOT use SendMessage tool. Dawn's agent monitors that folder and responds there.

## Skills & Tools
- Technical: Yes, codes
- Platform: Mac ecosystem
- Primary Tools:
  - Cursor (coding)
  - Claude Code (AI assistance)
  - Figma (design)

## How I Can Help
- Research
- SEO
- Writing
- Design assistance
- Building/development
- Product launches
- Multi-channel marketing

## Notes
- No restricted topics
- Working across multiple products/channels simultaneously
- Mix of creative and technical work
