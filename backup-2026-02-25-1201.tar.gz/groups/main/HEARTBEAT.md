# Heartbeat Checklist

## Step 1: Check for Active Work

Before doing anything else, check if a container is already running for this group. If you're responding to a user message or another task is in progress, skip all checks and respond with `HEARTBEAT_OK`.

## Step 2: System Health

Run these concrete checks:

- Check the last 50 lines of `/workspace/project/logs/nanoclaw.log` for any ERROR or WARN entries from the past hour:
  ```bash
  grep -E "ERROR|WARN" /workspace/project/logs/nanoclaw.log | tail -20
  ```
- Check scheduled task status — did the 3 AM upstream sync and 4 AM backup run?
  ```bash
  sqlite3 /workspace/project/store/messages.db "SELECT id, status, last_run, last_result FROM scheduled_tasks WHERE status='active' ORDER BY last_run DESC;"
  ```
  If any task shows `Error:` in last_result or hasn't run in >24 hours, flag it.

## Step 3: Collaboration Folder

Check `/workspace/extra/collaboration/` for files modified in the last 2 hours. This is the shared workspace with Dawn's agent.

```bash
find /workspace/extra/collaboration/ -type f -mmin -120 -newer /workspace/group/collaboration-watch.log 2>/dev/null
```

If new or modified files exist that weren't there during the last heartbeat, read them and assess urgency.

## Step 4: Project Deadlines & Blockers

Check `/workspace/group/profile.md` and `/workspace/group/session-memory.md` for any items marked as "waiting for Tim" or "next steps" that have been stale for >2 days.

Things to look for:
- Studio Moser: Is Tim's inspiration board review still pending? (Check `/workspace/extra/icloud/studio-moser/`)
- dawnmoser.com: Any files Dawn's agent dropped that need Tim's attention? (Check `/workspace/extra/icloud/dawnmoser-com/`)
- Dawn's job hunt: Any resume review requests sitting untouched? (Check `/workspace/extra/icloud/dawn-job-hunt/`)

Only flag items that have a real deadline or have been waiting >2 days.

## Step 5: In-Progress Research & Brain Trust Rounds

Check if there are any Brain Trust rounds or long-running research tasks that stalled or need follow-up.

```bash
# Check the venture ideas tracker for any rounds marked IN PROGRESS
grep -i "IN PROGRESS\|in_progress" /workspace/extra/icloud/moby-inc/venture-studio/VENTURE-IDEAS-TRACKER.md 2>/dev/null
```

For each round marked IN PROGRESS:
1. Check if the agent output files exist in the corresponding folder (e.g., `venture-studio/ai-infrastructure/agent-*.md`)
2. Check if a `BRAIN-TRUST-FINAL-REPORT.md` exists — if agents wrote output but no final report, the debate moderator never ran
3. Check if the next round in the pipeline was started

If a round's agents completed but the debate was never compiled, or the next round was never kicked off, flag it:
- "Brain Trust Round X agents completed but debate report never compiled — needs moderator run"
- "Brain Trust pipeline stalled after Round X — Rounds Y-Z never started"

Also check `/workspace/group/research/` and workspace for any `work-in-progress-*.md` or breadcrumb files left by a previous session.

## Step 6: (Upstream Sync — Disabled)

Upstream sync check removed from heartbeat per Tim (Feb 21).

## Response Protocol

**CRITICAL: Only send a message if there's an ACTUAL PROBLEM.**

- Everything normal: Reply ONLY `HEARTBEAT_OK` — nothing else, no status report, no checkmarks
- Something needs attention: Send a brief notification using `mcp__nanoclaw__send_message`:
  - What needs attention (1 line)
  - Why it matters (1 line)
  - Recommended action (1 line)

DO NOT send status reports. DO NOT list what you checked. DO NOT say "all systems normal." Tim only wants to hear about problems.

## Self-Maintenance

If this checklist becomes stale (checking for things that no longer apply, missing new data sources), update this file to stay relevant. Keep checks concrete and actionable.
