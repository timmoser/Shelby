# Studio Moser: Site Structure & Content Plan

**Created:** February 11, 2026
**For:** Tim Moser
**Purpose:** Comprehensive plan for Studio Moser website structure, content strategy, and implementation

---

## 1. RECOMMENDED SITE STRUCTURE

### Primary Navigation
```
STUDIO MOSER
├── Home
├── Work (Design & Creative Direction)
├── Photography
├── Products
├── About
└── Contact
```

### URL Structure
```
studiomoser.com/
├── / (homepage)
├── /work
│   ├── /work/[project-slug]
│   └── /work/[client-name]
├── /photography
│   ├── /photography/commercial
│   ├── /photography/personal
│   └── /photography/services
├── /products
│   ├── /products/ausra-photos
│   └── /products/supernormal-games
├── /about
└── /contact
```

### Page Hierarchy

**Homepage** → Three clear entry points (Design, Photography, Products)
**Work Page** → Individual project case studies
**Photography Page** → Gallery categories → Service offerings
**Products Page** → Individual product pages with updates
**About Page** → Full story + credentials
**Contact Page** → Availability + inquiry form

**Optional for Phase 2:** `/writing` or `/updates` (blog for product updates, industry insights)

---

## 2. HOMEPAGE STRATEGY

### Recommended Layout: Story-Driven with Clear Sections

**Hero Section:**
```
TIM MOSER
Creative Director · Photographer · Maker

I've spent 14 years directing creative for Microsoft, Disney, and NPR
at Moby, Inc. I also photograph stories, build apps, and make indie games.

Seattle-based. Always making something.
```

**Three Pillars Section (Visual Cards):**

```
┌─────────────┬─────────────┬─────────────┐
│   DESIGN    │ PHOTOGRAPHY │  PRODUCTS   │
│   [Image]   │   [Image]   │   [Image]   │
│             │             │             │
│ Creative    │ Commercial  │ Building    │
│ direction   │ & personal  │ apps &      │
│ for brands  │ photography │ indie games │
│             │             │             │
│  View Work →│  View →     │  View →     │
└─────────────┴─────────────┴─────────────┘
```

**Featured Work Section:**
- 6-9 featured pieces (mix across all three disciplines)
- Large images with brief captions
- Visual grid or carousel
- Each links to full project/gallery

**Current Focus Section:**
- "What I'm working on now"
- Brief updates on active projects (Ausra Photos, latest game, recent photography)
- Shows momentum and "building in public" approach

**Call-to-Actions:**
- Primary: "Let's work together" → Contact page
- Secondary: "Follow on Instagram" → Social link
- Tertiary: "Join Ausra waitlist" → Product page

### Alternative Layout Options

**Option 2: Three-Column Entry (If clearer separation preferred)**
- Homepage immediately splits into three distinct sections
- Visitor chooses path right away
- Less storytelling, more direct navigation

**Option 3: Unified Feed (All work together)**
- All projects shown together with filters
- Filter: All | Design | Photography | Products
- Best if Tim wants to emphasize range over specialization

**Recommendation: Story-Driven (Option 1)**
Reason: Establishes credibility first, then shows breadth. The Moby background + major clients creates immediate authority, making the multi-disciplinary approach feel intentional rather than scattered.

---

## 3. CORE PAGES CONTENT OUTLINE

### WORK PAGE (Design & Creative Direction)

**Page Purpose:** Showcase 14 years of creative direction experience, primarily from Moby

**Content Sections:**

1. **Introduction**
   ```
   I've directed creative work for Fortune 500 companies and ambitious
   startups for 14 years at Moby, Inc. I manage overall aesthetic and
   visual direction—brand systems, product design, user experience.
   ```

2. **Featured Projects** (5-8 case studies)
   - Microsoft [project name]
   - Disney [project name]
   - NPR [project name]
   - T-Mobile [project name]
   - Notable startup projects
   - Independent Studio Moser projects

3. **Each Case Study Should Include:**
   - Client name
   - Project title
   - Year
   - Tim's role (Creative Director, Visual Director, etc.)
   - Brief description (2-3 sentences for thumbnail view)
   - High-quality hero image
   - **Full case study page includes:**
     - Challenge/Background
     - Approach/Process
     - Role & team
     - Outcomes/Results
     - 5-8 supporting images
     - Technologies/tools used

4. **Project Filters** (optional for Phase 2)
   - All
   - Moby Projects
   - Independent Work
   - Startups
   - Brands

5. **Call-to-Action:**
   - "Need creative direction for your project? Let's talk."
   - Link to contact page

### PHOTOGRAPHY PAGE

**Page Purpose:** Showcase photography work + offer services

**Landing Page Content:**

1. **Hero Image**
   - Best single photograph
   - Spans full width
   - Caption: "Photography by Tim Moser"

2. **Three Categories (Cards or Tabs):**

   **Commercial Work**
   - Product photography
   - Brand documentation
   - Event/corporate photography
   - Client work examples

   **Personal Projects**
   - Travel photography (Pacific Northwest focus)
   - Street photography
   - Documentary work
   - Photo essays (like Paul Stamatiou model)

   **Process Documentation**
   - Behind-scenes of design work
   - Studio photography
   - Product development documentation
   - Shows intersection of design + photography

3. **Photography Services Section**
   ```
   PHOTOGRAPHY SERVICES

   I offer commercial photography for products, brands, and events.

   Services:
   • Product Photography
   • Brand Documentation
   • Event Coverage
   • Process Documentation

   Most projects range from $[X]-$[Y].
   Get in touch for a custom quote.

   [Contact Me]
   ```

4. **Gallery Best Practices (from research):**
   - 15-20 images per category
   - High resolution (2400 x 1600px)
   - Clean, minimal design
   - Simple navigation
   - Lightbox/full-screen viewing

### PRODUCTS PAGE

**Page Purpose:** Showcase active projects + shipped products (building in public approach)

**Content Sections:**

1. **Introduction**
   ```
   I build apps, make indie games, and create tools to solve problems
   I've encountered. Currently focused on Ausra Photos and games at
   Supernormal.
   ```

2. **Active Projects**

   **Ausra Photos**
   ```
   [Screenshot/Mockup]

   AUSRA PHOTOS
   Photo organization and backup, reimagined

   Status: Active development

   What it is: Native Mac, iPad, and iOS app for managing and backing
   up your photo library. Built because existing tools didn't solve my
   actual workflow needs.

   Platform: Mac, iPad, iOS (native)
   Current stage: Private beta
   Next milestone: Public beta Q2 2026

   [Join Waitlist] [See Progress Updates]
   ```

   **[Other Active Projects]**
   - Same format for ebook reader app
   - Same format for any other in-development projects

3. **Shipped Products**

   **Supernormal Games**
   ```
   [Logo/Screenshot]

   SUPERNORMAL GAMES
   Indie game studio

   Depict: Drawing and guessing game
   [Platform info] [Play Now →]

   Chuck the Ball: Fast-paced puzzle game
   [Platform info] [Play Now →]

   [More games →]
   ```

4. **Building in Public Section** (optional for Phase 2)
   - Recent updates
   - Development logs
   - Lessons learned
   - Progress screenshots
   - Link to full updates/blog

5. **Waitlist Components:**
   ```
   Want early access to Ausra Photos?

   [Email Address]
   [Join Waitlist]

   We'll email you when it's ready. No spam, just launch updates.
   ```

### ABOUT PAGE

**Page Purpose:** Tie all disciplines together, establish credibility, explain Studio Moser concept

**Content Outline:**

```markdown
# About Tim Moser

[Photo of Tim - workspace or Seattle background]

## I make things.

For 14 years, I've directed creative work for Microsoft, Disney, T-Mobile,
and NPR as co-founder of Moby, Inc. Along the way, I've co-founded 10
startups, created 25+ brands, and launched an indie game studio because
I can't help but build new things.

Studio Moser is where it all comes together—the design work, the
photography, the products I'm building. It's my complete creative
practice, not just one facet.

## Background

**Design & Creative Direction**
I co-founded Moby with James Jacoby in 2011. We've since built a team
that's created digital products, websites, and mobile apps for Fortune
500 companies and ambitious startups. I manage overall aesthetic and
visual direction—from brand systems to user experience to the final pixel.

**Photography**
The camera is how I see the world. I photograph commercially (products,
brands, events) and personally (travel, street, documentary). I also use
photography to document the design process, turning behind-scenes into
compelling visual stories.

**Products & Games**
I've co-founded 10 startups and currently run Supernormal Games (formerly
Makeshift Games), an indie game studio. Current projects include Ausra
Photos, a photo organization tool I'm building to solve my own frustration
with existing solutions. If I see a problem, I build something to fix it.

## Why "Studio Moser"?

For years, my work lived in different places: Moby for client work,
Supernormal for games, scattered portfolios for photography. Studio Moser
brings it together under one roof.

It's not a separate business—it's the umbrella for everything I make.
Client projects, side products, photography work, experimental apps.
They're all part of the same creative practice, all informed by the same
human-centered design thinking I've honed over 20+ years.

## Currently

- Creative Director at Moby, Inc (Seattle)
- Building Ausra Photos and other tools
- Making indie games at Supernormal
- Photographing the Pacific Northwest
- Taking on select Studio Moser projects

## Education & Background

- Northwest College of Art (2000-2003)
- Seattle-based since [year]
- Active in Seattle creative and indie game communities
- Creator of things visual and musical

## Let's Work Together

Studio Moser takes on 2-3 select projects per quarter. I'm interested in:

- Startups needing enterprise-level creative direction
- Agencies needing senior creative partnership
- Photography projects (commercial or editorial)
- Interesting problems that need creative solutions

If that sounds like your project, get in touch.

---

Email: tim@studiomoser.com
Instagram: @studiomoser
LinkedIn: Tim Moser
```

**Key Elements:**
- Leads with Moby credibility
- Explains breadth as unified practice
- Frames Studio Moser as intentional umbrella
- Shows focus through selectivity (2-3 projects/quarter)
- Clear what he's looking for

### CONTACT PAGE

**Content Sections:**

1. **Current Availability**
   ```
   AVAILABILITY: [Open for select projects | Booked through Q2 2026 | etc.]

   I take on 2-3 Studio Moser projects per quarter alongside my work
   at Moby, Inc.
   ```

2. **What I'm Looking For**
   - Creative direction for startups or agencies
   - Commercial photography projects
   - Interesting design challenges
   - Partnership opportunities

3. **Contact Methods**
   - **Email:** tim@studiomoser.com (primary)
   - **Instagram:** @studiomoser
   - **LinkedIn:** [Profile link]

4. **Contact Form** (optional)
   - Name
   - Email
   - Project type (dropdown: Design, Photography, Products, Other)
   - Message
   - Timeline (dropdown)
   - Budget range (optional)

5. **Response Expectations**
   ```
   I typically respond within 2-3 business days.
   For urgent inquiries, email is fastest.
   ```

---

## 4. CONTENT INVENTORY NEEDED

### Photography Assets Required

**For Homepage:**
- 1 hero image (best single work)
- 3 pillar images (one representing each discipline)
- 6-9 featured work images

**For Photography Page:**
- 15-20 commercial photography images
- 15-20 personal photography images
- 10-15 process documentation images
- 1 hero image for photography landing page

**Specifications:**
- High resolution: 2400 x 1600px minimum
- Mix of orientations (landscape, portrait, square)
- Color-corrected and edited
- Consistent style within each category

### Design Work Screenshots/Images Required

**For Work Page:**
- 5-8 project hero images (one per case study)
- 5-8 supporting images per case study (40-64 images total)
- Screenshots, mockups, final deliverables
- Before/after comparisons if applicable

**Required Information per Project:**
- Client name
- Project title
- Year completed
- Tim's role
- Team members (if notable)
- Challenge/brief description
- Approach/process notes
- Outcomes/results
- Tools/technologies used

**Priority Projects to Document (from research):**
1. Microsoft [specific project]
2. Disney [specific project]
3. NPR [specific project]
4. T-Mobile [specific project]
5. Notable startup work
6. 2-3 independent Studio Moser projects

### Product Screenshots/Mockups Required

**For Products Page:**
- Ausra Photos:
  - Hero screenshot/mockup
  - 3-5 feature screenshots
  - Logo/branding assets
  - App icon
- Supernormal Games:
  - Game logos
  - Screenshots from Depict
  - Screenshots from Chuck the Ball
  - Any other shipped games
- Ebook Reader:
  - Mockups/screenshots if available
  - Or "Coming soon" placeholder

### About Page Assets

- Professional photo of Tim (workspace, studio, or Seattle setting)
- Optional: Behind-scenes photos showing work process
- Optional: Studio/workspace photos

### Copy/Text Needed

**Homepage:**
- Hero tagline (draft provided, can be refined)
- Short descriptions for three pillars (50 words each)
- Featured work captions (1-2 sentences each)
- Current focus updates (3-5 sentences per active project)

**Work Page:**
- Portfolio introduction (100-150 words)
- 5-8 case study descriptions (see format above)
- Each case study: 300-500 words total

**Photography Page:**
- Photography bio (50-100 words)
- Service descriptions (100 words each)
- Pricing framework or inquiry approach
- Gallery/series descriptions (if doing photo essays)

**Products Page:**
- Products introduction (50-100 words)
- Per product:
  - What it is (50 words)
  - Why building it (50 words)
  - Current status (25 words)
  - Next milestone (25 words)

**About Page:**
- Full story (provided in outline, ~500 words)
- Current activities list
- Education/background details
- What looking for (client types)

**Contact Page:**
- Availability statement
- Response time expectations
- Contact preferences

### Credentials/Clients to Highlight

**From Moby Work:**
- Microsoft
- Disney
- T-Mobile
- NPR
- [Any other Fortune 500 or notable clients]

**Startups Co-Founded:**
- List of 10 startups (names if public)
- Or generalize: "10 startups, 25+ brands"

**Game Studio:**
- Supernormal Games (formerly Makeshift Games)
- Published games list
- Platforms

**Education:**
- Northwest College of Art (2000-2003)

**Community:**
- Seattle creative community involvement
- Indie game community involvement
- Any speaking/teaching experience

---

## 5. QUESTIONS FOR TIM

### Design Direction Preferences

1. **Visual Style:** Which design direction resonates most?
   - **Minimalist with Bold Typography** (Frank Chimero style)
     - Clean white space, large type, minimal color, professional
   - **Image-First Grid** (Photography portfolio style)
     - Large images, grid layouts, minimal text, immersive
   - **Playful/Interactive** (Bruno Simon style)
     - Custom interactions, personality-driven, memorable
   - **Editorial/Magazine** (Paul Stamatiou style)
     - Longer-form content, article layouts, storytelling
   - **Hybrid: Minimalist foundation + strong imagery** (Recommended)

2. **Color Palette:** Any preferences or existing Studio Moser brand colors?
   - Suggested: Warm neutrals (cream, warm gray) with deep blue or forest green accent (Pacific Northwest vibe)
   - Or: Monochrome with single bold accent
   - Or: Open to recommendations

3. **Typography:** Any font preferences?
   - Modern sans-serif (Inter, Söhne)?
   - Serif for long-form reading (Crimson, Lora)?
   - Mix of both?

### Content Priority

4. **Photography vs Design Priority:** Which should be more prominent?
   - **Equal weight** (recommended based on research)
   - **Design-forward** (lead with Moby credentials)
   - **Photography-forward** (if building photo business)

5. **Photography Services:** How serious about commercial photography?
   - Actively seeking photography clients → Need pricing, booking flow
   - Open to opportunities → Simple inquiry-based approach
   - Just showcasing personal work → No services section needed

6. **Client Work Detail:** How much can you share about Moby projects?
   - Full case studies with client names and details?
   - Generalized case studies?
   - Images only with brief descriptions?
   - Any NDAs or restrictions?

### Products to Feature

7. **Product Priority:** Which products to feature prominently?
   - **Active development:**
     - Ausra Photos (yes/no?)
     - Ebook reader app (yes/no?)
     - Other projects?
   - **Shipped products:**
     - Supernormal Games (all games or select few?)
     - Any other completed apps?
   - **Future products:** Mention in development without details?

8. **Waitlist Strategy:** For Ausra Photos specifically:
   - Ready for public waitlist signups?
   - Private beta only?
   - Just "coming soon" with no signup?
   - Timeline for public availability?

9. **Building in Public:** Comfort level with transparency?
   - Share development updates regularly (blog/social)?
   - Occasional updates only?
   - Keep products private until launch?

### Platform & Timeline

10. **Platform Preference:** Any existing preference?
    - **Framer** (recommended - fast, designer-friendly, $15-30/mo)
    - **Webflow** (more control, CMS, $20-40/mo)
    - **Custom build** (full control, showcase dev skills, longer timeline)
    - **Squarespace** (if photography-primary)
    - Open to recommendation?

11. **Launch Timeline:** When do you want this live?
    - ASAP (fast launch with basics, expand later)
    - 2-4 weeks (polished launch)
    - No rush (build it right, launch when ready)

12. **Existing Assets:** What do you already have?
    - Logo/branding for Studio Moser?
    - Photography portfolio already edited/organized?
    - Design case studies already documented?
    - Product screenshots/mockups ready?
    - Professional photos of yourself?

### Tone & Voice

13. **Writing Style:** How do you want to sound?
    - Professional but approachable (recommended)
    - Casual/conversational
    - Technical/precise
    - Creative/expressive

14. **First vs Third Person:**
    - "I direct creative work..." (more personal, recommended)
    - "Tim directs creative work..." (more formal)

### Additional Features

15. **Blog/Writing Section:** Want to include this at launch?
    - Yes, important for thought leadership
    - Maybe later (Phase 2)
    - No, not a priority

16. **Social Integration:**
    - Which platforms to link?
    - Instagram (yes/no? username?)
    - LinkedIn (yes/no? profile URL?)
    - Twitter/X (yes/no?)
    - Dribbble or Behance (yes/no?)

17. **Newsletter/Email List:**
    - Want to collect emails for product updates?
    - Newsletter for all Studio Moser activities?
    - Just product-specific waitlists?
    - No email collection for now?

### Business Details

18. **Contact Email:** What should be primary contact?
    - tim@studiomoser.com (need to set up?)
    - Personal email?
    - Contact form only?

19. **Availability Statement:** How to phrase current availability?
    - "Open for select projects"
    - "Booking Q2 2026"
    - "Limited availability"
    - Specific capacity (e.g., "2-3 projects per quarter")

20. **Project Types:** Which opportunities to highlight?
    - Design/creative direction (yes/no/priority level?)
    - Photography (yes/no/priority level?)
    - Partnership/collaboration (yes/no?)
    - Speaking/teaching (yes/no?)

---

## 6. NEXT STEPS & PHASED APPROACH

### Phase 1: Launch (Week 1-2) - MINIMUM VIABLE SITE

**Must-Have Content:**
- Homepage (hero, three pillars, 6 featured works)
- Work page (5 project thumbnails with brief descriptions)
- Photography page (15 images in simple gallery + services overview)
- Products page (Ausra + Supernormal with basic info)
- About page (full story using template)
- Contact page (email + form)

**Can Skip for Launch:**
- Full case studies (just thumbnails)
- Organized photography galleries (just best 15-20 images)
- Product update blog
- Writing/blog section
- Detailed photography services/pricing

**Goal:** Live site that establishes presence and credibility

### Phase 2: Expand (Month 1-2) - ADD DEPTH

**Add:**
- 2-3 full case studies (most impressive projects)
- Organized photography galleries (commercial/personal/process)
- Photography services detail + pricing approach
- Product updates for Ausra (if ready)
- Testimonials (if available)
- Behind-scenes content

**Goal:** Make site work harder for business development

### Phase 3: Optimize (Month 3+) - REFINE & GROW

**Based on Data:**
- Add more content to high-traffic sections
- Expand areas that generate inquiries
- Add blog/writing if valuable
- Newsletter integration if needed
- SEO optimization
- Social media integration improvements

**Goal:** Site becomes effective marketing tool

---

## 7. TECHNICAL RECOMMENDATIONS

### Platform: Framer (Recommended)

**Why Framer:**
- Fastest professional launch (1-2 weeks possible)
- Designer-friendly, no-code
- Beautiful templates as starting points
- Easy to update (products, photography)
- Built-in CMS for case studies/products
- Mobile-responsive by default
- Fast performance
- Reasonable cost ($15-30/mo)

**Alternative: Webflow**
- More control and customization
- Better for complex CMS needs (if planning lots of blog content)
- Slightly higher learning curve
- $20-40/mo

**Alternative: Custom (Next.js/React)**
- Full control
- Showcase development skills
- Site itself becomes portfolio piece
- 4-8 week timeline
- Requires ongoing maintenance
- Best if site is part of the portfolio message

### Features Needed

**Photography Features:**
- Lightbox/full-screen image viewing
- High-resolution image support
- Fast loading (WebP format, lazy loading)
- Mobile-optimized galleries
- Optional: Integration with Pixieset or similar (Phase 2)

**Product Features:**
- Email signup forms (waitlist functionality)
- Embedded videos/demos
- Status indicators (In Progress, Beta, Shipped)
- External links (App Store, Play Store, web apps)
- Update feed capability (Phase 2)

**General Features:**
- Contact form
- Analytics (Google Analytics or similar)
- SEO optimization (meta tags, Open Graph)
- Fast load times
- Mobile responsive
- Accessible (WCAG AA standards)

### Domain

- **Primary:** studiomoser.com
- **Email:** tim@studiomoser.com (or hi@studiomoser.com, contact@studiomoser.com)
- **Optional subdomain (Phase 2):** photos.studiomoser.com (if photography business grows)

### Third-Party Integrations

**For Launch:**
- Email service (ConvertKit, Mailchimp, or Buttondown for waitlist)
- Analytics (Google Analytics or Plausible)
- Contact form (native to platform or Formspree)

**For Phase 2:**
- Photography client galleries (Pixieset, Lightfolio, or Zenfolio)
- Newsletter platform (if adding blog)
- Social media feeds (if desired)

---

## 8. DESIGN SYSTEM RECOMMENDATIONS

### Color Palette (Suggested - Pending Tim's Input)

**Option 1: Pacific Northwest Inspired**
- Primary: Warm gray (#F5F5F0)
- Accent: Deep forest green (#2C5F2D) or slate blue (#3B5F6D)
- Text: Charcoal (#2D2D2D)
- Background: Cream (#FDFCF8)

**Option 2: Minimalist Professional**
- Primary: White (#FFFFFF)
- Accent: Deep blue (#003366)
- Text: Near-black (#1A1A1A)
- Background: Off-white (#FAFAFA)

**Option 3: Bold & Modern**
- Primary: Black (#000000)
- Accent: Vibrant color (coral #FF6B6B or electric blue #4A90E2)
- Text: Black (#000000)
- Background: White (#FFFFFF)

### Typography (Suggested)

**Option 1: Modern Sans**
- Headings: Inter or Söhne (bold, 600-700 weight)
- Body: Inter (regular, 400 weight)
- Accent: Monospace for technical details

**Option 2: Editorial Mix**
- Headings: Bold sans-serif (Inter, Helvetica Neue)
- Body: Serif (Crimson Text, Lora, Georgia) for readability
- Accent: Sans for captions

**Option 3: All Sans Clean**
- Headings: SF Pro Display or Inter (700 weight)
- Body: SF Pro Text or Inter (400 weight)
- Unified, clean, very Seattle tech

### Layout Principles

- **White space:** Generous spacing, not cramped
- **Grid:** Consistent column structure (12-column or 16-column)
- **Images:** Large, high-quality, full-bleed where appropriate
- **Mobile-first:** Design for mobile, enhance for desktop
- **Navigation:** Persistent, simple, clear current location

---

## 9. CONTENT STRATEGY SUMMARY

### Brand Message (Unifying Theme)

**Core Message:**
"Complete creative practice spanning design, photography, and products"

**Supporting Points:**
1. **Credibility:** 14 years enterprise experience (Moby, major clients)
2. **Breadth:** Multi-disciplinary but unified by design thinking
3. **Execution:** 10 startups, 25 brands, shipped products prove ability
4. **Current:** Active projects show momentum (Ausra, games, photography)
5. **Selective:** 2-3 projects/quarter = quality over quantity

### Voice & Tone

**Voice Characteristics:**
- Professional but approachable
- Confident without arrogance
- Maker/builder mentality
- Thoughtful and intentional
- Direct and clear (not verbose)

**Avoid:**
- Corporate jargon
- Over-technical language
- Apologizing for multiple interests
- Vague buzzwords ("innovative," "cutting-edge")
- Over-explaining choices

**Example Phrases That Work:**
- "I make things."
- "I can't help but build new things."
- "If I see a problem, I build something to fix it."
- "Studio Moser is where it all comes together."
- "Always making something."

### SEO Keywords to Target

**Primary Keywords:**
- Tim Moser
- Studio Moser
- Seattle creative director
- Seattle photographer
- Pacific Northwest design

**Secondary Keywords:**
- Moby Inc creative director
- Product designer Seattle
- Indie game developer Seattle
- Commercial photographer Seattle
- Multi-disciplinary designer

**Long-tail Keywords:**
- Creative direction for startups Seattle
- Seattle brand design photography
- Enterprise creative director portfolio
- Indie app developer photographer

---

## 10. SUCCESS METRICS

### Launch Success (Week 1-2)
- ✅ Site live and accessible
- ✅ All core pages complete (Home, Work, Photography, Products, About, Contact)
- ✅ Mobile responsive
- ✅ Fast load times (<3 seconds)
- ✅ Contact form working
- ✅ Analytics installed

### Business Success (Month 1-3)
- 2-3 quality inbound inquiries
- Contact form submissions from relevant prospects
- Photography booking inquiries (if pursuing)
- Ausra Photos waitlist signups (if ready)
- Positive feedback from network

### Don't Measure (Not Useful)
- Total page views (vanity metric)
- Social media followers initially
- Bounce rate (expected to be high for portfolio sites)
- Time on site (people browse quickly)

### Do Measure
- Inquiry quality and fit
- Project bookings from site
- Waitlist conversion (email to beta user)
- Referral quality (who's sending people)
- Which sections get most engagement

---

## SUMMARY & IMMEDIATE NEXT STEPS

### What This Plan Provides

✅ Complete site structure (6 core pages)
✅ Homepage strategy (story-driven with three pillars)
✅ Content outlines for all pages
✅ Detailed content inventory (what assets Tim needs to provide)
✅ 20 questions for Tim to clarify direction
✅ Phased approach (launch fast, expand later)
✅ Technical recommendations (Framer, features needed)
✅ Design system starting points
✅ SEO and content strategy

### For Tim to Review & Decide

**Critical Decisions:**
1. Design direction preference (Question 1)
2. Photography services approach (Question 5)
3. Products to feature (Questions 7-9)
4. Platform choice (Question 10)
5. Launch timeline (Question 11)

**Content to Gather:**
1. 5-8 Moby project case studies (descriptions + images)
2. 15-20 photography portfolio images (edited and organized)
3. Product screenshots (Ausra, games)
4. Professional photo of Tim
5. Social media handles/links

**Copy to Write/Approve:**
1. About page story (template provided, needs Tim's voice)
2. Project descriptions (300-500 words each)
3. Photography services description (if applicable)
4. Product descriptions (what, why, status)

### Recommended Immediate Actions

1. **Read this plan completely**
2. **Answer the 20 questions** (Section 5) - create separate doc with answers
3. **Gather existing assets** - collect best images/screenshots you already have
4. **Schedule content creation time** - block time to write case studies
5. **Choose platform** - make platform decision so designer/developer can start
6. **Set launch target** - pick realistic launch date based on timeline preference

### What Comes After This Plan

Once Tim answers questions and provides direction:
1. **Designer creates mockups** (homepage + key pages)
2. **Content team writes copy** (using Tim's input + research)
3. **Developer builds site** (or Tim builds in Framer/Webflow)
4. **Tim provides final assets** (photos, screenshots, case study details)
5. **Review and iterate** (2-3 rounds of feedback)
6. **Launch** (go live, announce, drive traffic)
7. **Phase 2 expansion** (add depth over next 1-2 months)

---

## APPENDIX: QUICK REFERENCE

### Site Structure (Copy/Paste)
```
Home | Work | Photography | Products | About | Contact
```

### Homepage Hero (Copy/Paste)
```
TIM MOSER
Creative Director · Photographer · Maker

I've spent 14 years directing creative for Microsoft, Disney, and NPR
at Moby, Inc. I also photograph stories, build apps, and make indie games.

Seattle-based. Always making something.
```

### About Page Hook (Copy/Paste)
```
I make things.

For 14 years, I've directed creative work for Microsoft, Disney, T-Mobile,
and NPR as co-founder of Moby, Inc. Along the way, I've co-founded 10
startups, created 25+ brands, and launched an indie game studio because
I can't help but build new things.

Studio Moser is where it all comes together.
```

### Navigation Labels
- Primary: Work | Photography | Products | About | Contact
- Mobile: Same (hamburger menu)
- Footer: All pages + Instagram + LinkedIn + Email

### Platform Recommendation Matrix

| Platform | Timeline | Control | Cost | Best For |
|----------|----------|---------|------|----------|
| Framer | 1-2 weeks | Medium | $15-30/mo | Quick professional launch |
| Webflow | 2-4 weeks | High | $20-40/mo | Blog/CMS needs |
| Custom | 4-8 weeks | Full | ~$10/mo | Showcase dev skills |

**Recommendation: Framer for fast, professional launch**

---

**This plan is ready for Tim's review and team implementation.**
