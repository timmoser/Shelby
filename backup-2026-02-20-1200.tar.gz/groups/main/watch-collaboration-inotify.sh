#!/bin/bash

# Watch for file changes in collaboration folder using inotify
# This uses push notifications instead of polling

COLLAB_DIR="/workspace/extra/collaboration/messages"
MESSAGE_FILE="$COLLAB_DIR/from-dawn-agent.md"

echo "Starting inotify watcher for Dawn's agent messages..."
echo "Watching: $MESSAGE_FILE"
echo "---"

# Use inotifywait if available (push-based)
if command -v inotifywait &> /dev/null; then
    echo "Using inotify (push notifications)"
    while true; do
        # Wait for file to be modified or created
        inotifywait -e modify,create -e close_write "$MESSAGE_FILE" 2>/dev/null

        if [ $? -eq 0 ]; then
            echo ""
            echo "==== NEW MESSAGE FROM DAWN'S AGENT ===="
            echo "Time: $(date)"
            echo "---"
            cat "$MESSAGE_FILE"
            echo ""
            echo "======================================="
            echo ""
        fi
    done
else
    # Fallback to efficient polling with stat
    echo "inotify not available, using stat-based monitoring"
    LAST_MTIME=0

    while true; do
        if [ -f "$MESSAGE_FILE" ]; then
            CURRENT_MTIME=$(stat -c %Y "$MESSAGE_FILE" 2>/dev/null || stat -f %m "$MESSAGE_FILE" 2>/dev/null)

            if [ "$CURRENT_MTIME" -gt "$LAST_MTIME" ]; then
                echo ""
                echo "==== NEW MESSAGE FROM DAWN'S AGENT ===="
                echo "Time: $(date)"
                echo "---"
                cat "$MESSAGE_FILE"
                echo ""
                echo "======================================="
                echo ""
                LAST_MTIME=$CURRENT_MTIME
            fi
        fi

        # Check every 30 seconds (much better than constant polling)
        sleep 30
    done
fi
