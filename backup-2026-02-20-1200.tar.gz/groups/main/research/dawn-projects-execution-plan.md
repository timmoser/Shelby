# Dawn's Projects: Detailed Execution Plan

**Created**: February 11, 2026
**Status**: Ready for Execution
**Timeline**: 8-12 weeks for both projects (running in parallel)

---

## Executive Summary

This document provides week-by-week execution plans for Dawn's two primary projects:
1. Professional portfolio website (dawnmoser.com)
2. Job hunt campaign

Both projects are fully researched and ready to execute. They will run in parallel, with the website serving as a strategic asset for the job hunt.

---

# PROJECT 1: DAWNMOSER.COM WEBSITE

## Strategic Overview

**Goal**: Launch a dual-purpose portfolio website that positions Dawn for both freelance opportunities and full-time roles while creating space for personal writing.

**Positioning**: "Professional Writer. Personal Storyteller."
- Day job: B2B tech + healthcare content strategist
- Personal: Essay writer exploring what it means to be human

**Platform**: Squarespace (recommended templates: Skye, Burke, Almar, Palmer)

**Timeline**: 8 weeks to launch

---

## Week-by-Week Website Execution Plan

### WEEK 1: Foundation & Content Gathering
**Status**: Critical path - blocks all other website work
**Owner**: Dawn (content) + Tim (template selection)

#### Monday-Tuesday: Template Selection
- [ ] **Tim & Dawn**: Review 4 recommended Squarespace templates
  - Skye (writer-focused, strong blog features)
  - Burke (clean, blog + portfolio hybrid)
  - Almar (minimalist, great typography)
  - Palmer (flexible portfolio + blog)
- [ ] **Decision criterion**: Must support blog, newsletter, portfolio showcase
- [ ] **Purchase template** and set up Squarespace account
- [ ] **Configure basic settings** (domain, basic pages)

#### Wednesday-Friday: Personal Essay Collection
- [ ] **Dawn**: Export all posts from "This Flawed Human" blog
- [ ] **Dawn**: Export all posts from "Unofficial Expert" blog
- [ ] **Dawn**: Gather any other personal essays or creative writing
- [ ] **Dawn**: Note original publication dates for each piece
- [ ] **Shelby**: Create `/content/personal-essays/` folder structure
- [ ] **Shelby**: Clean up formatting and organize by category

#### Ongoing This Week:
- [ ] **Dawn**: Gather professional headshot (or schedule photo session)
- [ ] **Dawn**: Collect client logos (if allowed: Avalara, Fred Hutch, F5)
- [ ] **Dawn**: Pull any analytics from Avalara author page (traffic, engagement)

**Deliverables by End of Week**:
- Template purchased and configured
- All personal essays collected and organized
- Professional assets gathered
- Clear decision on positioning angle

**Blockers/Risks**:
- If template selection takes longer, can proceed with content drafting in parallel
- Missing essays can be added later, but need at least 3-5 for launch

---

### WEEK 2: Core Copywriting
**Status**: Can begin once template selected
**Owner**: Shelby (drafting) → Dawn (reviewing/editing)

#### Monday: Homepage Copy
- [ ] **Shelby**: Draft integrated hero section
  ```
  I'M DAWN. I'M A WRITER.

  By day, I translate complex B2B tech and healthcare
  topics into content people actually understand.

  By night (and weekends), I write personal essays
  about being human, flawed, and figuring it out as I go.
  ```
- [ ] **Shelby**: Draft below-fold sections (professional intro, personal intro, visual separation)
- [ ] **Dawn**: Review and edit for authentic voice

#### Tuesday: About Page Copy
- [ ] **Shelby**: Draft "The Short Version" (2 sentences)
- [ ] **Shelby**: Draft "The Longer Version" (3-4 paragraphs covering journey)
- [ ] **Shelby**: Draft "What I'm Looking For" section
- [ ] **Dawn**: Review, add personal touches, approve

#### Wednesday: "Hire Me" Page Copy
- [ ] **Shelby**: Draft services overview (Content Strategy, B2B SaaS, Healthcare, Editorial Leadership)
- [ ] **Shelby**: Draft "My Approach" section
- [ ] **Shelby**: Create "Past Clients" section
- [ ] **Dawn**: Decide on pricing strategy (display rates vs. "contact for pricing")

#### Thursday: Writing/Blog Section Copy
- [ ] **Shelby**: Draft intro section ("Why I write personally")
- [ ] **Shelby**: Draft newsletter signup copy
- [ ] **Dawn**: Decide on blog categories based on existing essays
  - Suggested: Personal Growth, Work & Career, Writing & Creativity, Life Observations

#### Friday: Review & Refinement
- [ ] **Dawn**: Full review of all copy drafted this week
- [ ] **Shelby**: Implement Dawn's edits
- [ ] **Tim**: Begin implementing copy into Squarespace template

**Deliverables by End of Week**:
- Complete copy for Home, About, Hire Me, Writing pages
- Blog categories defined
- Newsletter signup copy ready
- All copy approved by Dawn

**Blockers/Risks**:
- Dawn's editing time - allocate 3-4 hours for review
- May need extra iteration on tone/voice

---

### WEEK 3: Portfolio Case Studies
**Status**: Can run parallel to Tim's Squarespace build
**Owner**: Shelby (drafting) → Dawn (adding details)

#### Monday-Tuesday: Avalara Case Study
- [ ] **Shelby**: Draft using STAR framework
  - Situation: B2B SaaS needing educational content
  - Task: Translate complex tax compliance for SMB audience
  - Action: 48+ articles, editorial board, SEO strategy
  - Result: Still driving traffic, used by sales team
- [ ] **Dawn**: Add specific metrics, anecdotes, corrections
- [ ] **Dawn**: Request testimonial from former Avalara manager (if available)

#### Wednesday: Fred Hutch Case Study
- [ ] **Shelby**: Draft using STAR framework
  - Situation: Cancer research center site redesign
  - Task: Multi-audience content (patients, researchers, donors)
  - Action: Interviewed scientists, created accessible content
  - Result: Improved accessibility, positive patient feedback
- [ ] **Dawn**: Add details, specific projects, outcomes

#### Thursday: F5 Networks Case Study
- [ ] **Shelby**: Draft using STAR framework
  - Situation: Enterprise tech company needing clearer messaging
  - Task: Two site rewrites, demand gen toolkits
  - Action: Translated technical specs to business value
  - Result: Improved clarity, reduced support inquiries
- [ ] **Dawn**: Add details and metrics

#### Friday: Additional Portfolio Pieces
- [ ] **Shelby**: Create 2-3 mini case studies for "More Work" section
- [ ] **Dawn**: Identify other projects worth featuring

**Deliverables by End of Week**:
- 3 full case studies (Avalara, Fred Hutch, F5)
- 2-3 mini case studies
- Testimonial requests sent
- All case studies approved

**Blockers/Risks**:
- Need Dawn's detailed input on metrics and specifics
- Some projects may be under NDA (have fallback examples ready)

---

### WEEK 4: Personal Essay Curation & Site Build
**Status**: Tim building site while content team curates essays
**Owner**: Tim (building) + Dawn/Shelby (content curation)

#### Tim's Track: Squarespace Build
- [ ] **Monday**: Set up page structure (Home, Work, Hire Me, Writing, About, Contact)
- [ ] **Tuesday**: Implement homepage copy and design
- [ ] **Wednesday**: Build portfolio section with case studies
- [ ] **Thursday**: Set up blog section and configure categories
- [ ] **Friday**: Configure newsletter integration

#### Content Track: Essay Curation
- [ ] **Monday-Tuesday**: **Dawn & Shelby**: Review all collected essays
- [ ] **Dawn**: Select 8-10 best essays for launch
- [ ] **Dawn**: Decide which to feature prominently
- [ ] **Wednesday**: **Shelby**: Edit and format selected essays for web
- [ ] **Shelby**: Write category descriptions
- [ ] **Thursday-Friday**: **Shelby**: Create SEO-optimized titles and meta descriptions
- [ ] **Dawn**: Write 1-2 new essays specifically for launch (optional but recommended)

**Deliverables by End of Week**:
- Site structure fully built in Squarespace
- Homepage, About, Hire Me pages complete
- 8-10 essays formatted and ready to publish
- Blog categories set up
- Newsletter configured

**Blockers/Risks**:
- Tim's availability for build work
- Essay editing may take longer than expected
- Newsletter integration may have technical issues

---

### WEEK 5: Content Loading & SEO Optimization
**Status**: Assembly phase
**Owner**: Tim (loading) + Shelby (SEO)

#### Monday-Wednesday: Content Loading
- [ ] **Tim**: Upload all case studies to portfolio section
- [ ] **Tim**: Load all curated essays into blog
- [ ] **Tim**: Add client logos (if available)
- [ ] **Tim**: Upload professional headshot to About page
- [ ] **Tim**: Set featured images for blog posts

#### Thursday-Friday: SEO Implementation
- [ ] **Shelby**: Write meta descriptions for all pages
  - Homepage: "Seattle content strategist specializing in B2B tech and healthcare. Portfolio, writing, and hire me info."
  - Portfolio: "Content strategy case studies from Avalara, Fred Hutch, and F5 Networks"
  - Writing: "Personal essays about work, life, and figuring it out"
- [ ] **Shelby**: Optimize page titles with keywords
  - Homepage: "Dawn Moser | Content Strategist | B2B Tech & Healthcare | Seattle"
  - Portfolio: "Portfolio | Content Strategy Case Studies | Dawn Moser"
- [ ] **Shelby**: Write alt text for all images
- [ ] **Tim**: Implement internal linking structure
- [ ] **Tim**: Set up URL structure (clean, keyword-rich URLs)
- [ ] **Shelby**: Create XML sitemap
- [ ] **Tim**: Submit to Google Search Console

**Deliverables by End of Week**:
- All content loaded and live on site
- Complete SEO optimization
- Site submitted to search engines
- Internal linking structure complete

**Blockers/Risks**:
- Image optimization may be time-consuming
- SEO tools may require additional setup time

---

### WEEK 6: Resume Integration & Contact Setup
**Status**: Final functionality additions
**Owner**: Tim (technical) + Dawn (decisions)

#### Monday-Tuesday: Resume Decisions
- [ ] **Dawn**: Choose which resume version to feature for download
  - Recommendation: Master Resume (shows full scope)
  - Keep specialized versions for specific job applications
- [ ] **Tim**: Create downloadable PDF version
- [ ] **Tim**: Add "Download Resume" CTA to About and Hire Me pages
- [ ] **Tim**: Create separate resume page (optional)

#### Wednesday: Contact Form Setup
- [ ] **Tim**: Configure contact form (Name, Email, Message)
- [ ] **Tim**: Set up email routing to Dawn's email
- [ ] **Tim**: Add spam protection
- [ ] **Tim**: Test form submissions
- [ ] **Tim**: Create auto-response email ("Thanks for reaching out, I'll respond within 24 hours")

#### Thursday: Newsletter Final Setup
- [ ] **Tim**: Configure newsletter signup form on Writing page
- [ ] **Tim**: Add newsletter popup (if desired, subtle timing)
- [ ] **Tim**: Set up welcome email for new subscribers
- [ ] **Dawn**: Write welcome email copy
- [ ] **Tim**: Test subscription flow

#### Friday: Mobile Optimization
- [ ] **Tim**: Test entire site on mobile devices
- [ ] **Tim**: Adjust layouts for mobile responsiveness
- [ ] **Tim**: Test newsletter signup on mobile
- [ ] **Tim**: Test contact form on mobile
- [ ] **Tim**: Check image loading speeds

**Deliverables by End of Week**:
- Resume available for download
- Contact form fully functional
- Newsletter fully configured and tested
- Site fully mobile-optimized

**Blockers/Risks**:
- Form configuration may have technical issues
- Mobile testing may reveal layout problems requiring fixes

---

### WEEK 7: Polish, Testing & Soft Launch
**Status**: Quality assurance phase
**Owner**: All team members

#### Monday-Tuesday: Comprehensive Review
- [ ] **Dawn**: Read through entire site as visitor
- [ ] **Dawn**: Check all copy for typos, tone, accuracy
- [ ] **Tim**: Click every link, test every form
- [ ] **Tim**: Test on multiple browsers (Chrome, Safari, Firefox, Edge)
- [ ] **Shelby**: Review all SEO elements one more time
- [ ] **All**: Check page load speeds (use GTmetrix or PageSpeed Insights)

#### Wednesday: Fixes & Refinements
- [ ] **Tim**: Implement all fixes from review
- [ ] **Dawn**: Make any final copy edits
- [ ] **Tim**: Optimize any slow-loading images
- [ ] **Shelby**: Make any final SEO adjustments

#### Thursday: Soft Launch
- [ ] **Tim**: Make site live at dawnmoser.com
- [ ] **Dawn**: Share with 3-5 trusted friends for feedback
- [ ] **Dawn**: Test newsletter signup yourself
- [ ] **Dawn**: Test contact form yourself
- [ ] **All**: Monitor for any technical issues

#### Friday: Final Adjustments
- [ ] **Tim**: Implement feedback from soft launch
- [ ] **Dawn**: Make any copy tweaks based on feedback
- [ ] **Shelby**: Prepare launch announcement copy for LinkedIn

**Deliverables by End of Week**:
- Site live and fully functional
- All bugs fixed
- Feedback incorporated
- Launch announcement copy ready

**Blockers/Risks**:
- Friends may take time to provide feedback
- Technical issues discovered during soft launch
- Domain DNS may take time to propagate

---

### WEEK 8: Official Launch & Promotion
**Status**: Go-to-market
**Owner**: Dawn (primary) + Shelby (support)

#### Monday: LinkedIn Profile Sync
- [ ] **Dawn**: Update LinkedIn headline: "Content Strategist | B2B Tech & Healthcare | Seattle"
- [ ] **Dawn**: Update LinkedIn summary to match website positioning
- [ ] **Dawn**: Add dawnmoser.com to LinkedIn profile (multiple places)
- [ ] **Dawn**: Add website to Featured section with custom image
- [ ] **Shelby**: Review LinkedIn profile for consistency

#### Tuesday: Official Launch Announcement
- [ ] **Dawn**: Post launch announcement on LinkedIn (use Shelby's draft as starting point)
  ```
  I'm excited to share my new website: dawnmoser.com

  It's a space for both my professional work (B2B tech + healthcare
  content strategy) and my personal writing (essays about being human).

  Check it out, subscribe to my newsletter if you're interested, or
  get in touch if you need a content strategist who speaks both tech
  and human.
  ```
- [ ] **Dawn**: Share in relevant LinkedIn groups
- [ ] **Dawn**: Send personal messages to 10-15 key contacts with website link

#### Wednesday: Network Outreach
- [ ] **Dawn**: Email former colleagues/managers with website link
- [ ] **Dawn**: Update email signature with website link
- [ ] **Dawn**: Add website to other social media profiles (if applicable)

#### Thursday: Content Marketing
- [ ] **Dawn**: Publish first new essay post-launch
- [ ] **Dawn**: Share essay on LinkedIn
- [ ] **Dawn**: Engage with comments and messages

#### Friday: Analytics Setup & Review
- [ ] **Tim**: Ensure Google Analytics is tracking properly
- [ ] **Tim**: Set up conversion tracking (contact form, newsletter signups)
- [ ] **Shelby**: Create analytics review template for weekly monitoring
- [ ] **All**: Celebrate launch!

**Deliverables by End of Week**:
- Website officially launched and announced
- LinkedIn profile fully synced
- Initial traffic and engagement
- Analytics tracking confirmed

**Success Metrics for Launch Week**:
- LinkedIn post engagement: 50+ reactions, 10+ comments
- Website visitors: 100+ unique visitors
- Newsletter signups: 10-20 initial subscribers
- Contact form submissions: 2-5 inquiries

---

## Website Project: Critical Path Items

These items CANNOT be skipped or delayed without impacting launch:

1. **Template Selection** (Week 1) - Blocks all design work
2. **Personal Essay Collection** (Week 1) - Blocks blog section
3. **Core Copywriting** (Week 2) - Blocks site build
4. **Portfolio Case Studies** (Week 3) - Blocks portfolio section
5. **Squarespace Build** (Week 4-5) - Blocks everything downstream
6. **SEO Implementation** (Week 5) - Blocks search visibility
7. **Mobile Optimization** (Week 6) - Blocks launch
8. **Testing & QA** (Week 7) - Blocks launch

**Everything else can be adjusted, delayed, or simplified if needed.**

---

## Website Project: Parallel Tracks

These can happen simultaneously to accelerate timeline:

### Track A: Design & Build (Tim)
- Template setup → Page structure → Content loading → Technical configuration

### Track B: Content Creation (Dawn + Shelby)
- Essay collection → Copywriting → Case studies → Resume prep

### Track C: SEO & Strategy (Shelby)
- Keyword research → Meta descriptions → Alt text → Analytics setup

**Key**: Tracks A and B must converge by Week 5 (content loading phase)

---

## Website Success Metrics by Phase

### Phase 1: Foundation (Weeks 1-2)
- [ ] Template selected and purchased
- [ ] All personal essays collected (minimum 8-10)
- [ ] Core copy written and approved
- [ ] Professional assets gathered

### Phase 2: Content (Weeks 3-4)
- [ ] 3 full case studies complete
- [ ] 8-10 essays formatted and ready
- [ ] Site structure built in Squarespace
- [ ] Blog and newsletter configured

### Phase 3: Build (Weeks 5-6)
- [ ] All content loaded
- [ ] SEO fully optimized
- [ ] Forms and functionality working
- [ ] Mobile responsive

### Phase 4: Launch (Weeks 7-8)
- [ ] Site tested and bug-free
- [ ] Soft launch feedback incorporated
- [ ] Official launch announced
- [ ] Analytics tracking confirmed

---

## Website Risk Mitigation Strategies

### Risk 1: Dawn's Time Constraints
**Mitigation**:
- Shelby drafts everything first, Dawn only reviews/edits (saves time)
- Prioritize critical path items if time is tight
- Can launch with fewer essays (minimum 5) and add more later

### Risk 2: Technical Issues with Squarespace
**Mitigation**:
- Tim tests each feature as it's built
- Have backup template options
- Squarespace support is responsive

### Risk 3: Content Perfectionism Causing Delays
**Mitigation**:
- Set "good enough for launch" standard
- Remember: Can update post-launch
- Better to launch and iterate than wait for perfect

### Risk 4: Missing Assets (Headshot, Logos, Testimonials)
**Mitigation**:
- Launch without client logos if needed
- Use temporary headshot and update later
- Testimonials can be added post-launch

### Risk 5: SEO Takes Time to Show Results
**Mitigation**:
- Focus on LinkedIn promotion for immediate traffic
- Build newsletter list for direct connection
- SEO is long-term play, not launch requirement

---

# PROJECT 2: JOB HUNT CAMPAIGN

## Strategic Overview

**Goal**: Land senior content strategist role ($100-130K) within 2-3 months

**Strategy**: Anti-ghost job, networking-first, quality over quantity approach

**Key Insight**: 27.4% of LinkedIn jobs are fake - verification before application is critical

**Timeline**: 12 weeks (3 months)

---

## Week-by-Week Job Hunt Execution Plan

### WEEKS 1-2: Setup & System Building (Parallel to Website Weeks 1-2)
**Status**: Foundation phase
**Owner**: Dawn (primary) + Shelby (support)

#### Week 1 Tasks:

**Monday: Resume Foundation**
- [ ] **Dawn**: Provide current resume to Shelby
- [ ] **Shelby**: Create 5 tailored resume versions:
  1. Master Resume (comprehensive)
  2. B2B SaaS Focus
  3. Healthcare Focus
  4. Senior Content Strategist
  5. Content Marketing Manager
- [ ] **Shelby**: Set up ATS-optimized template
- [ ] **Dawn**: Review and approve all versions

**Tuesday: Target Company List**
- [ ] **Dawn**: Build list of 20-30 target companies
  - 10 B2B SaaS companies (Salesforce, HubSpot, Asana, etc.)
  - 5 Healthcare tech companies (One Medical, Omada Health, etc.)
  - 5 Large tech companies (Amazon, Microsoft, Meta)
  - 5-10 Agencies with tech/healthcare clients
- [ ] **Shelby**: Create tracking spreadsheet (`target-companies.csv`)
- [ ] **Dawn**: Research content team leads at each company

**Wednesday: LinkedIn Optimization**
- [ ] **Dawn**: Update LinkedIn headline: "Content Strategist | B2B Tech & Healthcare | Seattle"
- [ ] **Dawn**: Update LinkedIn summary with new positioning
- [ ] **Dawn**: Turn on "Open to Work" (recruiters only mode)
- [ ] **Dawn**: Add portfolio URL once website launches (if not yet, add placeholder)
- [ ] **Shelby**: Review LinkedIn profile for optimization

**Thursday: Tracking Systems Setup**
- [ ] **Shelby**: Create applications tracking spreadsheet
  - Columns: Company, Job Title, Date Applied, Status, Hiring Manager, Follow-up Dates
- [ ] **Shelby**: Create networking tracker
- [ ] **Shelby**: Set up ghost job verification checklist
- [ ] **Dawn**: Familiarize herself with tracking systems

**Friday: Warm Connection Inventory**
- [ ] **Dawn**: List former colleagues from Avalara, Fred Hutch, F5, agencies
- [ ] **Dawn**: Identify 10-15 key people who could provide referrals
- [ ] **Dawn**: Note which target companies they work at or have connections to
- [ ] **Shelby**: Draft initial outreach messages for each contact

#### Week 2 Tasks:

**Monday: First Applications**
- [ ] **Dawn**: Review target company career pages
- [ ] **Dawn**: Identify 3-5 recently posted jobs (<7 days old)
- [ ] **Shelby**: Run ghost job verification on each
- [ ] **Shelby**: Customize resume for each verified job
- [ ] **Dawn**: Submit applications

**Tuesday: Networking Launch**
- [ ] **Dawn**: Send 5-10 LinkedIn connection requests to hiring managers
- [ ] **Shelby**: Draft personalized connection request messages
- [ ] **Dawn**: Review and send with personal touches

**Wednesday: Referral Outreach**
- [ ] **Dawn**: Reach out to 2-3 former colleagues for general catch-up
- [ ] **Shelby**: Draft referral request emails (use when appropriate)
- [ ] **Dawn**: Don't immediately ask for referrals - build rapport first

**Thursday: Company Research**
- [ ] **Shelby**: Deep research on 5 priority target companies
  - Content challenges they face
  - Recent company news
  - How Dawn could add value
- [ ] **Dawn**: Review research and prioritize companies

**Friday: Week 1-2 Review**
- [ ] **Dawn**: Update tracking spreadsheets
- [ ] **Dawn**: Note what's working, what's not
- [ ] **Dawn**: Plan Week 3 targets

**Deliverables by End of Week 2**:
- 5 resume versions ready
- 20-30 target companies identified
- LinkedIn profile optimized
- Tracking systems operational
- 3-5 applications submitted
- 10-15 hiring manager connections initiated
- Warm connection outreach begun

---

### WEEKS 3-4: Momentum Building (Parallel to Website Weeks 3-4)
**Status**: Execution phase
**Owner**: Dawn (applications) + Shelby (support)

#### Week 3 Tasks:

**Monday: Application Follow-Ups**
- [ ] **Dawn**: 48-hour follow-up on Week 2 applications
- [ ] **Shelby**: Draft LinkedIn messages to hiring managers
- [ ] **Dawn**: Send personalized follow-ups

**Monday: New Applications**
- [ ] **Dawn**: Apply to 3-5 new verified jobs
- [ ] **Shelby**: Customize resumes
- [ ] **Dawn**: Submit with cover letters if required

**Tuesday: Networking Growth**
- [ ] **Dawn**: Send 5-10 new connection requests
- [ ] **Dawn**: Follow up with accepted connections from Week 2
- [ ] **Shelby**: Draft value-first follow-up messages

**Wednesday: Referral Requests**
- [ ] **Dawn**: Request 2-3 referrals from warm connections
- [ ] **Shelby**: Draft referral request messages
- [ ] **Dawn**: Make it easy for them (provide resume, job link)

**Thursday: Company Research Day**
- [ ] **Shelby**: Research 5 more target companies
- [ ] **Dawn**: Check career pages of all target companies
- [ ] **Dawn**: Set up Google Alerts for "[Company] hiring content"

**Friday: Week 3 Review & Planning**
- [ ] **Dawn**: Update all tracking spreadsheets
- [ ] **Dawn**: Note any interview requests
- [ ] **Dawn**: Plan Week 4 focus

#### Week 4 Tasks:

**Monday: Follow-Ups**
- [ ] **Dawn**: 1-week follow-up on Week 2 applications (email this time)
- [ ] **Dawn**: 48-hour follow-up on Week 3 applications

**Monday: Applications**
- [ ] **Dawn**: Apply to 3-5 new jobs
- [ ] **Shelby**: Customize resumes with keywords

**Tuesday: Networking**
- [ ] **Dawn**: Send 5-10 new connections
- [ ] **Dawn**: Message Week 3 connections with value-first approach

**Wednesday: Informational Interviews**
- [ ] **Dawn**: Request 1-2 informational interviews with connections
- [ ] **Shelby**: Draft informational interview request message
- [ ] **Dawn**: Prepare questions for informational interviews

**Thursday: Interview Prep (if any scheduled)**
- [ ] **Shelby**: Create custom interview prep doc for any scheduled interviews
- [ ] **Dawn**: Research company thoroughly
- [ ] **Dawn**: Prepare STAR method stories for common questions

**Friday: Month 1 Review**
- [ ] **Dawn**: Review progress against goals
  - Applications submitted (goal: 12-20)
  - Hiring manager connections (goal: 20-40)
  - Interview requests (goal: 1-2)
- [ ] **Dawn & Shelby**: Adjust strategy based on what's working

**Deliverables by End of Week 4**:
- 12-20 total applications submitted
- 20-40 hiring manager connections made
- 5-10 referral requests sent
- 1-2 interview requests (hopefully)
- Clear sense of what's working

---

### WEEKS 5-6: Website Launch & Job Hunt Intensification
**Status**: Leverage website as job hunt tool
**Owner**: Dawn (primary) + Shelby (support)

#### Week 5 Tasks:

**Monday: Website-Powered Outreach**
- [ ] **Dawn**: Update all applications/profiles with website link
- [ ] **Dawn**: Send "My website is live" message to all active connections
- [ ] **Shelby**: Draft LinkedIn post announcing website
- [ ] **Dawn**: Apply to 3-5 jobs, include website in application

**Tuesday: Networking with Portfolio**
- [ ] **Dawn**: Share website in connection requests ("Check out my work at dawnmoser.com")
- [ ] **Dawn**: Send 10 new connection requests highlighting portfolio
- [ ] **Dawn**: Follow up with previous connections sharing website

**Wednesday: Referral Boost**
- [ ] **Dawn**: Re-engage referral contacts with website as credibility boost
- [ ] **Dawn**: Request 3-5 new referrals, including portfolio link
- [ ] **Shelby**: Draft "easier to refer me now with portfolio" message

**Thursday: Interview Prep**
- [ ] **Shelby**: Prep for any scheduled interviews
- [ ] **Dawn**: Use website case studies as talking points
- [ ] **Dawn**: Practice walking through portfolio

**Friday: Week 5 Review**
- [ ] **Dawn**: Update trackers
- [ ] **Dawn**: Monitor website analytics for employer traffic
- [ ] **Dawn**: Note any uptick in interest post-website launch

#### Week 6 Tasks:

**Monday: Application Blitz**
- [ ] **Dawn**: Apply to 5-7 jobs (more now that website is live)
- [ ] **Shelby**: Customize resumes, include portfolio link
- [ ] **Dawn**: Direct hiring managers to specific case studies in outreach

**Tuesday: Networking Growth**
- [ ] **Dawn**: 10-15 new connections (aim higher with portfolio to share)
- [ ] **Dawn**: Focus on hiring managers at priority companies

**Wednesday: Follow-Ups**
- [ ] **Dawn**: Follow up on all Week 4-5 applications
- [ ] **Dawn**: Message any non-responsive connections with website update

**Thursday: Informational Interviews**
- [ ] **Dawn**: Conduct 1-2 informational interviews
- [ ] **Dawn**: Share portfolio during conversations
- [ ] **Dawn**: Ask about unadvertised openings

**Friday: Week 6 Review**
- [ ] **Dawn**: Review metrics
  - Total applications: 25-35
  - Connections: 40-60
  - Interview requests: 2-4 (goal)
- [ ] **Dawn & Shelby**: Refine approach based on feedback

**Deliverables by End of Week 6**:
- Website launched and integrated into job hunt
- 25-35 total applications
- 40-60 hiring manager connections
- 2-4 interview requests (target)
- Portfolio demonstrably strengthening applications

---

### WEEKS 7-8: Interview Phase & Continued Applications
**Status**: Interviews starting to happen
**Owner**: Dawn (interviews) + Shelby (prep & continued applications)

#### Week 7 Tasks:

**Monday: Interview Prep Week**
- [ ] **Shelby**: Create detailed prep doc for each scheduled interview
- [ ] **Dawn**: Research companies thoroughly
- [ ] **Dawn**: Prepare portfolio walkthrough presentation
- [ ] **Dawn**: Practice STAR method answers

**Tuesday: Interviews**
- [ ] **Dawn**: Conduct scheduled interviews
- [ ] **Dawn**: Send thank you notes within 24 hours (Shelby can draft)
- [ ] **Dawn**: Update tracker with interview notes

**Wednesday: Continue Applications**
- [ ] **Dawn**: Apply to 3-5 new jobs (don't stop because of interviews)
- [ ] **Shelby**: Customize resumes

**Thursday: Networking Maintenance**
- [ ] **Dawn**: 5-10 new connections
- [ ] **Dawn**: Nurture existing relationships
- [ ] **Dawn**: Share website updates (new essay, newsletter)

**Friday: Follow-Ups**
- [ ] **Dawn**: Follow up on interviews (if timeline allows)
- [ ] **Dawn**: Follow up on pending applications
- [ ] **Dawn**: Update trackers

#### Week 8 Tasks:

**Monday: More Interviews**
- [ ] **Dawn**: Conduct any scheduled interviews
- [ ] **Shelby**: Prep as needed
- [ ] **Dawn**: Send follow-ups

**Tuesday: Application Push**
- [ ] **Dawn**: Apply to 5 more jobs
- [ ] **Shelby**: Customize materials

**Wednesday: Referral Push**
- [ ] **Dawn**: Request 5 more referrals from network
- [ ] **Dawn**: Focus on companies where you have warm intro

**Thursday: Interview Follow-Ups**
- [ ] **Dawn**: Follow up on all interviews from Weeks 7-8
- [ ] **Dawn**: Provide additional materials if requested
- [ ] **Dawn**: Stay in touch with hiring managers

**Friday: Week 8 Review**
- [ ] **Dawn**: Review progress
  - Applications: 35-50
  - Connections: 60-80
  - Interviews: 3-6 (target)
  - Final rounds: 1-2 (target)
- [ ] **Dawn & Shelby**: Adjust month 3 strategy

**Deliverables by End of Week 8**:
- 35-50 total applications
- 60-80 connections
- 3-6 first-round interviews completed
- 1-2 second-round/final interviews
- Active pipeline of opportunities

---

### WEEKS 9-12: Final Push & Negotiations
**Status**: Interview phase intensifies, offers come in
**Owner**: Dawn (primary) + Shelby (support)

#### Weeks 9-10: Interview Intensification

**Ongoing Activities**:
- [ ] **Dawn**: 3-5 applications per week (maintain momentum)
- [ ] **Dawn**: 5-10 new connections per week
- [ ] **Dawn**: 2-4 interviews per week (if pipeline is strong)
- [ ] **Shelby**: Interview prep for each opportunity
- [ ] **Dawn**: Strategic follow-ups on all interviews

**Key Focus**:
- Advance promising opportunities to final rounds
- Continue building pipeline (don't stop until offer accepted)
- Network referrals yielding faster interviews
- Portfolio proving value in conversations

#### Weeks 11-12: Offer & Negotiation Phase

**Anticipated Activities**:
- [ ] **Dawn**: Final round interviews at 2-3 companies
- [ ] **Dawn**: Receive 1-2 job offers
- [ ] **Shelby**: Research salary data for negotiation
- [ ] **Dawn**: Negotiate salary, benefits, title
- [ ] **Dawn**: Accept best-fit offer
- [ ] **Dawn**: Notify network and close job hunt

**Negotiation Support**:
- [ ] **Shelby**: Compile market data ($100-130K range for Seattle)
- [ ] **Shelby**: Draft negotiation email templates
- [ ] **Dawn**: Practice negotiation conversations
- [ ] **Dawn**: Evaluate total compensation (salary, benefits, equity)

**Deliverables by End of Week 12**:
- 50+ total applications submitted
- 80-100 connections made
- 6-10 interviews conducted
- 2-4 final round interviews
- 1-2 job offers received
- OFFER ACCEPTED

---

## Job Hunt: Critical Path Items

These activities CANNOT be skipped:

1. **Resume Creation** (Week 1) - Blocks all applications
2. **Target Company List** (Week 1) - Blocks strategic applications
3. **LinkedIn Optimization** (Week 1) - Blocks networking
4. **Consistent Applications** (Every week) - 3-5 verified jobs minimum
5. **Networking Outreach** (Every week) - 5-10 connections minimum
6. **Follow-Ups** (48 hours & 1 week) - Dramatically increases response rate
7. **Interview Prep** (Before each interview) - Necessary for strong performance
8. **Thank You Notes** (Within 24 hours) - Shows professionalism

**Everything else is helpful but not critical.**

---

## Job Hunt: Parallel Tracks

### Track A: Applications (Dawn + Shelby)
- Weekly cycle: Research → Customize → Apply → Follow up

### Track B: Networking (Dawn + Shelby)
- Weekly cycle: Identify → Connect → Engage → Nurture

### Track C: Referrals (Dawn)
- Ongoing: Reach out → Build rapport → Request → Follow up

### Track D: Interview Prep (Shelby + Dawn)
- As needed: Research → Prep doc → Practice → Execute

**All tracks run simultaneously throughout 12-week period.**

---

## Job Hunt Success Metrics by Phase

### Phase 1: Setup (Weeks 1-2)
- [ ] 5 resume versions created
- [ ] 20-30 target companies identified
- [ ] LinkedIn profile optimized
- [ ] Tracking systems operational
- [ ] 6-10 applications submitted
- [ ] 10-20 connections made

### Phase 2: Momentum (Weeks 3-6)
- [ ] 25-35 applications submitted
- [ ] 40-60 connections made
- [ ] 5-10 referral requests sent
- [ ] 2-4 interview requests received
- [ ] Website launched and integrated

### Phase 3: Interviews (Weeks 7-10)
- [ ] 40-60 applications submitted
- [ ] 70-90 connections made
- [ ] 4-8 first-round interviews
- [ ] 2-4 second-round interviews
- [ ] Strong pipeline of 3-5 active opportunities

### Phase 4: Offers (Weeks 11-12)
- [ ] 50+ applications total
- [ ] 80-100 connections total
- [ ] 6-10 interviews total
- [ ] 2-3 final rounds
- [ ] 1-2 offers received
- [ ] Offer accepted

---

## Job Hunt Risk Mitigation Strategies

### Risk 1: Ghost Jobs Wasting Time
**Mitigation**:
- Always use ghost job checklist before applying
- Verify job is on company website
- Check posting date (<7 days preferred)
- If 3+ red flags, skip it

### Risk 2: Low Response Rate from Applications
**Mitigation**:
- Focus on referrals (7x more effective)
- Direct outreach to hiring managers
- Custom materials for every application
- Strategic follow-ups at 48 hours and 1 week

### Risk 3: Interview Performance Anxiety
**Mitigation**:
- Shelby creates custom prep doc for each interview
- Practice STAR method stories
- Use portfolio as confidence booster
- Informational interviews as practice

### Risk 4: Long Interview Processes Causing Delays
**Mitigation**:
- Continue applications even when interviewing
- Build pipeline of multiple opportunities
- Don't rely on any single opportunity
- Be patient but persistent

### Risk 5: Salary Negotiations Falling Short
**Mitigation**:
- Research market data extensively
- Never accept first offer
- Negotiate 10-15% higher
- Use competing offers as leverage if possible

### Risk 6: Burnout from Intensive Search
**Mitigation**:
- Stick to 7-8 hours per week schedule
- Quality over quantity approach
- Take breaks between interview rounds
- Celebrate small wins (connections, interviews)

---

# INTEGRATION: HOW BOTH PROJECTS WORK TOGETHER

## Synergies Between Website & Job Hunt

### Week 1-4: Website Supports Job Hunt Prep
- Portfolio case studies become interview talking points
- Resume aligns with website positioning
- LinkedIn profile mirrors website messaging

### Week 5-6: Website Launch Amplifies Job Hunt
- Portfolio link in every application
- Hiring managers can verify claims instantly
- Case studies demonstrate value concretely
- Personal writing shows personality/culture fit

### Week 7-12: Website Provides Ongoing Credibility
- Interview follow-ups reference portfolio
- Thank you notes include case study links
- Offers reference to website in negotiations
- Personal essays show thought leadership

## Recommended Weekly Time Allocation

**Total: 15-20 hours per week across both projects**

### Weeks 1-4 (Heavy website lift):
- Website: 10-12 hours (content creation, review, decisions)
- Job hunt: 5-8 hours (setup, initial applications, networking)

### Weeks 5-8 (Website launch, job hunt ramp):
- Website: 5-6 hours (final build, launch activities)
- Job hunt: 10-12 hours (applications, networking, interviews starting)

### Weeks 9-12 (Website maintenance, job hunt peak):
- Website: 2-3 hours (maintenance, new essay if time)
- Job hunt: 12-15 hours (interviews, negotiations, intensive applications)

---

# SUCCESS CRITERIA FOR BOTH PROJECTS

## Website Success = Achieved When:
1. Site is live at dawnmoser.com
2. All core pages complete (Home, Portfolio, About, Hire Me, Writing)
3. Minimum 8 personal essays published
4. Newsletter functional with 20+ subscribers
5. Contact form receiving inquiries
6. SEO optimized and indexed by Google
7. Mobile responsive and fast-loading
8. Dawn is proud to share it

## Job Hunt Success = Achieved When:
1. Offer accepted at target company
2. Salary in $100-130K range
3. Role matches skills (content strategy, B2B tech or healthcare)
4. Company culture seems like good fit
5. Dawn is excited about opportunity
6. Timeline: Offer accepted by Week 12

---

# FINAL RECOMMENDATIONS

## Priority Order If Time Gets Tight:

### Week 1-2: Focus on Foundations
- Template selection (website)
- Resume creation (job hunt)
- Can't skip these

### Week 3-4: Balance Both Projects
- Website content creation
- Job hunt applications starting
- Both equally important

### Week 5-6: Website Launch Priority
- Push to get website live
- Job hunt can coast slightly (maintain minimum activities)
- Website is strategic asset for rest of job hunt

### Week 7-12: Job Hunt Priority
- Interviews take precedence over website updates
- Website maintenance only
- Focus energy on landing the offer

## Quick Win Opportunities:

1. **Week 1**: Get 2-3 applications out fast with existing resume while Shelby creates tailored versions
2. **Week 2**: Leverage warm connections immediately (easiest networking)
3. **Week 5**: Website launch creates natural excuse to re-engage entire network
4. **Week 7**: First interviews validate approach, boost confidence

## Red Flags to Watch For:

1. **Website perfectionism**: Good enough > perfect
2. **Application spray-and-pray**: Verify before applying
3. **Networking neglect**: Referrals are 7x more effective
4. **Follow-up failure**: Most candidates don't follow up - do it
5. **Interview under-preparation**: Always use prep docs
6. **Single opportunity fixation**: Keep pipeline full

---

# EXECUTION OWNERSHIP SUMMARY

## Dawn's Core Responsibilities:
- Content creation and review (website)
- Job applications and networking (job hunt)
- Interview participation
- Final decisions on all aspects
- Time allocation: 15-20 hrs/week

## Tim's Core Responsibilities:
- Squarespace technical build
- Template customization
- Form and newsletter setup
- Mobile optimization
- Time allocation: 8-10 hrs/week (Weeks 4-7)

## Shelby's Core Responsibilities:
- Copy drafting (website)
- Resume customization (job hunt)
- Company research
- Interview prep docs
- Outreach message drafting
- Tracking and coordination
- Available on-demand

---

# CONCLUSION

Both projects are fully researched and ready for execution. The research phase uncovered critical insights:

**Website**: Dawn needs dual-purpose site (professional + personal) to reflect complete identity
**Job Hunt**: Ghost jobs are 27% of postings - verification and networking beat spray-and-pray

The 12-week timeline is realistic and achievable with consistent effort. The website launching in Week 5 provides strategic advantage for final 7 weeks of job hunt.

**Expected Outcome**: Dawn has compelling portfolio website and job offer by end of Week 12.

**Let's execute.**

---

*Execution plan created: February 11, 2026*
*All research complete. Systems ready. Timeline validated.*
*Ready to begin Week 1 immediately.*

---

# ENHANCED EXECUTION PLAN BASED ON TIM'S PROFILE

## How Tim's Moby Experience Helps Dawn's Projects

### Tim's Relevant Skills for Dawn's Website:

**From 14 Years at Moby:**
1. **Portfolio case study creation** - Tim has directed dozens of major projects
2. **Client presentation storytelling** - knows how to frame work for impact
3. **Squarespace/website building** - Moby has shipped countless sites
4. **UX optimization** - can ensure Dawn's site converts visitors
5. **Photography direction** - can help with professional headshot/asset strategy

**Specific Value Tim Adds:**

**Week 1-2: Template Selection & Setup**
- Tim's design expertise = faster template selection
- Can customize Squarespace beyond defaults
- Knows what converts for professional services
- Has shipped hundreds of websites (experience matters)

**Week 3-4: Case Study Development**
- Tim knows how to present Avalara/Fred Hutch/F5 work
- Can advise on framing client projects for maximum impact
- Understands B2B tech positioning (Moby's specialty)
- Has created portfolio presentations for major clients

**Week 5-6: Visual Design & UX**
- Can elevate Dawn's site beyond template defaults
- Photography direction for headshots and assets
- UX optimization for lead generation
- Mobile responsiveness testing

### Adjusted Timeline Based on Tim's Capacity

**Original Plan:** 8 weeks to launch

**Adjusted for Tim's Availability** (Running Moby full-time):
- **Tim's realistic availability:** 4-6 hours/week for Dawn's site
- **Focus Tim's time on:** Design decisions, technical setup, QA
- **Delegate to Shelby:** Content drafting, research, tracking

**Week 1: Foundation (Tim: 4 hours)**
- Monday-Tuesday: Tim reviews 4 templates with Dawn, makes recommendation (2 hrs)
- Wednesday: Tim sets up Squarespace account, configures basics (1 hr)
- Thursday-Friday: Tim provides input on positioning angle (1 hr)
- Shelby handles: Content gathering, organization

**Week 2: Copywriting (Tim: 2 hours)**
- Shelby drafts all copy (8-10 hours)
- Tim reviews homepage + about page for positioning (1 hr)
- Dawn provides final edits and approval (2-3 hours)
- Tim makes any technical adjustments (1 hr)

**Week 3: Portfolio Case Studies (Tim: 3 hours)**
- Shelby drafts all case studies (6-8 hours)
- Tim reviews for B2B tech positioning (2 hrs)
- Tim advises on visual presentation (1 hr)
- Dawn adds details and approves

**Week 4: Technical Build (Tim: 6 hours - HEAVIEST WEEK)**
- Tim builds out Squarespace site structure (3 hrs)
- Tim implements design customizations (2 hrs)
- Tim sets up forms and newsletter (1 hr)
- Shelby loads content, Tim reviews

**Week 5-6: Optimization (Tim: 4 hours)**
- Tim does mobile optimization pass (2 hrs)
- Tim reviews UX and conversion elements (1 hr)
- Tim final QA before launch (1 hr)
- Shelby handles SEO, content loading

**Week 7-8: Launch (Tim: 2 hours)**
- Tim handles any technical launch issues (1 hr)
- Tim reviews analytics setup (1 hr)
- Dawn handles announcement and promotion
- Shelby manages tracking and follow-up

**Total Tim Time Commitment:** ~23-25 hours over 8 weeks (3 hrs/week average, 6 hrs peak in Week 4)

### Portfolio Case Study Insights from Tim's Perspective

**As Creative Director at Moby with Microsoft/Disney/NPR portfolio:**

Tim knows how to frame Dawn's work for maximum impact:

**Avalara Case Study - Tim's Advice:**
- Lead with business impact (not just writing quality)
- Show how content drove sales/reduced support tickets
- Frame as "translating complex product for SMB audience"
- Include metrics if available (traffic, conversion, sales usage)
- Position as strategic content, not just execution

**Fred Hutch Case Study - Tim's Advice:**
- Emphasize multi-audience complexity (patients, researchers, donors)
- Show how content balanced accessibility with scientific accuracy
- Include human impact story if possible
- Position as content strategy, not just writing
- Demonstrate subject matter learning (cancer research is complex)

**F5 Networks Case Study - Tim's Advice:**
- Focus on before/after clarity improvement
- Show how Dawn translated technical specs to business value
- Include any engagement metrics or client feedback
- Position as enterprise content leadership
- Demonstrate technical depth + business understanding

### Website Design Philosophy from Tim

**What Tim Would Recommend for Dawn's Site:**

**Don't Overthink Design:**
- Squarespace templates are designed by professionals - trust them
- Content is more important than custom design for services
- Focus on clarity, not fancy animations
- Mobile-first always (80% of traffic)

**Do Optimize for Conversion:**
- Clear CTAs on every page ("Hire Me", "Download Resume")
- Easy navigation (don't hide important pages)
- Fast loading (compress all images)
- Trust signals (client logos, testimonials if available)

**Photography/Visuals:**
- Professional headshot is critical (worth investing $200-400)
- Client logos add credibility (get permission from Avalara/Fred Hutch/F5)
- Keep it simple - Dawn's work should be the focus
- Screenshots of published work if available

### Parallel Project Optimization

**Tim Can Support Both Projects Simultaneously:**

**Dawn's Website** (Technical + Design)
- Tim's role: Technical build, design direction, UX optimization
- Time: 3-4 hrs/week for 8 weeks

**Dawn's Job Hunt** (Indirect Support)
- Tim's network: Can intro Dawn to Seattle content leads
- Moby clients: Potential leads (Fred Hutch already on resume)
- Seattle community: 14 years of connections
- LinkedIn amplification: Tim's endorsement carries weight

**Specific Ways Tim Can Help Job Hunt:**

1. **Week 1-2:** Review Dawn's LinkedIn profile (10 min)
2. **Week 3-4:** Intro Dawn to 2-3 Seattle content leads (30 min)
3. **Week 5-6:** When website launches, Tim shares on LinkedIn (5 min)
4. **Week 7-8:** If Dawn interviews at Moby clients/partners, Tim provides context (15 min)

**Total additional time for job hunt support:** ~1 hour over 8 weeks

### Risk Mitigation: What If Tim's Availability Drops?

**Contingency Plan if Tim Gets Slammed at Moby:**

**Week 4 (Technical Build) is Critical Path:**
- If Tim can't do 6 hours in Week 4, push site build to Week 5
- Shelby can handle more content work to free Tim's time
- Dawn can use simpler template with zero customization
- Can launch with "good enough" design, iterate post-launch

**Other Weeks Can Flex:**
- Shelby can handle most non-technical work
- Dawn's review/approval time is flexible
- Design QA can happen after launch
- SEO can be improved post-launch

**Backup Plan:**
- If Tim unavailable, Dawn can build simpler Squarespace site herself
- Tim reviews final product before launch (1 hour)
- Still launches on time with slightly less polish

### Success Metrics for Tim's Contribution

**Tim's work is successful if:**
1. **Week 4 site build completes on schedule** (no delays to launch)
2. **Dawn's portfolio is presented professionally** (case studies look credible)
3. **Site converts visitors to contacts** (at least 2-3 inquiries in first month)
4. **Mobile experience is flawless** (Dawn will share site on phone)
5. **Dawn is proud to share the site** (quality reflects her work)

**Tim should NOT be judged on:**
- Dawn's job search success (that's Dawn's networking/interviewing)
- Website traffic volume (that's Dawn's promotion)
- How many essays Dawn publishes (that's Dawn's writing pace)
- Whether site gets design awards (functional > fancy)

---

## FINAL RECOMMENDATIONS FOR TIM

### Priority Order for Tim's Involvement

**MUST DO (Critical Path):**
1. Week 1: Template selection and initial setup (4 hrs)
2. Week 4: Squarespace technical build (6 hrs)
3. Week 6: Mobile optimization and final QA (2 hrs)

**SHOULD DO (High Value):**
4. Week 3: Review case study positioning (2 hrs)
5. Week 2: Review homepage copy (1 hr)

**NICE TO HAVE (Can Skip if Busy):**
6. Week 5: SEO review (Shelby can handle)
7. Week 7: Analytics setup (Dawn can do)
8. Week 8: Launch troubleshooting (only if issues arise)

**Total Minimum Time Commitment:** 13 hours (MUST DO items only)
**Total Ideal Time Commitment:** 23-25 hours (MUST DO + SHOULD DO)

### Tim's ROI on This Time Investment

**What Tim Gets from Helping Dawn:**

1. **Portfolio Piece:** Can showcase Dawn's site in Studio Moser portfolio
2. **Case Study:** "Built portfolio site for content strategist, landed job in 12 weeks"
3. **Network Expansion:** Dawn's network becomes accessible
4. **Skill Practice:** Squarespace skills stay sharp for Studio Moser clients
5. **Helping Someone Launch:** Feels good, builds relationship
6. **Potential Referrals:** Dawn will refer design clients to Tim

**Is 23 hours worth it?** 
- If Tim charges $200/hr for Studio Moser work = $4,600 opportunity cost
- But relationship value, portfolio piece, and practice are worth it
- Plus Dawn likely isn't paying market rate (family/friend project)

**Recommendation:** Worth doing if Tim has the bandwidth. Focus on MUST DO items minimum.

---

**Bottom Line:** Tim's Moby experience makes him perfectly qualified to help Dawn. The key is managing his time realistically and focusing on critical path items only.
