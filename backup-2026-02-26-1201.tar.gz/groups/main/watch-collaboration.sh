#!/bin/bash

# Watch for messages from Dawn's agent
MESSAGE_FILE="/workspace/extra/collaboration/messages/from-dawn-agent.md"
LAST_CHECK_FILE="/workspace/group/.last-collaboration-check"

# Get last modification time
if [ -f "$MESSAGE_FILE" ]; then
    CURRENT_MTIME=$(stat -c %Y "$MESSAGE_FILE" 2>/dev/null || stat -f %m "$MESSAGE_FILE" 2>/dev/null)

    if [ -f "$LAST_CHECK_FILE" ]; then
        LAST_MTIME=$(cat "$LAST_CHECK_FILE")
    else
        LAST_MTIME=0
    fi

    if [ "$CURRENT_MTIME" -gt "$LAST_MTIME" ]; then
        echo "NEW MESSAGE from Dawn's agent detected!"
        echo "File: $MESSAGE_FILE"
        echo "---"
        cat "$MESSAGE_FILE"
        echo "$CURRENT_MTIME" > "$LAST_CHECK_FILE"
        exit 0
    else
        echo "No new messages"
        exit 1
    fi
else
    echo "No messages yet from Dawn's agent"
    exit 1
fi
