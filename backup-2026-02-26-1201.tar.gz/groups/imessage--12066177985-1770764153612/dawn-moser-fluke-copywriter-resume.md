# Dawn Moser
*Creative Storyteller + Technical Writer*

**Seattle, WA** • dawn.moser@me.com • 206-617-7985
**Portfolio**: dawnmoser.com • **LinkedIn**: linkedin.com/in/dawn-moser

---

## PROFESSIONAL SUMMARY

Versatile copywriter with 12+ years crafting compelling, technically accurate content for B2B audiences across technology and healthcare sectors. Published 48+ articles at Avalara translating complex tax compliance into accessible narratives. Proven ability to blend creative storytelling with technical precision—shifting seamlessly from conceptual campaign development to detailed product content. Expert at collaborating with cross-functional teams to develop messaging that educates, engages, and inspires trust among technical professionals.

**Core Expertise**: Creative Storytelling • Technical & Product Writing • SEO/AEO/GEO Content • Brand Voice Development • Cross-Functional Collaboration • B2B Tech & Industrial Content • Campaign Copy • Digital Marketing

---

## PROFESSIONAL EXPERIENCE

### Web Writer and Developer | Content Strategist
**Avalara** (B2B SaaS - Tax Compliance Technology) — Seattle, WA | *Feb 2019 – June 2024*

**Creative Storytelling & Brand Writing**
- **Published 48+ articles** blending creative narratives with technical accuracy, making complex tax compliance accessible and engaging for SMB audiences
- Developed brand voice guidelines as **editorial board member**, ensuring tone, clarity, and messaging consistency across all channels
- Crafted compelling headlines, narratives, and value propositions that positioned Avalara as authoritative thought leader in competitive space
- Created state-by-state guides and long-form educational content that connected emotionally with business owners while reinforcing brand leadership

**Technical & Product Writing**
- Translated complex tax regulations, e-commerce compliance rules, and software features into clear, concise, audience-friendly content without sacrificing accuracy
- Partnered with product marketing and subject-matter experts to articulate product benefits, features, and use cases for diverse industries
- Wrote and refined content ranging from product pages and solution briefs to landing pages and training materials
- Developed comprehensive guides (exemption certificates, resale certificates, 1099 forms) that became sales enablement resources

**Content Development for Growth (SEO/AEO/GEO)**
- Created web and digital content optimized for SEO—ensuring discoverability, clarity, and user relevance
- Collaborated with digital team to interpret keyword insights and search intent, applying them to high-quality content that improved visibility and drove organic traffic
- Wrote structured, intent-aligned content for web pages, FAQs, how-to guides, and performance-driven assets
- Continuously refined content based on analytics and performance insights; articles still actively published through 2026

**Cross-Functional Collaboration**
- Partnered with strategists, product marketers, designers, and commercial teams to develop integrated campaigns and deliverables
- Managed feedback from multiple stakeholders with professionalism and clarity
- Contributed to content templates and scalable workflows that supported global operations

**Impact**: Content contributed to organic lead generation strategy; established Avalara as trusted resource in SMB tax compliance space

---

### Contract Writer
**Fred Hutch Cancer Center** — Seattle, WA | *Aug 2018 – Feb 2019*

**Technical & Healthcare Writing**
- **Interviewed scientists, program directors, and oncology researchers** to translate complex medical research into accessible content for multiple audiences (researchers, doctors, donors, patients, caregivers)
- Created patient-facing content explaining treatment options and clinical trials in plain language while maintaining medical precision and empathy
- Developed copy for full-site redesign, balancing technical accuracy with compassionate storytelling that inspired trust
- Collaborated with design and UX teams to ensure content supported wayfinding and user experience

**Impact**: Content received positive feedback from patient focus groups for clarity and compassion; successfully bridged gap between scientific expertise and patient/donor understanding

---

### Senior Copywriter | Content Lead
**F5 Networks** (Enterprise B2B - Application Delivery Technology) — Seattle, WA | *March 2016 – Aug 2018*

**Creative & Technical Campaign Development**
- **Led content strategy for two full site rewrites**, translating complex server-side technology into business-value messaging for enterprise IT buyers
- Created global demand generation toolkits including email sequences, landing pages, display ads, and nurture content targeting technical decision-makers
- Developed scalable content templates for product pages that balanced technical specifications with compelling benefit statements
- Wrote sales enablement materials (case studies, one-pagers, presentation decks) that helped communicate value to C-suite

**Operational Excellence & Workflow**
- **Served as PM on all content projects**, coordinating across product, design, and marketing teams to deliver high-quality work under tight deadlines
- Managed multiple projects simultaneously in fast-paced environment
- Ensured all content met brand and technical standards prior to final delivery

**Impact**: Improved product page clarity, reducing customer confusion; content framework enabled faster page creation for new products

---

### Senior Copywriter
**HackerAgency** — Seattle, WA | *June 2012 – Feb 2016*

**Creative Studio Experience**
- Developed digital marketing copy for B2B and B2C clients across technology, telecommunications, and e-commerce sectors
- Created integrated campaigns spanning email, display ads, landing pages, websites, and video scripts
- Used A/B testing and analytics to optimize messaging and inform content best practices
- Collaborated with creative, account, and design teams in fast-paced agency environment
- Managed multiple client projects simultaneously, delivering quality work on aggressive timelines

**Key B2B Projects**: Microsoft (Hotmail, Messenger campaigns), AT&T business services, telecommunications product launches

---

## SKILLS & COMPETENCIES

**Creative Storytelling**
- Brand voice development & guidelines
- Campaign narratives & concepts
- Headlines, taglines & scripts
- Long-form storytelling
- Emotional connection with technical audiences
- Value proposition development

**Technical & Product Writing**
- Complex topic translation
- B2B technology & industrial content
- Product pages & datasheets
- Solution briefs & feature descriptions
- Technical accuracy with clarity
- Healthcare & scientific content

**SEO/AEO/GEO Content**
- Keyword research & application
- Structured content development
- Search intent alignment
- On-page optimization
- Performance-driven content
- Analytics-based refinement

**Content Formats**
- Digital campaigns (display, email, social)
- Website copy & landing pages
- Blog posts & articles
- Video scripts & multimedia
- Product marketing materials
- Case studies & white papers
- How-to guides & FAQs
- UX microcopy
- Sales enablement content

**Cross-Functional Collaboration**
- Creative studio/agency experience
- Editorial board leadership
- Project management
- Stakeholder feedback management
- Designer/art director collaboration
- Product marketing partnerships
- Brand & digital team alignment

**Tools & Platforms**
- CMS platforms (WordPress, Squarespace, custom)
- Project management (Asana, Jira, Basecamp)
- Analytics (Google Analytics)
- SEO tools (keyword research, optimization)
- Collaboration tools (Slack, MS Teams, Google Workspace)

---

## PORTFOLIO HIGHLIGHTS

**48+ Published Articles** at Avalara
View at: avalara.com/blog/en/authors/dawn-moser.html

**Editorial Board Leadership**
Defined brand voice guidelines and content standards adopted company-wide

**Versatility Across Industries**
B2B SaaS • Healthcare • Enterprise Tech • E-commerce • Telecommunications

**Complete portfolio available at**: dawnmoser.com

---

## WHY I'M AN IDEAL FIT FOR FLUKE

**I thrive at the intersection of creative and technical writing.**

At Avalara, I made tax compliance engaging. At Fred Hutch, I made oncology research accessible. At F5 Networks, I made server-side technology compelling. This is exactly what Fluke needs—someone who can craft creative narratives while maintaining technical accuracy.

**I understand industrial and technical audiences.**

My B2B tech experience spans enterprise software, compliance technology, and application delivery—audiences similar to Fluke's early-career technicians, engineers, and professionals. I know how to connect emotionally with technical audiences while reinforcing brand leadership in safety, accuracy, and reliability.

**I'm a collaborative, fast-paced creative studio professional.**

From agency experience at HackerAgency to in-house creative work at Avalara and F5, I'm comfortable managing multiple projects, navigating stakeholder feedback, and delivering high-quality work under tight deadlines. I thrive in collaborative environments with designers, product marketers, and subject-matter experts.

**I write for growth and performance.**

My content isn't just creative—it's strategic. I understand SEO, search intent, and analytics-driven optimization. I create content that's discoverable, engaging, and drives results.

---

## EDUCATION

*(Bachelor's degree information if applicable)*

---

**Available for hybrid work in Everett, WA**
*Portfolio and writing samples available upon request*
